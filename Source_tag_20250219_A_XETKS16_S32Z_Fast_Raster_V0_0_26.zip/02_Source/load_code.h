/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2022                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */


#include "a_std_type.h"
#include "target_specific.h"

#ifdef PROCESSOR_MEM_TYPE_BIG_ENDIAN
#define LOAD_PATTERN ((uint32)('L'<<24) + (uint32)('O'<<16) + (uint32)('A'<<8) + (uint32)('D'))
#else
#define LOAD_PATTERN ((uint32)('L') + (uint32)('O'<<8) + (uint32)('A'<<16) + (uint32)('D'<<24))
#endif

#define APPLICATION_LOAD_FROM_FLASH_ADDR (0x00091240UL)

struct _section_hdr {
	uint32 src_offset;  //Offset from the start of the structure
	uint32 src_size;
	uint32 dest_addr;
};

struct _load_code_header {
	uint32 pattern;
	uint16 crc16;
	uint16 num_sections;
	struct _section_hdr load_section[1];
};

#ifdef BOOT_CORE_M33
extern struct _load_code_header rtu_code_store;
#define LOAD_OTHER_CORES_STRUCT rtu_code_store
#endif
#ifdef RTU_STAND_ALONE_BOOT
extern struct _load_code_header smu_code_store;
#define LOAD_OTHER_CORES_STRUCT smu_code_store
#endif
/**  LoadCodeSections() will only load if the pattern is found.  This allows the ability to load both the
 *   RTU and SMU from the debugger if desired.
 */
#if defined(BOOT_CORE_M33)||defined(RTU_STAND_ALONE_BOOT)
void LoadCodeSections(void);
#endif

inline static uint32 LoadCodeAvailableAddr(void)
{
#if defined(BOOT_CORE_M33)||defined(RTU_STAND_ALONE_BOOT)
    if(LOAD_PATTERN == LOAD_OTHER_CORES_STRUCT.pattern)  //This requires that the RTU image fits in the memory set aside in the SMU memory used for the SD card image
    {
    	return (uint32)(&LOAD_OTHER_CORES_STRUCT);
    }
    else
    {
    	//This is for the EVB QSPI but could be used for other applications
    	struct _load_code_header *rtu_qspi_code_store=(struct _load_code_header *)(APPLICATION_LOAD_FROM_FLASH_ADDR);  //Reserve first 1meg for header and SMU image
    	if(LOAD_PATTERN==rtu_qspi_code_store->pattern)
    	{
    		return APPLICATION_LOAD_FROM_FLASH_ADDR;
    	}
    }
#endif

    return 0;

}
