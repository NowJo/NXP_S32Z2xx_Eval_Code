/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef __hw_type_h__
#define __hw_type_h__

#include "ETK_Integration_Cfg.h"

typedef enum _core_index {
    eCORE_R52_0_INDEX,
    eCORE_R52_1_INDEX,
    eCORE_R52_2_INDEX,
    eCORE_R52_3_INDEX,
    eCORE_R52_4_INDEX,
    eCORE_R52_5_INDEX,
    eCORE_R52_6_INDEX,
    eCORE_R52_7_INDEX,
    eCORE_M33_INDEX,
    eCORE_MAX
}eCORE_INDEX_T;


typedef enum {
    	eHW_Type_Unknown=0,
    	eHW_Type_TU16
}ENUM_HW_TYPE;



extern volatile ENUM_HW_TYPE M_Hardware_Type;
extern volatile ENUM_HW_TYPE M_Hardware_TypeM33;

extern uint8 Get_Core_ID(void);
extern uint8 GetCoreIndex(void);

ENUM_HW_TYPE HWT_IsTU16_Check(void);

/*This function can only be set after the R52 memory has been initialized */
static inline void HWT_InitHW_Type(void)
{
    if(eCORE_M33_INDEX==Get_Core_ID())
    {
        M_Hardware_TypeM33=HWT_IsTU16_Check();
    }
    else
    {
        if(eHW_Type_Unknown==M_Hardware_TypeM33)
        {
            M_Hardware_Type=HWT_IsTU16_Check();
        }
        else
        {
            M_Hardware_Type=M_Hardware_TypeM33;  //M33 is always set before R52
        }
            
    }
}

static inline uint8 HWT_GetHW_Type(void)
{
    return M_Hardware_TypeM33;
}



#endif
