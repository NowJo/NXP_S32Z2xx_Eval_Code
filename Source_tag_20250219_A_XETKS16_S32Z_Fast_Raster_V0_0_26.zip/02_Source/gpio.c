/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "target_specific.h"
#include "ETK_Integration_Cfg.h"
#include "gpio.h"
#if defined(CONSECUTIVE_LED_BLINKING_SUPPORT)&&defined(INCA_CORE_R52)
#include "ETK_SER_Handshake.h"
#endif

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
#define MAX_CONSECUTIVE_LED (7)
#define MIN_CONSECUTIVE_LED (2)

sint8 LedBlinkingState = MIN_CONSECUTIVE_LED-1; // First LED to be set to the high state during the blinking. Should be between [2-7] first thing that it does is add 1.
uint8 LedDirection = LED_INCREASE; // Starting direction of the Led blinking
uint8 LedWaitTime = 0; // Current waiting time in function execution cycles before the next LED being set to output mode

uint32 LED_Consecutive_PinNumber[MAX_CONSECUTIVE_LED+1] = {
	    LED0_CONSECUTIVE,
		LED1_CONSECUTIVE ,
		LED2_CONSECUTIVE ,
		LED3_CONSECUTIVE ,
		LED4_CONSECUTIVE ,
		LED5_CONSECUTIVE ,
		LED6_CONSECUTIVE ,
		LED7_CONSECUTIVE
};

#endif


void GPIO_Init(void)
{
#ifdef USE_IO
    // PAD_041/GPIO[41]/CLKOUT_1 B3 S32Z_CLKOUT0
#ifdef LED_CAL //Used for startup diagnostics
    SIUL2_1.MSCR[LED_CAL].B.OBE = 1;  /* GPIO Output Buffer Enable */
    SIUL2_1.MSCR[LED_CAL].B.SSS = 0;  /* Source Signal Select */
    SIUL2_1.GPDO40.R = LED_ON;  //Set to high for start. R52 will toggle low when it starts
#endif
#ifdef LED_ALIVE_M //Used for startup diagnostics
    SIUL2_1.MSCR[LED_ALIVE_M].B.OBE = 1;
    SIUL2_1.MSCR[LED_ALIVE_M].B.SSS = 0;
    SIUL2_1.GPDO41.R = LED_ON;  //Set high user code will toggle low
#endif

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
	if(eHW_Type_TU16 == M_Hardware_TypeM33)
	{
		int n;
		for(n=0; n<=MAX_CONSECUTIVE_LED; n++)
		{
			SIUL2_1.MSCR[LED_Consecutive_PinNumber[n]].B.OBE = 1;
			SIUL2_1.MSCR[LED_Consecutive_PinNumber[n]].B.SSS = 0;
		}
		GPIO_LedBlinkingInit(0);
	}
#endif
	if(eHW_Type_TU16 == M_Hardware_TypeM33)
	{
		for(int i=64;i<72;i++)
		{
			SIUL2_1.MSCR[i].B.OBE = 1;
			SIUL2_1.MSCR[i].B.SSS = 0;
		}
		SIUL2_1.GPDO64.R = 0;
		SIUL2_1.GPDO65.R = 0;
		SIUL2_1.GPDO66.R = 0;
		SIUL2_1.GPDO67.R = 0;
		SIUL2_1.GPDO68.R = 0;
		SIUL2_1.GPDO69.R = 0;
		SIUL2_1.GPDO70.R = 0;
		SIUL2_1.GPDO71.R = 0;
	}
#endif  //USE_IO
}

/** Toggle LED based on Pin Number */
void GPIO_ToggleLED(uint8 PinNo)
{
#ifdef USE_IO
	switch(PinNo)
    {
	case 40:
    	SIUL2_1.GPDO40.R = !(SIUL2_1.GPDO40.B.PDO_N);
        break;

	case 41:
    	SIUL2_1.GPDO41.R = !(SIUL2_1.GPDO41.B.PDO_N);
        break;

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
	case 48:
    	SIUL2_1.GPDO48.R = !(SIUL2_1.GPDO48.B.PDO_N);
        break;

	case 49:
    	SIUL2_1.GPDO49.R = !(SIUL2_1.GPDO49.B.PDO_N);
        break;

	case 50:
    	SIUL2_1.GPDO50.R = !(SIUL2_1.GPDO50.B.PDO_N);
        break;

	case 51:
    	SIUL2_1.GPDO51.R = !(SIUL2_1.GPDO51.B.PDO_N);
        break;

	case 52:
    	SIUL2_1.GPDO52.R = !(SIUL2_1.GPDO52.B.PDO_N);
        break;

	case 53:
    	SIUL2_1.GPDO53.R = !(SIUL2_1.GPDO53.B.PDO_N);
        break;

	case 54:
    	SIUL2_1.GPDO54.R = !(SIUL2_1.GPDO54.B.PDO_N);
        break;

	case 55:
    	SIUL2_1.GPDO55.R = !(SIUL2_1.GPDO55.B.PDO_N);
        break;

#endif
    };
#endif
}



/* This is currently used to signal a missing (X)ETK (ETK_available bit not detected during handshake).*/
void GPIO_Led_YesEtk(void)
{
#ifdef USE_IO
#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
	if(eHW_Type_TU16 == M_Hardware_Type)
	{
		GPIO_LedBlinkingInit(3);
	}
#endif
#endif
}

/* This is currently used to signal a missing (X)ETK (ETK_available bit not detected during handshake).*/
void GPIO_Led_NoEtk(void)
{
#ifdef USE_IO
#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
	if(eHW_Type_TU16 == M_Hardware_Type)
	{
		GPIO_LedBlinkingInit(2);
	}
#endif
#endif
}


void GPIO_Led_AdvHandshake(uint8 state)
{
#ifdef USE_IO
#ifdef LED_HSTYPE
	if(eHW_Type_TU16 == M_Hardware_Type)
	{
		if(LED_ON==state)
			GPIO_TurnLedOn(LED_HSTYPE);
		else
			GPIO_TurnLedOff(LED_HSTYPE);
	}
#endif
#endif
}

void GPIO_Led_WP_Active(uint8 state)
{
#ifdef USE_IO
#ifdef LED_PAGE
	if(eHW_Type_TU16 == M_Hardware_Type)
	{
		if(LED_ON==state)
			GPIO_TurnLedOn(LED_PAGE);
		else
			GPIO_TurnLedOff(LED_PAGE);
	}
#endif
#endif
}




void GPIO_TurnLedOn(uint8 PinNo)
{
#ifdef USE_IO
	switch(PinNo)
    {
	case 40:
    	SIUL2_1.GPDO40.R = LED_ON;
        break;

	case 41:
    	SIUL2_1.GPDO41.R = LED_ON;
        break;

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
	case 48:
    	SIUL2_1.GPDO48.R = LED_ON;
        break;

	case 49:
    	SIUL2_1.GPDO49.R = LED_ON;
        break;

	case 50:
    	SIUL2_1.GPDO50.R = LED_ON;
        break;

	case 51:
    	SIUL2_1.GPDO51.R = LED_ON;
        break;

	case 52:
    	SIUL2_1.GPDO52.R = LED_ON;
        break;

	case 53:
    	SIUL2_1.GPDO53.R = LED_ON;
        break;

	case 54:
    	SIUL2_1.GPDO54.R = LED_ON;
        break;

	case 55:
    	SIUL2_1.GPDO55.R = LED_ON;
        break;

#endif
    }
#endif
}

void GPIO_TurnLedOff(uint8 PinNo)
{
#ifdef USE_IO
	switch(PinNo)
    {
	case 40:
    	SIUL2_1.GPDO40.R = LED_OFF;
        break;

	case 41:
    	SIUL2_1.GPDO41.R = LED_OFF;
        break;

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
	case 48:
    	SIUL2_1.GPDO48.R = LED_OFF;
        break;

	case 49:
    	SIUL2_1.GPDO49.R = LED_OFF;
        break;

	case 50:
    	SIUL2_1.GPDO50.R = LED_OFF;
        break;

	case 51:
    	SIUL2_1.GPDO51.R = LED_OFF;
        break;

	case 52:
    	SIUL2_1.GPDO52.R = LED_OFF;
        break;

	case 53:
    	SIUL2_1.GPDO53.R = LED_OFF;
        break;

	case 54:
    	SIUL2_1.GPDO54.R = LED_OFF;
        break;

	case 55:
    	SIUL2_1.GPDO55.R = LED_OFF;
        break;

#endif
    }
#endif
}


#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT

/* Resets the LEDs to a pattern make sure to call only when tu16 is present*/
void GPIO_LedBlinkingInit(uint8 mode)
{
#ifdef USE_IO
		switch(mode)
		{
			case 2:  //Turn all to off state this is when the ETK is not available
				SIUL2_1.GPDO50.R = LED_OFF;
				SIUL2_1.GPDO51.R = LED_OFF;
				SIUL2_1.GPDO52.R = LED_OFF;
				SIUL2_1.GPDO53.R = LED_OFF;
				SIUL2_1.GPDO54.R = LED_OFF;
				SIUL2_1.GPDO55.R = LED_OFF;
				break;

			case 3:  //Turn all to on state, these will turn into a pattern because a ETK was found latter
				SIUL2_1.GPDO50.R = LED_ON;
				SIUL2_1.GPDO51.R = LED_ON;
				SIUL2_1.GPDO52.R = LED_ON;
				SIUL2_1.GPDO53.R = LED_ON;
				SIUL2_1.GPDO54.R = LED_ON;
				//SIUL2_1.GPDO55.R = LED_ON; This is being used for timing info so do not toggle the state
				break;

			default:  //Set to initial state
				SIUL2_1.GPDO48.R = LED_OFF;
				SIUL2_1.GPDO49.R = LED_OFF;
				SIUL2_1.GPDO50.R = LED_OFF;
				SIUL2_1.GPDO51.R = LED_OFF;
				SIUL2_1.GPDO52.R = LED_OFF;
				SIUL2_1.GPDO53.R = LED_OFF;
				SIUL2_1.GPDO54.R = LED_OFF;
				SIUL2_1.GPDO55.R = LED_OFF;
		}

#endif
}
#endif

#if defined(CONSECUTIVE_LED_BLINKING_SUPPORT)&&defined(INCA_CORE_R52)

/* Blinks the LEDs 0-3 in a consecutive way. One Led is set to high mode, while the previous LED is reverted to low mode. */
void GPIO_LedBlinkingConsecutive(void)
{
#ifdef USE_IO

	if(eHW_Type_TU16 == M_Hardware_Type)
	{
		if(!ECU_ETK_ADV_Status.ETK_Available)
		{
			//Only blink 1 LED if the ETK is not found
			GPIO_ToggleLED(LED_Consecutive_PinNumber[MAX_CONSECUTIVE_LED]);
		}
		else
		{
			if (LedWaitTime > 0)
			{
				LedWaitTime--;
			}
			else
			{
				GPIO_TurnLedOff(LED_Consecutive_PinNumber[LedBlinkingState]);
				if (LedDirection == LED_INCREASE)
				{
					LedBlinkingState++;

					if (LedBlinkingState > MAX_CONSECUTIVE_LED)
					{
						LedDirection = LED_DECREASE;
						LedWaitTime = LED_STANDBY_TIME;
						LedBlinkingState--;
					}
					else // LedBlinkingState will not set a LED outside of the range
					{
						GPIO_TurnLedOn(LED_Consecutive_PinNumber[LedBlinkingState]);
					}
				}
				else if (LedDirection == LED_DECREASE)
				{
					LedBlinkingState--;

					if (LedBlinkingState < MIN_CONSECUTIVE_LED)
					{
						LedDirection = LED_INCREASE;
						LedWaitTime = LED_STANDBY_TIME;
						LedBlinkingState++;
					}
					else // LedBlinkingState will not set a LED outside of the range
					{
						GPIO_TurnLedOn(LED_Consecutive_PinNumber[LedBlinkingState]);
					}
				}
			}
		}
	}

#endif
}

#endif
