/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "meas_cal.h"
#include "base.h"
#include "ETK_Integration_Cfg.h" //SWITCH macros
#include "ETK_SectionMacro.h"

/************************************* BEGIN OF MEASUREMENT VARIABLES ************************************/
PRE_SECTION_RODATA(P_RasterCalMaxM33, ".CAL_PARAM")
CAL_DEF tCalMax P_RasterCalMaxM33 =
{
  //-1 is not "max positive value but is the value before roll over to 0 needed for LUX tests
    -1,     //sint32
    ~0,     //uint32
    -1,     //sint16
    ~0,     //uint16
    -1,     //sint8
    ~0      //uint8
};
POST_SECTION_RODATA()


PRE_SECTION_DATA(DistabExecTimeM33, ".IRAM_DATA")
VOLATILE_DEF uint32 DistabExecTimeM33[DISTAB_RASTER_EVENTS] = { 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(M_I_RasterMeasM33, ".IRAM_DATA")
VOLATILE_DEF tMeas M_I_RasterMeasM33[NUMBER_MEAS_RASTERS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(M_E_RasterMeasM33, ".IRAM_DATA")
VOLATILE_DEF tMeas M_E_RasterMeasM33[NUMBER_MEAS_RASTERS] = { 0 };
POST_SECTION_DATA()

/* Coldstart ASW Variables */
#ifdef COLDSTART_EXECUTION_TIME
uint32 Time_for_Wait_Pattern_ASD;
uint32 Time_for_Ready_Pattern_ASD;
#endif


#ifdef CAL_MEASURE_BLOCKS
PRE_SECTION_DATA(M_Cal_Measure_Blocks, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureBlocks M_Cal_Measure_Blocks = { { 0 } };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_Cal_Measure_Blocks, ".ETAS_RP2")
VOLATILE_DEF tCalMeasureBlocks P_Cal_Measure_Blocks;
POST_SECTION_DATA()
#endif

/************************************* END OF MEASUREMENT VARIABLE ************************************/

/************************************* BEGIN OF CALIBRATION PARAMETERS ************************************/

/************************************* END OF CALIBRATION PARAMETERS ************************************/

/************************************* BEGIN OF ADAPTIVE PARAMETERS ************************************/
/************************************* END OF ADAPTIVE PARAMETERS ************************************/

/* Functions */
#define INCREMENT_COUNTER(VAL, MAX) VAL++; *VAL = (MAX == *VAL) ? 0 : *VAL + 1

void MEAS_IncrementFctM33(VOLATILE_DEF tMeas* meas)
{
    uint8 i;

    VOLATILE_DEF sint8* sint8_ptr;
    VOLATILE_DEF sint16* sint16_ptr;
    VOLATILE_DEF sint32* sint32_ptr;
    VOLATILE_DEF uint8* uint8_ptr;
    VOLATILE_DEF uint16* uint16_ptr;
    VOLATILE_DEF uint32* uint32_ptr;
#ifdef FLOAT32_SUPPORT
    VOLATILE_DEF real32* fl32_ptr;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
    VOLATILE_DEF real64* fl64_ptr;
#endif // FLOAT64_SUPPORT

    sint8_ptr = &meas->sint8.sint8_01;
    uint8_ptr = &meas->uint8.uint8_01;
    sint16_ptr = &meas->sint16.sint16_01;
    uint16_ptr = &meas->uint16.uint16_01;
    sint32_ptr = &meas->sint32.sint32_01;
    uint32_ptr = &meas->uint32.uint32_01;
#ifdef FLOAT32_SUPPORT
    fl32_ptr = &meas->fl32.fl32_01;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
    fl64_ptr = &meas->fl64.fl64_01;
#endif // FLOAT64_SUPPORT

    /* INCREMENT_COUNTER starts incrementing it VAL++. So, it has to start one address before. */
    sint8_ptr--;
    uint8_ptr--;
    sint16_ptr--;
    uint16_ptr--;
    sint32_ptr--;
    uint32_ptr--;
#ifdef FLOAT32_SUPPORT
    fl32_ptr--;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
    fl64_ptr--;
#endif // FLOAT64_SUPPORT

    for (i = 0; i < 8; i++)
    {
        INCREMENT_COUNTER(sint8_ptr,  ACTIVE_PAGE_SINT8(P_RasterCalMaxM33.sint8_max));
        INCREMENT_COUNTER(uint8_ptr,  ACTIVE_PAGE_UINT8(P_RasterCalMaxM33.uint8_max));
        INCREMENT_COUNTER(sint16_ptr, ACTIVE_PAGE_SINT16(P_RasterCalMaxM33.sint16_max));
        INCREMENT_COUNTER(uint16_ptr, ACTIVE_PAGE_UINT16(P_RasterCalMaxM33.uint16_max));
        INCREMENT_COUNTER(sint32_ptr, ACTIVE_PAGE_SINT32(P_RasterCalMaxM33.sint32_max));
        INCREMENT_COUNTER(uint32_ptr, ACTIVE_PAGE_UINT32(P_RasterCalMaxM33.uint32_max));
#ifdef FLOAT32_SUPPORT
        fl32_ptr++;
        *fl32_ptr+=1.0;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
        fl64_ptr++;
        *fl64_ptr+=1.0;
#endif // FLOAT64_SUPPORT
    }

}

void MEAS_RasterCountersM33(uint8 index)
{
    MEAS_IncrementFctM33(&M_I_RasterMeasM33[index]);
    MEAS_IncrementFctM33(&M_E_RasterMeasM33[index]);
}

void MEAS_RasterCountersM33Init(void)
{
    uint8 i;

    for (i = 0; i < NUMBER_MEAS_RASTERS; i++)
    {
        M_I_RasterMeasM33[i].sint8.sint8_01 = -71;
        M_I_RasterMeasM33[i].sint8.sint8_02 = -61;
        M_I_RasterMeasM33[i].sint8.sint8_03 = -51;
        M_I_RasterMeasM33[i].sint8.sint8_04 = -41;
        M_I_RasterMeasM33[i].sint8.sint8_05 = -31;
        M_I_RasterMeasM33[i].sint8.sint8_06 = -21;
        M_I_RasterMeasM33[i].sint8.sint8_07 = -11;
        M_I_RasterMeasM33[i].sint8.sint8_08 = -01;

        M_I_RasterMeasM33[i].sint16.sint16_01 = -7003;
        M_I_RasterMeasM33[i].sint16.sint16_02 = -6003;
        M_I_RasterMeasM33[i].sint16.sint16_03 = -5003;
        M_I_RasterMeasM33[i].sint16.sint16_04 = -4003;
        M_I_RasterMeasM33[i].sint16.sint16_05 = -3003;
        M_I_RasterMeasM33[i].sint16.sint16_06 = -2003;
        M_I_RasterMeasM33[i].sint16.sint16_07 = -1003;
        M_I_RasterMeasM33[i].sint16.sint16_08 = -0003;

        M_I_RasterMeasM33[i].sint32.sint32_01 = -1900000005;
        M_I_RasterMeasM33[i].sint32.sint32_02 = -190000005;
        M_I_RasterMeasM33[i].sint32.sint32_03 = -19000005;
        M_I_RasterMeasM33[i].sint32.sint32_04 = -1900005;
        M_I_RasterMeasM33[i].sint32.sint32_05 = -190005;
        M_I_RasterMeasM33[i].sint32.sint32_06 = -19005;
        M_I_RasterMeasM33[i].sint32.sint32_07 = -1905;
        M_I_RasterMeasM33[i].sint32.sint32_08 = -195;

        M_I_RasterMeasM33[i].uint8.uint8_01 = 00;
        M_I_RasterMeasM33[i].uint8.uint8_02 = 10;
        M_I_RasterMeasM33[i].uint8.uint8_03 = 20;
        M_I_RasterMeasM33[i].uint8.uint8_04 = 30;
        M_I_RasterMeasM33[i].uint8.uint8_05 = 40;
        M_I_RasterMeasM33[i].uint8.uint8_06 = 50;
        M_I_RasterMeasM33[i].uint8.uint8_07 = 60;
        M_I_RasterMeasM33[i].uint8.uint8_08 = 70;

        M_I_RasterMeasM33[i].uint16.uint16_01 = 0005;
        M_I_RasterMeasM33[i].uint16.uint16_02 = 1005;
        M_I_RasterMeasM33[i].uint16.uint16_03 = 2005;
        M_I_RasterMeasM33[i].uint16.uint16_04 = 3005;
        M_I_RasterMeasM33[i].uint16.uint16_05 = 4005;
        M_I_RasterMeasM33[i].uint16.uint16_06 = 5005;
        M_I_RasterMeasM33[i].uint16.uint16_07 = 6005;
        M_I_RasterMeasM33[i].uint16.uint16_08 = 7005;

        M_I_RasterMeasM33[i].uint32.uint32_01 = 400000001;
        M_I_RasterMeasM33[i].uint32.uint32_02 = 40000001;
        M_I_RasterMeasM33[i].uint32.uint32_03 = 4000001;
        M_I_RasterMeasM33[i].uint32.uint32_04 = 400001;
        M_I_RasterMeasM33[i].uint32.uint32_05 = 40001;
        M_I_RasterMeasM33[i].uint32.uint32_06 = 4001;
        M_I_RasterMeasM33[i].uint32.uint32_07 = 401;
        M_I_RasterMeasM33[i].uint32.uint32_08 = 41;

        M_E_RasterMeasM33[i].sint8.sint8_01 = -72;
        M_E_RasterMeasM33[i].sint8.sint8_02 = -62;
        M_E_RasterMeasM33[i].sint8.sint8_03 = -52;
        M_E_RasterMeasM33[i].sint8.sint8_04 = -42;
        M_E_RasterMeasM33[i].sint8.sint8_05 = -32;
        M_E_RasterMeasM33[i].sint8.sint8_06 = -22;
        M_E_RasterMeasM33[i].sint8.sint8_07 = -12;
        M_E_RasterMeasM33[i].sint8.sint8_08 = -02;

        M_E_RasterMeasM33[i].sint16.sint16_01 = -7004;
        M_E_RasterMeasM33[i].sint16.sint16_02 = -6004;
        M_E_RasterMeasM33[i].sint16.sint16_03 = -5004;
        M_E_RasterMeasM33[i].sint16.sint16_04 = -4004;
        M_E_RasterMeasM33[i].sint16.sint16_05 = -3004;
        M_E_RasterMeasM33[i].sint16.sint16_06 = -2004;
        M_E_RasterMeasM33[i].sint16.sint16_07 = -1004;
        M_E_RasterMeasM33[i].sint16.sint16_08 = -0004;

        M_E_RasterMeasM33[i].sint32.sint32_01 = -200000005;
        M_E_RasterMeasM33[i].sint32.sint32_02 = -150000005;
        M_E_RasterMeasM33[i].sint32.sint32_03 = -100000004;
        M_E_RasterMeasM33[i].sint32.sint32_04 = -500000004;
        M_E_RasterMeasM33[i].sint32.sint32_05 = -50000004;
        M_E_RasterMeasM33[i].sint32.sint32_06 = -500004;
        M_E_RasterMeasM33[i].sint32.sint32_07 = -5004;
        M_E_RasterMeasM33[i].sint32.sint32_08 = -54;

        M_E_RasterMeasM33[i].uint8.uint8_01 = 01;
        M_E_RasterMeasM33[i].uint8.uint8_02 = 11;
        M_E_RasterMeasM33[i].uint8.uint8_03 = 21;
        M_E_RasterMeasM33[i].uint8.uint8_04 = 31;
        M_E_RasterMeasM33[i].uint8.uint8_05 = 41;
        M_E_RasterMeasM33[i].uint8.uint8_06 = 51;
        M_E_RasterMeasM33[i].uint8.uint8_07 = 61;
        M_E_RasterMeasM33[i].uint8.uint8_08 = 71;

        M_E_RasterMeasM33[i].uint16.uint16_01 = 0004;
        M_E_RasterMeasM33[i].uint16.uint16_02 = 1004;
        M_E_RasterMeasM33[i].uint16.uint16_03 = 2004;
        M_E_RasterMeasM33[i].uint16.uint16_04 = 3004;
        M_E_RasterMeasM33[i].uint16.uint16_05 = 4004;
        M_E_RasterMeasM33[i].uint16.uint16_06 = 5004;
        M_E_RasterMeasM33[i].uint16.uint16_07 = 6004;
        M_E_RasterMeasM33[i].uint16.uint16_08 = 7004;

        M_E_RasterMeasM33[i].uint32.uint32_01 = 430000002;
        M_E_RasterMeasM33[i].uint32.uint32_02 = 420000002;
        M_E_RasterMeasM33[i].uint32.uint32_03 = 42000002;
        M_E_RasterMeasM33[i].uint32.uint32_04 = 4200002;
        M_E_RasterMeasM33[i].uint32.uint32_05 = 420002;
        M_E_RasterMeasM33[i].uint32.uint32_06 = 42002;
        M_E_RasterMeasM33[i].uint32.uint32_07 = 4202;
        M_E_RasterMeasM33[i].uint32.uint32_08 = 422;
    }
}

#ifdef CAL_MEASURE_BLOCKS
void MEAS_UpdateCalMeasureBlocks(void)
{
    uint32 Index_x, Index_y;

    for (Index_x = 0U; Index_x < 6U; Index_x++)
    {
        M_Cal_Measure_Blocks.Sint32_array[Index_x] = ACTIVE_PAGE_SINT32(P_Cal_Measure_Blocks.Sint32_array[Index_x]);
        M_Cal_Measure_Blocks.Sint16_array[Index_x] = ACTIVE_PAGE_SINT16(P_Cal_Measure_Blocks.Sint16_array[Index_x]);
        M_Cal_Measure_Blocks.Sint8_array[Index_x] = ACTIVE_PAGE_SINT8(P_Cal_Measure_Blocks.Sint8_array[Index_x]);
        M_Cal_Measure_Blocks.Uint32_array[Index_x] = ACTIVE_PAGE_UINT32(P_Cal_Measure_Blocks.Uint32_array[Index_x]);
        M_Cal_Measure_Blocks.Uint16_array[Index_x] = ACTIVE_PAGE_UINT16(P_Cal_Measure_Blocks.Uint16_array[Index_x]);
        M_Cal_Measure_Blocks.Uint8_array[Index_x] = ACTIVE_PAGE_UINT8(P_Cal_Measure_Blocks.Uint8_array[Index_x]);

#ifdef FLOAT32_SUPPORT
        M_Cal_Measure_Blocks.Fl32_array[Index_x] = ACTIVE_PAGE_FL32(P_Cal_Measure_Blocks.Fl32_array[Index_x]);
#endif

#ifdef FLOAT64_SUPPORT
        M_Cal_Measure_Blocks.Fl64_array[Index_x] = ACTIVE_PAGE_FL64(P_Cal_Measure_Blocks.Fl64_array[Index_x]);
#endif
    }

    for (Index_x = 0U; Index_x < 5U; Index_x++)
    {
        for (Index_y = 0U; Index_y < 6U; Index_y++)
        {
            M_Cal_Measure_Blocks.Sint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_SINT8(P_Cal_Measure_Blocks.Sint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Sint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_SINT16(P_Cal_Measure_Blocks.Sint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Sint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_SINT32(P_Cal_Measure_Blocks.Sint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Uint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_UINT8(P_Cal_Measure_Blocks.Uint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Uint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_UINT16(P_Cal_Measure_Blocks.Uint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Uint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_UINT32(P_Cal_Measure_Blocks.Uint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

#ifdef FLOAT32_SUPPORT
            M_Cal_Measure_Blocks.Fl32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_FL32(P_Cal_Measure_Blocks.Fl32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);
#endif

#ifdef FLOAT64_SUPPORT
            M_Cal_Measure_Blocks.Fl64_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_FL64(P_Cal_Measure_Blocks.Fl64_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);
#endif
        }

    }
}
#endif

