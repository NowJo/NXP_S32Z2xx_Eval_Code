/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2022                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
/***************************************************************************//**
* \file  Distab17_Inst.h
* \brief file containing the declaration of the Distab17 data structs
*******************************************************************************/

#ifndef DISTAB17_INST_H
#define DISTAB17_INST_H

#include "ETK_Integration_Cfg.h"
#include "Distab17_Def.h"
#include "Distab17_Cfg.h"

extern
VOLATILE_DEF
uint8 Distab17EventConfigArea[];

extern
VOLATILE_DEF
uint8 Distab17EventOutputArea[];

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
tD17EventList Distab17EventList;

#if (defined TRG_ON_RAM) || (defined ADV_RAM_HS_SUPPORTED)
    PRE_SECTION_BSS(RAM_INTERFACE, ".RAM_HsTrg_MemClass")
    extern
    #ifdef USE_DISTAB_CONST_DEF
    DISTAB_CONST_DEF
    #endif /* #ifdef USE_DISTAB_CONST_DEF */
    #ifdef USE_VOLATILE_DEF
    VOLATILE_DEF
    #endif /* #ifdef USE_VOLATILE_DEF */
	tInterfaceOnRAM RAM_INTERFACE;
    POST_SECTION_BSS()
#endif

#ifdef D17_USE_VIRTUAL_TRIGGER
extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
//#ifdef USE_VOLATILE_DEF
//VOLATILE_DEF
//#endif /* #ifdef USE_VOLATILE_DEF */
CONST_DEF tECUTriggerTable ECUTriggerTable;
#endif

#ifdef D17_ENABLE_BYPASS_SUPPORT

//#ifndef USE_DISTAB_CONST_DEF
//#define USE_DISTAB_CONST_DEF // FIXME!
//#define UNDEF_USE_DISTAB_CONST_DEF
//#endif


extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
tD17GlobalServicePointDescriptor D17_ServicePoint_Cfg;


extern
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
tD17ControlVars D17_SP_ControlVar[];

#ifdef D17_SBB_ASCETBUILD

//////////////////////////////////////////////////////////////////////////////

#include "SBB_module_reduced_114_SP.h"

#define ASCET_PARAM_MODULE_PREFIX SBB_module_SBB_CALS
#define ASCET_VAR_MODULE_PREFIX SBB_module_SBB_IRAM

#define P_D17_TimeOutPre (ASCET_PARAM_MODULE_PREFIX.P_TimeOutPre)
#define P_D17_TimeOutPost (ASCET_PARAM_MODULE_PREFIX.P_TimeOutPost)
#define P_D17_SrvPtEnabled (ASCET_PARAM_MODULE_PREFIX.P_SrvPtEnabled)
#define P_D17_SrvPtResId (ASCET_PARAM_MODULE_PREFIX.P_SrvPtResId)
#define P_D17_ResIdSrvPt (ASCET_PARAM_MODULE_PREFIX.P_ResIdSrvPt)
#define P_D17_DisableFctExec (ASCET_PARAM_MODULE_PREFIX.P_DisableECUFct)
#define P_D17_DisableRAIDCheck (ASCET_PARAM_MODULE_PREFIX.P_DisableRAIDCheck)

#define D17_TriggerCount (ASCET_VAR_MODULE_PREFIX.SBB_SP_TriggerCount)
#define D17_ProcessCount (ASCET_VAR_MODULE_PREFIX.SBB_SP_ProcessCount)
#define D17_LockMissCount (ASCET_VAR_MODULE_PREFIX.SBB_SP_LockMissCount)

//////////////////////////////////////////////////////////////////////////////

#else /* #ifdef D17_SBB_ASCETBUILD */

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
uint32 P_D17_TimeOutPre[];

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
uint32 P_D17_TimeOutPost[];

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
uint8 P_D17_SrvPtEnabled[];

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
uint8 P_D17_SrvPtResId[];

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
uint16 P_D17_ResIdSrvPt[];

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
uint8 P_D17_DisableFctExec[];

#ifdef D17_BYPASS_DEBUG_ALLOW_NO_READ_ACTION_ID_CHECK
extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
uint8 D17_BYPASS_DEBUG_ALLOW_NO_READ_ACTION_ID_CHECK;
#endif /* #ifdef D17_BYPASS_DEBUG_NO_READ_ACTION_ID_CHECK */

/* ETASTEST    */ extern uint32 SBB_SP_TriggerCount[];
/* ETASTEST    */ extern uint32 SBB_SP_ProcessCount[];
/* ETASTEST    */ extern uint32 SBB_SP_LockMissCount[];

#endif

/* Internal helpers */

extern uint8 D17_SP_OldBypassCounterPre[];
extern uint8 D17_SP_OldBypassCounterPost[];
extern uint32 D17_SP_StartWaitTimePre[];
extern uint32 D17_SP_StartWaitTimePost[];

#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
extern uint8 D17_SP_Status_TimeOutPre[];
extern uint8 D17_SP_Status_TimeOutPost[];
extern uint8 D17_SP_Status_ServicePointEnabled[];
extern uint8 D17_SP_Status_FunctionExecution[];
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
extern uint32 D17_SP_Timestamp_Trigger_Pre[];
extern uint32 D17_SP_Timestamp_Trigger_Post[];
extern uint32 D17_SP_Timestamp_StartCopyECUData_Pre[];
extern uint32 D17_SP_Timestamp_StartCopyECUData_Post[];
extern uint32 D17_SP_Timestamp_BypassAnswer_Pre[];
extern uint32 D17_SP_Timestamp_BypassAnswer_Post[];
extern uint32 D17_SP_Timestamp_BypassDataCopied_Pre[];
extern uint32 D17_SP_Timestamp_BypassDataCopied_Post[];
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
extern uint8 D17_SBB_State_IsFirstServicePoint;
extern uint8 D17_SBB_State_IsETargetDetected;
extern uint32 D17_SBB_State_RAIDWaitLoops;
extern enum D17_SBB_Enable_State D17_SBB_State;
extern enum D17_SBB_Structure_Version D17_SBB_State_StructureVersion;
extern enum D17_SBB_Structure_Type D17_SBB_State_StructureType;
extern enum D17_SBB_Feature_Mode D17_SBB_State_FeatureMode;

extern
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif /* #ifdef USE_DISTAB_CONST_DEF */
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif /* #ifdef USE_VOLATILE_DEF */
enum D17_SBB_State_Request P_D17_SBB_Enable;

#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

#endif /*#ifdef D17_ENABLE_BYPASS_SUPPORT*/

#ifdef TRACE_SUPPORT
extern VOLATILE_DEF uint32 TraceTriggerSuD17;
extern VOLATILE_DEF uint32 traceTrigger;
#endif
#endif /* DISTAB17_INST_H */
