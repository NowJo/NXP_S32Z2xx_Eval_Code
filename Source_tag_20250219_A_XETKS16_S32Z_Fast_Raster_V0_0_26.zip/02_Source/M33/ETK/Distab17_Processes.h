/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2022                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef DISTAB17_PROCESS_H
#define DISTAB17_PROCESS_H

#include "Distab17_Cfg.h"
#include "ETK_Integration_cfg.h"
#include "Distab17_Def.h"
#include "Distab17_Fct.h"
#include "Distab17_Inst.h"

#ifdef ASCET_PROJ
#include "base.h"
#ifdef D17_ENABLE_BYPASS_SUPPORT
#ifndef D17_SBB_ASCETBUILD
#include "SBB_module_ext.h"
#endif
#endif
#else
#include "../target_specific.h"
#ifdef D17_ENABLE_BYPASS_SUPPORT
#ifndef D17_SBB_ASCETBUILD
#include "SBB_module_ext.h"
#endif
#endif
#endif

/*******************************************************************************
* \fn Distab17_Process
* \brief Process the configuration for the given event
* \param eventNumber the current event
*
* This function looks up the event configuration, decides whether this event is
* enabled, used TDM or the output table, if necessary invokes the data copy
* and finally executes the trigger.
*******************************************************************************/
extern enum D17_Result Distab17_Process(uint16 eventNumber);
extern int Distab17_IsTimeout(uint32 startTime, uint32 waitTime);
extern uint32 Distab17_GetSystemTime(void);
extern uint32 Distab17_GetMicrosecondsToTicks(uint32 microSeconds);

#ifdef D17_ENABLE_BYPASS_SUPPORT

extern void* Distab17_IsServicePointActiveAndConfiguredForHBB(uint8 servicePointNumber);

extern uint8 Distab17_SBB_Process(
    uint8 servicePointNumber,
    enum D17_SBB_SP_Type servicePointType);

extern uint8 Distab17_HBB_Process(uint8 servicePointNumber);

extern uint8 Distab17_Get_Bypass_Value_Bit(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint8 ecuValue,
    uint8 bitOffset);

extern uint8 Distab17_Get_Bypass_Value_uint8(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint8 ecuValue);

extern sint8 Distab17_Get_Bypass_Value_sint8(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    sint8 ecuValue);

extern uint16 Distab17_Get_Bypass_Value_uint16(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint16 ecuValue);

extern sint16 Distab17_Get_Bypass_Value_sint16(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    sint16 ecuValue);

extern uint32 Distab17_Get_Bypass_Value_uint32(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint32 ecuValue);

extern sint32 Distab17_Get_Bypass_Value_sint32(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    sint32 ecuValue);

extern real32 Distab17_Get_Bypass_Value_real32(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    real32 ecuValue);

extern real64 Distab17_Get_Bypass_Value_real64(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    real64 ecuValue);

#ifdef D17_ENABLE_BYPASS_NB_OF_BYTES_STATUS
extern void Distab17_SBB_NbOfBytes(uint8 servicePointNumber);
/* ETASTEST    */ extern inline uint16 Distab17_getNumberOfBytesFromECU(CONST_DEF tD17EventConfig* config);
/* ETASTEST    */ extern inline uint16 Distab17_getNumberOfBytesToECU(CONST_DEF tD17BypassReverseConfig* adrTabToECU);

/* ETASTEST    */ #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
/* ETASTEST    */ extern inline uint16 Distab17_getNumberOfBytesFromECULegacy(CONST_DEF tD17LegacyDistab* adrTabFromECU);
/* ETASTEST    */ extern inline uint16 Distab17_getNumberOfBytesToECULegacy(CONST_DEF tD17LegacyReverseDistab* adrTabToECU);
/* ETASTEST    */ #endif
#endif

#ifdef RTT_TEST
extern real32 D17_BypRTT_Sum[];
extern uint32 D17_BypRTT_Min[], D17_BypRTT_Max[], D17_BypRTT_CountNumber[], D17_BypRTT_Avg[];
extern uint16 D17_BypassFromEcuBytes[], D17_BypassToEcuBytes[];
#endif

#endif /*#ifdef D17_ENABLE_BYPASS_SUPPORT*/

#endif /* DISTAB17_PROCESS_H */
