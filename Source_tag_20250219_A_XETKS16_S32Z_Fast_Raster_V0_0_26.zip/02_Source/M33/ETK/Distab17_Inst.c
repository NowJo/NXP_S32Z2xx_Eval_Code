/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2022                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
/***************************************************************************//**
* \file  Distab17_Inst.c
* \brief file containing the definition of the Distab17 data structs

* All data structures needed for the ECU part of using the Distab17 are
* instantiated here.
*
* Note: no initialization is done here -- please either change the statement,
* locate in a cleared section or initialize explicitly if required.
*******************************************************************************/

#include "Distab17_Inst.h"
#include "ETK_SectionMacro.h"

PRE_SECTION_DATA(Distab17EventList, ".ETK_DisTab17_EventList")
VOLATILE_DEF
tD17EventList Distab17EventList /* = {} */;
POST_SECTION_DATA()

PRE_SECTION_DATA(Distab17EventConfigArea, ".ETK_DisTab17_EventConfigArea")
VOLATILE_DEF
uint8 Distab17EventConfigArea[D17_EVENT_CONFIG_AREA_SIZE];
POST_SECTION_DATA()

PRE_SECTION_DATA(Distab17EventOutputArea, ".ETK_DisTab17_EventOutputArea")
VOLATILE_DEF
uint8 Distab17EventOutputArea[D17_EVENT_OUTPUT_AREA_SIZE];
POST_SECTION_DATA()

#ifdef TRACE_SUPPORT
/*These triggers should be placed so that they are in a trace window */
/* Supplemental distab trigger is usually contiguous to the output
 * table so can be in the same trace window as the table
 */
PRE_SECTION_BSS(TraceTriggerSuD17, ".ETK_TraceTrigger")
VOLATILE_DEF uint32 TraceTriggerSuD17;
POST_SECTION_BSS()
/* the trace trigger is usually contiguous to a trace window */
PRE_SECTION_BSS(traceTrigger, ".ETK_TraceTrigger")
VOLATILE_DEF uint32 traceTrigger;
POST_SECTION_BSS()
#endif

#if (defined TRG_ON_RAM) || (defined ADV_RAM_HS_SUPPORTED)
    PRE_SECTION_BSS(RAM_INTERFACE, ".RAM_HsTrg_MemClass")
    VOLATILE_DEF
    tInterfaceOnRAM RAM_INTERFACE;
    POST_SECTION_BSS()
#endif

#ifdef D17_USE_VIRTUAL_TRIGGER
CONST_DEF
VOLATILE_DEF
#if (defined CPUCLASS_RH850_E2X) || (defined CPUCLASS_RH850_U2X)
tECUTriggerMap ECUTriggerMap[] = { { 550,14 },
                                    { 260,15 },
                                    { 451,16 },
                                    { 530,17 },
                                    { 556,18 },
                                    { 666,19 },
                                    { 1024,20 },
                                    { 2048,21 },
                                    { 4120,22 },
                                    { 4130,23 },
                                    { 4131,24 },
                                    { 4132,25 },
                                    { 4138,26 },
                                    { 4136,27 },
                                    { 4133,28 },
                                    { 16334,29 },
                                    { 366,30 },
                                    { 32768,31 },
                                    { 65535,32 } };
#else
#error *** Undefined D17 virtual trigger mapping ***
#endif

CONST_DEF tECUTriggerTable ECUTriggerTable = { sizeof(ECUTriggerMap) / sizeof(ECUTriggerMap[0]), &ECUTriggerMap };
#endif

#ifdef D17_ENABLE_BYPASS_SUPPORT

/**************************************************************************//**
* \var ServicePoint_Cfg[MAXNUM_ACTIVE_SERVICEPOINTS]
* \brief Instantiation of Service Based Bypass This config struct
*        will be written by Intecrio after set up of bypass experiment
*
******************************************************************************/

/**************************************************************************
* (ECU: read only, ETK: write only, A2L: n/a [ResWorkArea -- "SBB_RESOURCE_WORKING_AREA"])
***************************************************************************/
PRE_SECTION_DATA(D17_ServicePoint_Cfg, ".SBB_ConfigStruct_MemClass")
VOLATILE_DEF
tD17GlobalServicePointDescriptor D17_ServicePoint_Cfg = { 0 };
POST_SECTION_DATA()

/**************************************************************************
* (ECU: write only, ETK: read only, A2L: SBB_Data [EcuWrtblResWorkArea -- "SBB_ECU_WRITABLE_WORKING" ]
***************************************************************************/
PRE_SECTION_DATA(D17_SP_ControlVar, ".SBB_Crtl_Vars_MemClass")
VOLATILE_DEF
tD17ControlVars D17_SP_ControlVar[D17_MAXNUM_ACTIVE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()

/**************************************************************************
* (ECU: read only, ETK: write only, A2L: SBB_Cals [Adaptive -- "SBB DATA"])
***************************************************************************/
#ifndef D17_SBB_ASCETBUILD

PRE_SECTION_DATA(P_D17_TimeOutPre, ".SBB_Crtl_Cals_MemClass")
VOLATILE_DEF
uint32 P_D17_TimeOutPre[D17_MAXNUM_ACTIVE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_D17_TimeOutPost, ".SBB_Crtl_Cals_MemClass")
VOLATILE_DEF
uint32 P_D17_TimeOutPost[D17_MAXNUM_ACTIVE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_D17_SrvPtEnabled, ".SBB_Crtl_Cals_MemClass")
VOLATILE_DEF
uint8 P_D17_SrvPtEnabled[D17_MAXNUM_ACTIVE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_D17_SrvPtResId, ".SBB_Crtl_Cals_MemClass")
VOLATILE_DEF
uint8 P_D17_SrvPtResId[D17_MAXNUM_AVAILABLE_SERVICEPOINTS + 1] = { 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_D17_ResIdSrvPt, ".SBB_Crtl_Cals_MemClass")
VOLATILE_DEF
uint16 P_D17_ResIdSrvPt[D17_MAXNUM_ACTIVE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_D17_DisableFctExec, ".SBB_Crtl_Cals_MemClass")
VOLATILE_DEF
uint8 P_D17_DisableFctExec[D17_MAXNUM_ACTIVE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()

/* TODO: real parameter or fake (adaptive) parameter -> ASCET!!!*/
#ifdef D17_BYPASS_DEBUG_ALLOW_NO_READ_ACTION_ID_CHECK
VOLATILE_DEF
uint8 P_D17_DisableRAIDCheck = 0;
#endif /* #ifdef D17_BYPASS_DEBUG_ALLOW_NO_READ_ACTION_ID_CHECK */

#endif /* #ifdef D17_SBB_ASCETBUILD */

/**************************************************************************
* (ECU: read/write, ETK: read only, A2L: RAM (measurements)
***************************************************************************/

/* Helpers
TODO: Clarify that these could be measured and be present in the A2L (that's
what we're going to do!) */

PRE_SECTION_BSS(D17_SP_OldBypassCounterPre, ".SBB_IRAM_BSS")
uint8 D17_SP_OldBypassCounterPre[D17_MAXNUM_ACTIVE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_OldBypassCounterPost, ".SBB_IRAM_BSS")
uint8 D17_SP_OldBypassCounterPost[D17_MAXNUM_ACTIVE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_StartWaitTimePre, ".SBB_IRAM_BSS")
uint32 D17_SP_StartWaitTimePre[D17_MAXNUM_ACTIVE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_StartWaitTimePost, ".SBB_IRAM_BSS")
uint32 D17_SP_StartWaitTimePost[D17_MAXNUM_ACTIVE_SERVICEPOINTS];
POST_SECTION_BSS()


#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
PRE_SECTION_BSS(D17_SP_Status_TimeOutPre, ".SBB_IRAM_BSS")
uint8 D17_SP_Status_TimeOutPre[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Status_TimeOutPost, ".SBB_IRAM_BSS")
uint8 D17_SP_Status_TimeOutPost[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Status_ServicePointEnabled, ".SBB_IRAM_BSS")
uint8 D17_SP_Status_ServicePointEnabled[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Status_FunctionExecution, ".SBB_IRAM_BSS")
uint8 D17_SP_Status_FunctionExecution[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
PRE_SECTION_BSS(D17_SP_Timestamp_Trigger_Pre, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_Trigger_Pre[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Timestamp_Trigger_Post, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_Trigger_Post[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Timestamp_StartCopyECUData_Pre, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_StartCopyECUData_Pre[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Timestamp_StartCopyECUData_Post, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_StartCopyECUData_Post[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Timestamp_BypassAnswer_Pre, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_BypassAnswer_Pre[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Timestamp_BypassAnswer_Post, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_BypassAnswer_Post[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Timestamp_BypassDataCopied_Pre, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_BypassDataCopied_Pre[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()

PRE_SECTION_BSS(D17_SP_Timestamp_BypassDataCopied_Post, ".SBB_IRAM_BSS")
uint32 D17_SP_Timestamp_BypassDataCopied_Post[D17_MAXNUM_AVAILABLE_SERVICEPOINTS];
POST_SECTION_BSS()
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT

PRE_SECTION_DATA(D17_SBB_State_IsFirstServicePoint, ".SBB_IRAM_DATA")
uint8 D17_SBB_State_IsFirstServicePoint = 1;
POST_SECTION_DATA()

PRE_SECTION_DATA(D17_SBB_State_IsETargetDetected, ".SBB_IRAM_DATA")
uint8 D17_SBB_State_IsETargetDetected = 0;
POST_SECTION_DATA()

PRE_SECTION_DATA(D17_SBB_State_RAIDWaitLoops, ".SBB_IRAM_DATA")
uint32 D17_SBB_State_RAIDWaitLoops = 0;
POST_SECTION_DATA()

PRE_SECTION_DATA(D17_SBB_State, ".SBB_IRAM_DATA")
enum D17_SBB_Enable_State D17_SBB_State = INACTIVE;
POST_SECTION_DATA()

PRE_SECTION_DATA(D17_SBB_State_StructureVersion, ".SBB_IRAM_DATA")
enum D17_SBB_Structure_Version D17_SBB_State_StructureVersion = D17_SBB_Structure_Version_NONE;
POST_SECTION_DATA()

PRE_SECTION_DATA(D17_SBB_State_StructureType, ".SBB_IRAM_DATA")
enum D17_SBB_Structure_Type D17_SBB_State_StructureType = D17_SBB_Structure_Type_DYNAMIC;
POST_SECTION_DATA()

PRE_SECTION_DATA(D17_SBB_State_FeatureMode, ".SBB_IRAM_DATA")
enum D17_SBB_Feature_Mode D17_SBB_State_FeatureMode = D17_SBB_Mode_BASIC;
POST_SECTION_DATA()

/**************************************************************************
* ECU: read only, ETK: write only on WP, A2L: CAL_PARAM (parameters)
***************************************************************************/

VOLATILE_DEF
enum D17_SBB_State_Request P_D17_SBB_Enable = ENABLE_NOW;

#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

#endif /*#ifdef D17_ENABLE_BYPASS_SUPPORT*/

