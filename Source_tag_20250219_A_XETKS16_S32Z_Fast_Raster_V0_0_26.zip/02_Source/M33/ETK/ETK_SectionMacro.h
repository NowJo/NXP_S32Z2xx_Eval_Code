/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2022                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */


/* ======================================================================================= *
 This file defines the format needed to decalre what section/location that a variable is 
 placed inthe build.

 BSS, Data, and Read Only data sections are required for RefSys builds.

 It is best to have this variable passed in from the makefile/build with GNU --and most 
 compilers-- you would use "-D" so that -DGNU_COMPILER would be pased in on the 
 command line with the compiler.

 The "PRE_" and "POST_" section macros are used in the code around each variable and are 
 require to follow this nameing convention so that it is portable.

 Note: __INTELLISENSE__ is needed for using an editor like Visual Studio that does not 
 recognise the "pragma" definition


 SOURCE CODE EXAMPLE:

PRE_SECTION_BSS("IRAM_measure_variables")
volatile etas_uint32 M_Prescaler_LED_900;
POST_SECTION_BSS()

PRE_SECTION_RODATA("measure_parameters")
volatile const etas_uint32 P_Prescaler_LED_900 = 5;
POST_SECTION_RODATA()

Non editable MACRO structures (that's used in the source code):
// PRE_SECTION_BSS( name) and POST_SECTION_BSS()
// PRE_SECTION_DATA( name) and POST_SECTION_DATA()
// PRE_SECTION_RODATA( name) and POST_SECTION_RODATA()

 * ======================================================================================= */

#ifndef _SECTION_MACRO_H_
#define _SECTION_MACRO_H_

#include "ETK_Common.h"

#ifdef __TI_COMPILER_VERSION__
#ifndef CCS_COMPILER
#define CCS_COMPILER 
#endif
#endif

//Check only one compiler is active
#if ((defined(GHS_COMPILER)||defined(GREENHILLS_COMPILER))&&(defined(GNU_COMPILER)||defined(HIGHTEC_COMPILER)||defined(TASKING_COMPILER)||defined(WINDRIVER_COMPILER)||defined(CCS_COMPILER)))||\
    (defined(GNU_COMPILER)&&(defined(HIGHTEC_COMPILER)||defined(TASKING_COMPILER)||defined(WINDRIVER_COMPILER)||defined(CCS_COMPILER)))||\
    (defined(HIGHTEC_COMPILER)&&(defined(TASKING_COMPILER)||defined(WINDRIVER_COMPILER)||defined(CCS_COMPILER)))||\
    (defined(TASKING_COMPILER)&&(defined(WINDRIVER_COMPILER)||defined(CCS_COMPILER)))||\
    (defined(WINDRIVER_COMPILER)&&defined(CCS_COMPILER))

#error "Only one compiler can be specified as active! choices are GREENHILLS_COMPILER, WINDRIVER_COMPILER, TASKING_COMPILER, HIGHTEC_COMPILER, CCS_COMPILER, and GNU_COMPILER"
#endif


/*-----------------------------------------------------------------------*/
/* Macros for getting section information from the defined sections below*/
#define GetSectionAddrStart( sec_name ) ((etas_uint32)(& __start_##sec_name ))
#define GetSectionAddrEnd( sec_name )   ((etas_uint32)((& __stop_##sec_name )-1))
#define GetSectionSize( sec_name )      ((etas_uint32)((etas_uint32)(& __stop_##sec_name )-(etas_uint32)(& __start_##sec_name )))


/*-----------------------------------------------------------------------------------*/
/* Based on the compiler that is used we setup the macros that define the sections  */
/*-----------------------------------------------------------------------------------*/
#if defined(GREENHILLS_COMPILER)||defined(GHS_COMPILER)
/* ======================================================================================= */
// GREEN HILLS
#ifdef __INTELLISENSE__
#define PRAGMA(x) 
#else
#define PRAGMA(x) _Pragma(#x)
#endif
#define SECTION(type, name) PRAGMA(ghs section type = name)

#define PRE_SECTION_BSS(var_name,  name) SECTION(bss, name)
#define POST_SECTION_BSS() SECTION(bss, default)
#define PRE_SECTION_DATA(var_name,  name) SECTION(data, name)
#define POST_SECTION_DATA() SECTION(data, default)
#define PRE_SECTION_RODATA(var_name,  name) SECTION(rodata, name)
#define POST_SECTION_RODATA() SECTION(rodata, default)

#elif defined(DS_COMPILER)
/* Design Studio for NXP */
#ifdef __INTELLISENSE__
#define PRAGMA(x) 
#else
#define PRAGMA(x) _Pragma(#x)
#endif

#define SECTION(type,name) __attribute__((section(name)))

#define PRE_SECTION_BSS(var_name, x) SECTION(bss, x)
#define POST_SECTION_BSS()
#define PRE_SECTION_DATA(var_name, x) SECTION(data, x)
#define POST_SECTION_DATA()
#define PRE_SECTION_RODATA(var_name, x) SECTION(rodata, x)
#define POST_SECTION_RODATA()


#elif defined(GNU_COMPILER)
// =======================================================================================
// GNU

#ifdef __INTELLISENSE__
#define PRAGMA(x) 
#else
#define PRAGMA(x) _Pragma(#x)
#endif
#define SECTION(type, name) __attribute__((section(name)))

#define PRE_SECTION_BSS(var_name,  name) SECTION(bss, name)
#define POST_SECTION_BSS() SECTION(bss, default)
#define PRE_SECTION_DATA(var_name,  name) SECTION(data, name)
#define POST_SECTION_DATA() SECTION(data, default)
#define PRE_SECTION_RODATA(var_name,  name) SECTION(rodata, name)
#define POST_SECTION_RODATA() SECTION(rodata, default)


#elif defined(HIGHTEC_COMPILER)
// =======================================================================================
// HIGHTECH

#ifdef __INTELLISENSE__
#define PRAGMA(x) 
#else
#define PRAGMA(x) _Pragma(#x)
#endif
#define SECTION(type, name, algn) PRAGMA(section name type algn)

#define PRE_SECTION_BSS(var_name,  name) SECTION(aw, name, 4)
#define POST_SECTION_BSS() SECTION( , , )
#define PRE_SECTION_DATA(var_name,  name) SECTION(aw, name, 4)
#define POST_SECTION_DATA() SECTION( , , )
#define PRE_SECTION_RODATA(var_name,  name) SECTION(aw, name, 4)
#define POST_SECTION_RODATA() SECTION( , , )

//Make sure prefix is removed
#ifdef SECTION_PREFIX
#undef SECTION_PREFIX
#endif

#ifdef ASM_INST
#undef ASM_INST
//Need a different format for hightec
#define ASM_INST __asm__
#endif


#elif defined(TASKING_COMPILER)
// =======================================================================================
// TASKING
#ifdef __INTELLISENSE__
#define PRAGMA(x) 
#else
#define PRAGMA(x) _Pragma(#x)
#endif
#define SECTION(type, name) PRAGMA(section type name)

#define PRE_SECTION_BSS(var_name,  name) SECTION(all, name) PRAGMA(noclear) // If needed BSS without "noclear" we could create another PRE_SECTION_BSS_NOCLEAR( name). Then for other compilers it would be the same as PRE_SECTION_BSS( name).
#define POST_SECTION_BSS() PRAGMA(clear) SECTION( , ) // If needed BSS without "noclear" we could create another POST_SECTION_BSS_NOCLEAR().  Then for other compilers it would be the same as POST_SECTION_BSS().
#define PRE_SECTION_DATA(var_name,  name) SECTION(all, name)
//#define POST_SECTION_DATA() SECTION( , )
#define POST_SECTION_DATA() ;
#define PRE_SECTION_RODATA(var_name,  name) SECTION(all, name)
//#define POST_SECTION_RODATA() SECTION( , )
#define POST_SECTION_RODATA() ;


#elif defined(WINDRIVER_COMPILER)
// =======================================================================================
// WINDRIVER
#ifdef __INTELLISENSE__
#define PRAGMA(x) 
#else
#define PRAGMA(x) _Pragma(#x)
#endif
#define SECTION(type, name, attr) PRAGMA(section type name name attr)

#define PRE_SECTION_BSS(var_name,  name) SECTION(DATA, name, far-absolute RW) PRAGMA(use_section DATA variable)
#define POST_SECTION_BSS() SECTION( , , )
#define PRE_SECTION_DATA(var_name,  name) SECTION(DATA, name, far-absolute RW) PRAGMA(use_section DATA variable)
#define POST_SECTION_DATA() SECTION( , , )
#define PRE_SECTION_RODATA(var_name,  name) SECTION(DATA, name, far-absolute RW) PRAGMA(use_section DATA variable)
#define POST_SECTION_RODATA() SECTION( , , )

#elif defined(__TI_COMPILER_VERSION__)||defined(CCS_COMPILER)
// =======================================================================================
// TI Code Composer Studio
#ifdef __INTELLISENSE__
#define PRAGMA(x) 
#else
#define PRAGMA(x) _Pragma(#x)
#endif
#ifndef STRINGFY
#define STRINGFY(A) #A
#endif
#define MSECTION(X,Y) PRAGMA(DATA_SECTION(X,Y))


#define PRE_SECTION_BSS(var_name, name) MSECTION(var_name, name )
#define POST_SECTION_BSS() 
#define PRE_SECTION_DATA(var_name, name) MSECTION(var_name, name )
#define POST_SECTION_DATA() 
#define PRE_SECTION_RODATA(var_name, name) MSECTION(var_name, name)
#define POST_SECTION_RODATA() 

#else
#error "Compiler must be specified in the build! Best done on the compile option '-D'.  Choices are WINDRIVER_COMPILER, TASKING_COMPILER, HIGHTEC_COMPILER, and GNU_COMPILER"
#endif


/*-----------------------------------------------------------------------*/
/* Because some compilers do not like starting the name with non-alpha 
 * numerics we prefer that the section name be defined here and use these defines 
 * --not hard coded names-- in each source file.
 * In some cases like HighTech or a real OS like QNX the prefix of the section name 
 * needs to be an alpha string and not a dot '.' or underscore '_'
 */

//Code validation
#define SECTION_ETK_Code_checkMemClass      "ETK_Code_checkMemClass"
#define SECTION_code_checkMemClassRam       "code_checkMemClassRam"
#define SECTION_code_checkMemClassEMURam    "code_checkMemClassEMURam"
#define SECTION_ETK_Presence_checkMemClass  "ETK_Presence_checkMemClass"
#define SECTION_ETK_EPK_DATA                "ETK_EPK_DATA"

#define SECTION_ETK_DataFreeze_Mailbox      "ETK_DataFreeze_Mailbox"
#define SECTION_DataFreeze_Validate_Pattern "DataFreeze_Validate_Pattern"
#define SECTION_DataFreeze_Validate_Pattern_Save_in_Code "DataFreeze_Validate_Pattern_Save_in_CodeSpace"

//ETK page switch handling
#define SECTION_ETK_PageSwitch_MemClass     "ETK_PageSwitch_MemClass"
#define SECTION_ETK_OMDTable_MemClass       "ETK_OMDTable_MemClass"

//Coldstart sections
#define SECTION_ETK_ColdStart_MemClass      "ETK_ColdStart_MemClass"
#define SECTION_coldstart_parameters        "coldstart_parameters"

//Distab13 Specific
#define SECTION_ETK_DisTab13_MemClass         "ETK_DisTab_MemClass"
#define SECTION_ETK_DisTab13_DAQChnl_MemClass "ETK_DAQChnl_MemClass"

//Distab17 Specific 
#define SECTION_ETK_DisTab17_EventList        "ETK_DisTab17_EventList"
#define SECTION_ETK_DisTab17_EventConfigArea  "ETK_DisTab17_EventConfigArea"
#define SECTION_ETK_DisTab17_EventOutputArea  "ETK_DisTab17_EventOutputArea"



#endif //_SECTION_MACRO_H_
