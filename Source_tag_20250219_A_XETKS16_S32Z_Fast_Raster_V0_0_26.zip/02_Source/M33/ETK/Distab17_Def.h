/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
/***************************************************************************//**
* \file  Distab17_Def.h
* \brief file containing the type definitions for distab data types
*
* This file contains the base type definitions for all distab based ECU routines
* supporting measurement and bypass solutions supported by ETAS tools
*******************************************************************************/

/* TODO: All that is here is effectively 1-byte aligned, or is it?
         -> if not, we'd have to introduce special structures (this time really
            one byte aligned) that contain the individual configuration entries
            packed into a 32-bit field of the containing struct.
*/

#ifndef DISTAB17_DEF_H
#define DISTAB17_DEF_H

#include "a_std_type.h"
#include "Distab17_Cfg.h"
#include "base.h"


/***************************************************************************//**
* \typedef tD17EventOutputHeader
* \brief This datatype is the header for a particular event's output area
*
* The Distab17 event output area contains the ECU status and the trigger flag,
* followed by the measurement data.
*
* This entry is written by the ECU and read by the ETK system.
*
* If D17_ETK_TRIGGER_FLAG_CLEAR is set, the ETK has to clear the trigger
* flag before the ECU issues another trigger -- this requires ECU read and
* ETK write access.
*/
/** \struct D17EventOutputHeader
* \brief This structure is the header for a particular event's output area
*
* The Distab17 event output area contains the ECU status and the trigger flag,
* followed by the measurement data.
*
* This entry is written by the ECU and read by the ETK system.
*
* If D17_ETK_TRIGGER_FLAG_CLEAR is set, the ETK has to clear the trigger
* flag before the ECU issues another trigger -- this requires ECU read and
* ETK write access.
*******************************************************************************/
typedef struct D17EventOutputHeader
{
    uint32 EcuStatus; /**< ECU status, set to (! 0) by the ECU when processing this event */
    uint32 TriggerFlag; /**< Trigger Flag, set to (! 0) by the ECU to indicate new data for this event */

    void* FirstEntry; /**< Start of the measurement data */
} tD17EventOutputHeader;

/***************************************************************************//**
* \typedef tD17EventConfigHeader
* \brief This datatype describes the configuration for a particular event
*
* A Distab17 event configuration contains the version number, a change indicator,
* and the (possibly virtual) trigger to be used (ref. "ECU_ID" AML entry).
*
* This entry is written by the ETK system and read by the ECU.
*/
/** \struct D17EventConfigHeader
* \brief This structure describes the generic configuration for a particular event
*
* A Distab17 event configuration contains the version number, a change indicator,
* and the (possibly virtual) trigger to be used (ref. "ECU_ID" AML entry).
*
* This entry is written by the ETK system and read by the ECU.
*******************************************************************************/
typedef struct D17EventConfigHeader
{
    uint8 Change; /**< Incremented whenever this configuration has been changed */
    uint8 Config; /**< Defines some properties of the event. Bit 0 defines if TDM is used or not. */
    uint16 Trigger; /**< The (possibly virtual) trigger to be set after the ECU has provided the data */
    tD17EventOutputHeader* Output; /**< The start of the output area for this event */
} tD17EventConfigHeader;

/***************************************************************************//**
* \typedef tD17EventConfig
* \brief This datatype describes an event in case TDM is not used
*
* In addition to the generated event configuration header, this datatype also
* contains the number of measurement variables of 8-, 4-, 2-, and 1-byte,
* followed by the respective source addresses.
*
* This entry is written by the ETK system and read by the ECU.
*/
/** \struct D17EventConfig
* \brief This datatype describes the configuration of an event in case TDM is not used
*
* In addition to the generated event configuration header, this datatype also
* contains the number of measurement variables of 8-, 4-, 2-, and 1-byte,
* followed by the respective source addresses.
*
* This entry is written by the ETK system and read by the ECU.
*******************************************************************************/
typedef struct D17EventConfig
{
    tD17EventConfigHeader Header; /**< The generic event config header */

    uint16 NoOfVal_8; /**< number of 8 byte (64 bit) values in the Distab */
    uint16 NoOfVal_4; /**< number of 4 byte (32 bit) values in the Distab */
    uint16 NoOfVal_2; /**< number of 2 byte (16 bit) values in the Distab */
    uint16 NoOfVal_1; /**< number of 1 byte (8 bit) values in the Distab */

    void* FirstEntry; /**< Start of the measurement data, this is used to get the start address of the table since 64bit would actually be 64bits instead of the 32bits that INCA uses */
} tD17EventConfig;

/***************************************************************************//**
* \typedef tD17EventList
* \brief This datatype describes all available events
*
* While the header contains currently applicable configuration items, each
* member of the event configuration pointer array describes an event in detail.
*
* This entry is written by the ETK system and read by the ECU.
*/
/** \struct D17EventList
* \brief This structure describes all available events
*
* While the header contains currently applicable configuration items, each
* member of the event configuration pointer array describes an event in detail.
*
* This entry is written by the ETK system and read by the ECU.
*******************************************************************************/
typedef struct D17EventList
{
    uint8 Version; /**< The Distab version number, has to be 17 */
    uint8 Change; /**< Incremented modulo 0xFF whenever the event configuration changes */
    uint8 First; /**< Set to the index of the first active event config pointer */
    uint8 Number; /**< The number of currently active events */

    uint32 Config[D17_MAX_EVENT_NO]; /**< One entry for each event */
} tD17EventList;

#if (defined TRG_ON_RAM) || (defined HS_ON_RAM)
typedef struct InterfaceOnRAM
{
#ifdef HS_ON_RAM
    uint32 HS_IN; // Write by XETK
    uint32 HS_OUT; // Write by ECU
#endif
#ifdef TRG_ON_RAM
    uint32 Trg32; // Trigger 1..32
    uint32 Trg64; // Trigger 33..64
    uint32 Trg96; // Trigger 65..96
    uint32 Trg128; // Trigger 97..128
    uint32 Trg160; // Trigger 129..160
    uint32 Trg192; // Trigger 161..192
    uint32 Trg224; // Trigger 193..224
    uint32 Trg256; // Trigger 225..256
#endif
} tInterfaceOnRAM;
#endif

#ifdef D17_USE_VIRTUAL_TRIGGER
/***************************************************************************//**
* \typedef tETK_Trigger_Map
* \brief This datatype describes a mapping from virtual to actual triggers
*
* This entry is constant.
*/
/** \struct ETKTriggerMap
* \brief This structure describes a mapping from virtual to actual triggers
*
* This entry is constant.
*******************************************************************************/
typedef struct ECUTriggerMap
{
    uint16 ECU_ID; /**< The ID specified in the A2L file */
    uint16 TriggerNumber; /**< The actual trigger issued by the ECU, also specified in the A2L file */
} tECUTriggerMap;

/***************************************************************************//**
* \typedef tETK_Trigger_Table
* \brief This datatype describes the number of mappings from virtual to actual triggers
*
* This entry is constant.
*/
/** \struct ETK_Trigger_Table
* \brief This structure describes the number of mappings from virtual to actual triggers
*
* This entry is constant.
*******************************************************************************/
typedef struct ECUTriggerTable
{
    uint8 Entries; /**< The number of entries in the table */
    tECUTriggerMap* Table; /**< Pointer to a table containing the mapping */
} tECUTriggerTable;
#endif

enum D17_Result
{
    D17_EVENT_NOT_ACTIVE = 0x00, /**< possible return values for distab17Process(): event not active */
    D17_EVENT_UNSUPPORTED_VERSION = 0x01, /**< possible return values for distab17Process(): version field contains unexpected and unsupported value */
    D17_EVENT_INVALID_OUTPUT_TABLE = 0x02, /**< possible return values for distab17Process(): the pointer to the output table is required, but not set */
    D17_DATA_ACQUISITION_CONSISTENCY_ERROR = 0x03,
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    D17_DATA_TABLE_NOT_ACTIVE = 0x04,
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/
    D17_DATA_ACQUISITION_SUCCESS = 0xFF, /**< possible return values for distab17Process(): Distab was successfully processed */
};

#ifdef D17_ENABLE_BYPASS_SUPPORT

/***************************************************************************//**
* \typedef  tD17BypassReverseData
* \brief Data type to describe the data table used by the
* D17 based bypass to write back values from the RP system
*******************************************************************************/
/***************************************************************************//**
* \struct tD17BypassReverseData
* \brief Data type to describe the data table used by the
* D17 based bypass to write back values from the RP system
*******************************************************************************/

typedef struct D17BypassReverseData
{
    uint8 BypCtr; /**< an uneven counter specifies access to the first toggle buffer */
    uint8 Reserved_1;
    uint16 TableLength; /**< the length of one toggle buffer */

    uint8 FirstValue; /**< Entry for the first value in the first toggle buffer */
} tD17BypassReverseData;

/***************************************************************************//**
* \typedef  tD17BypassReverseConfig
* \brief Data type to describe an extended Distab13 header structure used by the
* D17 based bypass to write back values from the RP system
*
* The D17 bypass introduces an extended Distab13 header to allow the
* bypass to write back packed bits. Packed bits are supported for 32bit, 16bit
* and 8bit masks.
* The structure ancontains the active byte, the number of 4,2 and 1 byte containing
* packed bits and the number of 8,4,2 and 1 byte values addressed by the distab
*/
/** \struct D17BypassReverseConfig
* \brief struct to describe an extended Distab13 header used by the
* D17 based bypass to write back values from the RP system
*
* The D17 bypass introduces an extended Distab13 header to allow the
* bypass to write back packed bits. Packed bits are supported for 32bit, 16bit
* and 8bit masks.
* The structure ancontains the active byte, the number of 4,2 and 1 byte containing
* packed bits and the number of 8,4,2 and 1 byte values addressed by the distab
*******************************************************************************/

typedef struct D17BypassReverseConfig
{
    /** \var Change
    * \brief Change byte for the Distab */
    uint8 Change; /**< Change byte for the Distab */
    uint8 Reserved_1;
    uint16 NoOfVal_8; /**< number of 8 byte (64 bit) values in the Distab */
    tD17BypassReverseData* DataTable;

    uint16 NoOfVal_4; /**< number of 4 byte (32 bit) values in the Distab */
    uint16 NoOfBits_4; /**< number of bits packed in 4 byte (32 bit) values in the Distab */
    uint16 NoOfVal_2; /**< number of 2 byte (16 bit) values in the Distab */
    uint16 NoOfBits_2; /**< number of bits packed in 2 byte (16 bit) values in the Distab */
    uint16 NoOfVal_1; /**< number of 1 byte (8 bit) values in the Distab */
    uint16 NoOfBits_1; /**< number of bits packed in 1 byte (8 bit) values in the Distab */

    void* FirstAddress; /**< first address to be bypassed */
} tD17BypassReverseConfig;

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT

typedef struct D17LegacyDistab
{
    uint8 Active;
    uint8 Reserved[3];
    uint8 NoOfVal_8;
    uint8 NoOfVal_4;
    uint8 NoOfVal_2;
    uint8 NoOfVal_1;

    void* FirstAddress;
} tD17LegacyDistab;

typedef struct D17LegacyReverseDistab
{
    uint8 Active;
    uint8 NoOfBits_4;
    uint8 NoOfBits_2;
    uint8 NoOfBits_1;
    uint8 NoOfVal_8;
    uint8 NoOfVal_4;
    uint8 NoOfVal_2;
    uint8 NoOfVal_1;

    void* FirstAddress;
} tD17LegacyReverseDistab;

/* D13 Reverse bypass data table with an 8 byte offset. Can be used for SBBv3.0 and SBBv2.0. */
typedef struct D17LegacyBypassReverseData
{
    uint8 BypCtr; /**< an uneven counter specifies access to the first toggle buffer */
    uint8 Reserved_1;
    uint8 Reserved_2;
    uint8 Reserved_3;
    uint8 Reserved_4;
    uint8 Reserved_5;
    uint8 Reserved_6;
    uint8 Reserved_7;

    uint8 FirstValue; /**< Entry for the first value in the first toggle buffer */
} tD17LegacyBypassReverseData;


/* Service point configuration structure compatible with SBBv2.0 and SBBv3.0. */
typedef struct D17LegacyServicePointDescriptor
{
    struct
    {
#if defined PROCESSOR_MEM_TYPE_BIG_ENDIAN
        uint8 Reserved_3 : 4;
        uint8 Trigger_Mode_Post : 1;
        uint8 Reserved_2 : 1;
        uint8 Trigger_Mode_Pre : 1;
        uint8 Reserved_1 : 1;
#elif defined PROCESSOR_MEM_TYPE_LITTLE_ENDIAN
        uint8 Reserved_1 : 1;
        uint8 Trigger_Mode_Pre : 1;
        uint8 Reserved_2 : 1;
        uint8 Trigger_Mode_Post : 1;
        uint8 Reserved_3 : 4;
#else
#error Please define PROCESSOR_MEM_TYPE_BIG_ENDIAN or PROCESSOR_MEM_TYPE_LITTLE_ENDIAN
#endif
    } Config;
    uint8 TrigNumPre;
    uint8 MaxValPre; /**< maximum number of missed bypass responses in the PRE section until error callback routine is triggered (if configured); can be set in the Intecrio GUI */
    uint8 RAIDPre; /**< Read Action Id for the PRE section */
    uint8 ErrCfg; /**< error configuration for Service Point; currently defined bits: 0x01 execute callback routine in PRE; 0x10 execute callback routine in POST*/
    uint8 TrigNumPost;
    uint8 MaxValPost; /**< maximum number of missed bypass responses in the POST section until error callback routine is triggered (if configured); can be set in the Intecrio GUI */
    uint8 RAIDPost; /**< Read Action Id for the POST section */

    uint32* TrgFlgAdrPre;
    CONST_DEF tD17LegacyDistab* AdrTabFromECUPre;
    void* DatTabFromECUPre;
    CONST_DEF tD17LegacyReverseDistab* AdrTabToECUPre;
    tD17BypassReverseData* DatTabToECUPre;
    CONST_DEF void* DefaultValTabToECUPre;
    uint32* TrgFlgAdrPost;
    CONST_DEF tD17LegacyDistab* AdrTabFromECUPost;
    void* DatTabFromECUPost;
    CONST_DEF tD17LegacyReverseDistab* AdrTabToECUPost;
    tD17BypassReverseData* DatTabToECUPost;
    CONST_DEF void* DefaultValTabToECUPost;
} tD17LegacyServicePointDescriptor;

#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/


/* Service point configuration structure compatible with SBBv3.1. */
typedef struct D17ServicePointDescriptor
{
    uint8 Reserved_1;
    uint8 Reserved_2;
    uint8 MaxValPre; /**< maximum number of missed bypass responses in the PRE section until error callback routine is triggered (if configured); can be set in the Intecrio GUI */
    uint8 RAIDPre; /**< Read Action Id for the PRE section */
    uint8 ErrCfg; /**< error configuration for Service Point; currently defined bits: 0x01 execute callback routine in PRE; 0x10 execute callback routine in POST*/
    uint8 Reserved_3;
    uint8 MaxValPost; /**< maximum number of missed bypass responses in the POST section until error callback routine is triggered (if configured); can be set in the Intecrio GUI */
    uint8 RAIDPost; /**< Read Action Id for the POST section */

    uint32* TrgFlgAdrPre;
    CONST_DEF tD17EventConfig* AdrTabFromECUPre; /**< Distab address for sending data from the ECU to the bypass in the PRE section of a service point */
    CONST_DEF tD17BypassReverseConfig* AdrTabToECUPre; /**< reverse Distab address for receiving data from the bypass in the PRE section of a service point */
    tD17BypassReverseData* DatTabToECUPre; /**< (HBB) data table address for receiving data from the bypass in the PRE section of a service point */
    uint32* TrgFlgAdrPost;
    CONST_DEF tD17EventConfig* AdrTabFromECUPost; /**< Distab address for sending data from the ECU to the bypass in the POST section of a service point */
    CONST_DEF tD17BypassReverseConfig* AdrTabToECUPost; /**< reverse Distab address for receiving data from the bypass in the POST section of a service point */
} tD17ServicePointDescriptor;


/* Service point configuration structure union containing the SBBv3.1, SBBv3 and SBBv2 structures together.  */
typedef union D17GlobalServicePointDescriptor
{

    tD17ServicePointDescriptor V31[D17_MAXNUM_ACTIVE_SERVICEPOINTS];
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    tD17LegacyServicePointDescriptor V3_V2[D17_MAXNUM_ACTIVE_SERVICEPOINTS];
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

} tD17GlobalServicePointDescriptor;


typedef struct D17SBBMode
{
#if defined PROCESSOR_MEM_TYPE_BIG_ENDIAN
    uint8 FeatureMode : 2;
    uint8 StructureType : 2;
    uint8 StructureVersion : 4;
#elif defined PROCESSOR_MEM_TYPE_LITTLE_ENDIAN
    uint8 StructureVersion : 4;
    uint8 StructureType : 2;
    uint8 FeatureMode : 2;
#else
#error Please define PROCESSOR_MEM_TYPE_BIG_ENDIAN or PROCESSOR_MEM_TYPE_LITTLE_ENDIAN
#endif
} tD17SBBMode;

/***************************************************************************//**
* \typedef  tD17ControlVars
* \brief ram data type to control a service based bypass service point
*
* A structure of variables written by the service based bypass service
* that can be made available for measurement also
*/

/** \struct D17ControlVars
* \brief ram struct to control a service based bypass service point
*
* A structure of variables written by the service based bypass service
* that can be made available for measurement also
*******************************************************************************/
typedef struct D17ControlVars
{
    /** \var Control
    * \brief control byte; currently defined bits: 0x01 time out pre; 0x02 time out post*/
    uint8 Control;
    /** \var ErrCntPre
    * \brief error counter for the PRE section of a service point */
    uint8 ErrCntPre;
    /** \var ErrCntPost
    * \brief error counter for the POST section of a service point */
    uint8 ErrCntPost;
    /** \var FailedTriggerCounter
    * \brief counter for number of failed triggers */
    uint8 FailedTriggerCounter;
} tD17ControlVars;

enum D17_SBB_SP_Type
{
    D17_SP_TYPE_PRE,
    D17_SP_TYPE_POST,
};

enum D17_SBB_Result
{
    /* Bits 0:1 : general condition */
    D17_SP_ACTIVE = 0x00,
    D17_SP_INVALID_SBB_VERSION = 0x01,
    D17_SP_NO_RESID = 0x02,
    D17_SP_DISABLED = 0x03,

    /* Bits 2:4 : ECU -> RP condition */
    D17_SP_NO_DATA_FROM_ECU = 0x04,
    D17_SP_FROM_ECU_ACQUISITION_ERROR = 0x08,
    D17_SP_FROM_ECU_INTERRUPTED = 0x0C,
    D17_SP_FROM_ECU_RAID_TIMEOUT = 0x10,
    D17_SP_FROM_ECU_SUCCESS = 0x14,
    /* new: for example if there's no valid TRIGIDVAL in the SBBv2 case
    (more than 32 active service points) */
    D17_SP_FROM_ECU_INVALID_CONFIG = 0x18,

    /* Bits 5:7 : RP -> ECU condition */
    D17_SP_NO_DATA_TO_ECU = 0x20,
    D17_SP_TO_ECU_INVALID_DATATABLE = 0x40,
    D17_SP_TO_ECU_ERROR_CALLBACK_INVOKED = 0x60,
    D17_SP_TO_ECU_TIMEOUT_WHILE_WAITING_FOR_BYPASS_COUNTER = 0x80,
    D17_SP_TO_ECU_BYPASS_NOT_ACTIVE = 0xA0,
    D17_SP_TO_ECU_NEW_DATA = 0xC0,
    D17_SP_TO_ECU_DATA_ACQUISITION_ERROR = 0xE0,
};

enum D17_SBB_ControlStates
{
    D17_SP_TIMEOUT_PRE_SET = 0x01, /* timeout for pre ECU proc part has been reached */
    D17_SP_TIMEOUT_POST_SET = 0x02, /* timeout for post ECU proc part has been reached */
    D17_SP_FAILEDTRIGGER_PRE = 0x04, /* triggering the ETK failed in PRE section */
    D17_SP_FAILEDTRIGGER_POST = 0x08, /* triggering the ETK failed in POST section */
};

enum D17_SBB_ErrorConfig
{
    D17_SP_PRE_CALLBACK_ACTIVE = 0x01, /* define for calling call back pre routine */
    D17_SP_POST_CALLBACK_ACTIVE = 0x10, /* define for calling call back post routine */
};

enum D17_SBB_Structure_Version
{
    D17_SBB_Structure_Version_NONE = 0,
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2
    D17_SBB_Structure_Version_2 = 2,
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2*/
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3
    D17_SBB_Structure_Version_3 = 3,
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3*/
    D17_SBB_Structure_Version_31 = 4,
    D17_SBB_Structure_Version_21 = 5,
};

#define DISABLE_ECU_PROCESS (! ENABLE_ECU_PROCESS)
#define SP_INACTIVE 0x00  /* define for service points that are not prepared for */
/* use in the bypass experiment, used in */
/* SrvPtResId[] */

#define SP_ACTIVE (! SP_INACTIVE)

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT

enum D17_SBB_Structure_Type
{
    D17_SBB_Structure_Type_DYNAMIC = 0,
    D17_SBB_Structure_Type_STATIC = 1,
};

enum D17_SBB_Feature_Mode
{
    D17_SBB_Mode_BASIC = 0,
    D17_SBB_Mode_EXTENDED = 1,
    D17_SBB_Mode_SELECTED = 2,
};

enum D17_SBB_State_Request
{
    DISABLE,
    ENABLE_NOW,
    ENABLE_AFTER_RESET,
    DISABLE_SERVICE
};

enum D17_SBB_Enable_State
{
    INACTIVE,
    WAITING_FOR_ACTIVATION,
    WAITING_FOR_SETTING_OF_LABEL,
    WAITING_FOR_STIMDATA_AFTER_RESET,
    WAITING_FOR_STIMDATA,
    BYPASS_ACTIVE,
    BYPASS_TRIGGERED_NO_STIMDATA_USED,
    DISABLED
};

#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

#endif /*#ifdef D17_ENABLE_BYPASS_SUPPORT*/

#endif /* DISTAB17_DEF_H */
