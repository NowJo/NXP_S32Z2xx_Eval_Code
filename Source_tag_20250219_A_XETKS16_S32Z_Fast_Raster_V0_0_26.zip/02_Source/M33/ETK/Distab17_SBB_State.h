/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2022                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef DISTAB17_SBB_STATE_H
#define DISTAB17_SBB_STATE_H

#include "ETK_Integration_Cfg.h"
#include "Distab17_Cfg.h"
#include "Distab17_Processes.h"

#ifdef ASCET_PROJ
#include "base.h"
#else
#include "../target_specific.h"
#include "../base.h"
#endif

#if !defined(D17_SBB_ASCETBUILD)&&defined(D17_SBB_SUPPORT)
#include "SBB_module_ext.h"
#endif

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT

void Distab17_SBB_Init(void);
void Distab17_SBB_Config_Update(void);
void Distab17_SBB_State_Update(void);

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2
#define DISTAB17_IS_CONFIGURED_SBB_V2 \
    (D17_SBB_Structure_Version_2 == D17_SBB_State_StructureVersion)
#else
#define DISTAB17_IS_CONFIGURED_SBB_V2 (0)
#endif

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3
#define DISTAB17_IS_CONFIGURED_SBB_V3 \
    (D17_SBB_Structure_Version_3 == D17_SBB_State_StructureVersion)
#else
#define DISTAB17_IS_CONFIGURED_SBB_V3 (0)
#endif

#define DISTAB17_IS_CONFIGURED_SBB_V31 \
    (D17_SBB_Structure_Version_31 == D17_SBB_State_StructureVersion)

#define DISTAB17_IS_CONFIGURED_SBB_V21 \
    (D17_SBB_Structure_Version_21 == D17_SBB_State_StructureVersion)

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
#define DISTAB17_IS_CONFIGURED_SBB      \
    (DISTAB17_IS_CONFIGURED_SBB_V31 ||   \
     DISTAB17_IS_CONFIGURED_SBB_V21 ||   \
     DISTAB17_IS_CONFIGURED_SBB_V3 ||   \
     DISTAB17_IS_CONFIGURED_SBB_V2)
#else
#define DISTAB17_IS_CONFIGURED_SBB  DISTAB17_IS_CONFIGURED_SBB_V31 ||   \
     DISTAB17_IS_CONFIGURED_SBB_V21
#endif

#ifdef RTT_TEST
extern real32 D17_BypRTT_Sum[];
extern uint32 D17_BypRTT_Min[], D17_BypRTT_Max[], D17_BypRTT_CountNumber[], D17_BypRTT_Avg[];
extern uint16 D17_BypassFromEcuBytes[], D17_BypassToEcuBytes[];
#endif

#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

#endif /*#ifndef DISTAB17_SBB_STATE_H*/
