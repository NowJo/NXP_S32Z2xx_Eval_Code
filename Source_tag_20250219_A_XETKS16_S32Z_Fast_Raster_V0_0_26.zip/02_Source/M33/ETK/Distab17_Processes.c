/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

#include "Distab17_Processes.h"
#include "Distab17_Fct.h"
#include "Distab17_Inst.h" //traceTrigger
#include "target_specific.h" //Semaphore


#ifdef D17_ENABLE_BYPASS_SUPPORT

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
#include "Distab17_SBB_State.h"
#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

#ifndef D17_BYPASS_DEBUG_ALLOW_NO_READ_ACTION_ID_CHECK
#define ONE_BYTE_CLEARED(x)             \
    (! ((x & 0xFF000000ul) &&           \
        (x & 0x00FF0000ul) &&           \
        (x & 0x0000FF00ul) &&           \
        (x & 0x000000FFul)))
#else /*#ifndef D17_BYPASS_DEBUG_ALLOW_NO_READ_ACTION_ID_CHECK*/
#define ONE_BYTE_CLEARED(x)                                     \
    (P_D17_DisableRAIDCheck ||                                  \
     (! ((x & 0xFF000000ul) &&                                  \
         (x & 0x00FF0000ul) &&                                  \
         (x & 0x0000FF00ul) &&                                  \
         (x & 0x000000FFul))))
#endif /*#ifndef D17_BYPASS_DEBUG_ALLOW_NO_READ_ACTION_ID_CHECK*/

#endif /*#ifdef D17_ENABLE_BYPASS_SUPPORT*/

static void ExecuteTrigger(uint16 triggerEntry,
    uint32* triggerFlag,
    uint32 triggerFlagValue)
{
    /*******************************************************************************
    * \fn ExecuteTrigger
    * \brief Trigger this event
    * \param triggerEntry the (possibly virtual) trigger to use
    * \param triggerFlag the address to write the trigger value to
    * \param triggerFlagValue the value to write to the trigger flag address
    *
    * This function invokes the low-level trigger function, after possibly
    * looking up the actual trigger id to be set.
    *******************************************************************************/
    uint16 hardwareTrigger = 0;

#if defined(USE_TRIGGER_SEMAPHORE)
    Trigger_S4_SpinLock();
#endif
#ifdef D17_USE_VIRTUAL_TRIGGER
    int i;

    /* check the table if the trigger entry is a redirection */
    /* note: if there are many indirections, this implementation might be too
        slow */
    for (i = 0; (!hardwareTrigger) && (i < ECUTriggerTable.Entries); i++)
    {
        if (triggerEntry == ECUTriggerTable.Table[i].ECU_ID)
        {
            hardwareTrigger = ECUTriggerTable.Table[i].TriggerNumber;
        }
    }

    /* not a redirection -- use the trigger number directly */
    if (!hardwareTrigger)
#endif
    {
        hardwareTrigger = (uint16)triggerEntry;
    }

#ifdef TRACE_SUPPORT
    // Only triggers Supplementary Distab if it's a SuD17 event which can be defined based on the event ECU_ID:
    // 'actual trigger value' = 0: not a valid trace trigger value
    // 'actual trigger value' = 1: 'eventConfig->Trigger' = 'SUD17_ID_OFFSET' + 1
    // ...
    // 'actual trigger value' = 255: 'eventConfig->Trigger' = 'SUD17_ID_OFFSET' + 255
    if ((hardwareTrigger > SUD17_ID_OFFSET) && (hardwareTrigger <= (SUD17_ID_OFFSET + SUD17_MAX_TRG)))
    {
        // Extracting the actual trigger value from Event Config Table
        *triggerFlag = (uint32)triggerFlagValue; // Not necessary for SuD17
        uint8 actualTrigger = (uint8)(hardwareTrigger - SUD17_ID_OFFSET); // eventConfig->Trigger is uint16, but trace trigger is uint8
        TraceTriggerSuD17 = actualTrigger; // Trace trigger address used: TraceTriggerSuD17
    }
    else // D17 Trigger
#endif
    {
        /** Tricore TC2xx, MPC57xx and RH850 specific - The trigger needs to be offset back with 1 because the value written to the register will trigger the bit with this number.
        Thus if we write the trigger number 1 given by the Event config area it will set the bit numbered 1 to true which will give the value 0x2 because there is also a bit numbered 0.*/
        Set_ETKTrigger_D17(hardwareTrigger - 1, triggerFlag, triggerFlagValue);
    }

#if defined(USE_TRIGGER_SEMAPHORE)
    Trigger_S4_SpinUnlock();
#endif
}

enum D17_Result Distab17_Process(uint16 eventNumber)
{
    /*******************************************************************************
    * \fn Distab17_Process
    * \brief Process the configuration for the given event
    * \param eventNumber the current event
    *
    * This function looks up the event configuration, decides whether this event is
    * enabled, used TDM or the output table, if necessary invokes the data copy
    * and finally executes the trigger.
    *******************************************************************************/

    enum D17_Result result = D17_EVENT_NOT_ACTIVE;
    uint32 config = Distab17EventList.Config[eventNumber - 1];
    uint32 triggerFlagValue = ((eventNumber << 0x18) |
        (eventNumber << 0x10) |
        (eventNumber << 0x08) |
        (eventNumber << 0x00));

    int configIsEnabled = config & 1;
#ifdef D17_ETK_TRIGGER_FLAG_CLEAR
    VOLATILE_DEF int t = 0;
#endif

    if (configIsEnabled)
    {
        /* The entry in the configuration list is a tagged pointer, and aligned
           to four bytes, with the lowest two bits containing other information
           -- e.g. the "is enabled" setting
         */
        tD17EventConfigHeader* eventConfig =
            (tD17EventConfigHeader*)(config & (uint32)(~3));

        if (D17_VERSION_NUMBER == Distab17EventList.Version)
        {
            tD17EventOutputHeader* output = eventConfig->Output;

#ifdef D17_ETK_TRIGGER_FLAG_CLEAR
            while (triggerFlagValue == output->TriggerFlag)
            {
                /* Busy loop - Waiting for a different event using the same output area with indirect triggering to be ready ? */
                t++;
            }
#endif

            output->EcuStatus = ~0;

            result = ((eventConfig->Config & 1)) // checks if TDMconfig  is enabled with the bit 0 of Config set to 1
                ? D17_DATA_ACQUISITION_SUCCESS
                : Distab17_CopyValuesFromECU((tD17EventConfig*)eventConfig);

            ExecuteTrigger(eventConfig->Trigger,
                &(output->TriggerFlag),
                triggerFlagValue);

            output->EcuStatus = 0;
        }
        else
        {
            result = D17_EVENT_UNSUPPORTED_VERSION;
        }
    }
    return result;
}

uint32 Distab17_GetSystemTime(void)
{
    return BASE_GetSystemTime();
}

int Distab17_IsTimeout(uint32 startTime, uint32 waitTime)
{
    return (waitTime > 0)
        ? ((Distab17_GetSystemTime() - startTime) > waitTime)
        : 0;
}

uint32 Distab17_GetMicrosecondsToTicks(uint32 microSeconds)
{
    return (USEC_TO_TICKS(microSeconds));
}

#ifdef D17_ENABLE_BYPASS_SUPPORT

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2
CONST_DEF uint8 TRIGIDVAL[] = {
    0x10, 0x11, 0x12, 0x13,
    0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1A, 0x1B,
    0x1C, 0x1D, 0x1E, 0x1F,
    0x80, 0x81, 0x82, 0x83,
    0x84, 0x85, 0x86, 0x87,
    0x88, 0x89, 0x8A, 0x8B,
    0x8C, 0x8D, 0x8E, 0x8F
};
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2*/

struct BypassLegacyConfig {
    uint32* TrgFlgAdr;
    CONST_DEF tD17LegacyDistab* AdrTabFromECU;
    void* DatTabFromECU;
    CONST_DEF tD17LegacyReverseDistab* AdrTabToECU;
    tD17LegacyBypassReverseData* DatTabToECU;
};

struct BypassReceiveConfig {
    uint8 TimeOutFlag;
    uint8* OldCounter;
    uint8* ErrorCounter;
    uint32* StartWaitTime;
    uint32 TimeOut;
    CONST_DEF tD17BypassReverseConfig* AdrTabToECU;
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    CONST_DEF struct BypassLegacyConfig* LegacyConfig;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/
#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
    uint8 CallbackActive;
    uint8 MaxErrorCount;
#endif /*#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK*/
#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
    uint8* TimeOutStatus;
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */
#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
    uint32* BypassAnswer;
    uint32* BypassDataCopied;
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */
};

struct BypassSendConfig {
    CONST_DEF tD17EventConfig* AdrTabFromECU;
    uint8 ReadActionID;
    uint8 FailedTriggerFlag;
    uint16 TriggerNumber;
    uint32* TriggerFlagAddress;
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    uint8 IsIndirectTrigger;
    CONST_DEF struct BypassLegacyConfig* LegacyConfig;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/
#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
    uint32* TriggerTime;
    uint32* StartCopyECUData;
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */
};

static enum D17_SBB_Result IsServicePointActive(
    uint8 servicePointNumber,
    uint8* servicePointIndex)
{
    CONST_DEF tD17SBBMode* mode = (CONST_DEF tD17SBBMode*) & (P_D17_SrvPtResId[0]);

    if (!servicePointIndex)
    {
        return D17_SP_INVALID_SBB_VERSION;
    }

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
    if (!DISTAB17_IS_CONFIGURED_SBB)
    {
        return D17_SP_INVALID_SBB_VERSION;
    }
#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

    switch (mode->StructureVersion)
    {
    case D17_SBB_Structure_Version_31:
        break;
    case D17_SBB_Structure_Version_21:
        break;
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3
    case D17_SBB_Structure_Version_3:
        break;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3*/
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2
    case D17_SBB_Structure_Version_2:
        break;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2*/
    default:
        return D17_SP_INVALID_SBB_VERSION;
    }

    if (!P_D17_SrvPtResId[servicePointNumber])
    {
        return D17_SP_NO_RESID;
    }

    /* The index starts at zero, but the P_D17_SrvPtResId entry is 1-based
    (zero is used to indicate "inactive", see above) -> subtract one */
    *servicePointIndex = P_D17_SrvPtResId[servicePointNumber] - 1;
    if (!P_D17_SrvPtEnabled[*servicePointIndex])
    {
        return D17_SP_DISABLED;
    }

    return D17_SP_ACTIVE;
}


/* Almost the same as IsServicePointActive(). However it checks if SP is active in SBBv3.1 mode only. */
static enum D17_SBB_Result IsDistab17ServicePointActive(
    uint8 servicePointNumber,
    uint8* servicePointIndex)
{
    CONST_DEF tD17SBBMode* mode = (CONST_DEF tD17SBBMode*) & (P_D17_SrvPtResId[0]);

    if (!servicePointIndex)
    {
        return D17_SP_INVALID_SBB_VERSION;
    }

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
    if (!(DISTAB17_IS_CONFIGURED_SBB_V31 || DISTAB17_IS_CONFIGURED_SBB_V21))
    {
        return D17_SP_INVALID_SBB_VERSION;
    }
#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

    switch (mode->StructureVersion)
    {
    case D17_SBB_Structure_Version_31:
        break;
    case D17_SBB_Structure_Version_21:
        break;
    default:
        return D17_SP_INVALID_SBB_VERSION;
    }

    if (!P_D17_SrvPtResId[servicePointNumber])
    {
        return D17_SP_NO_RESID;
    }

    /* The index starts at zero, but the P_D17_SrvPtResId entry is 1-based
    (zero is used to indicate "inactive", see above) -> subtract one */
    *servicePointIndex = P_D17_SrvPtResId[servicePointNumber] - 1;
    if (!P_D17_SrvPtEnabled[*servicePointIndex])
    {
        return D17_SP_DISABLED;
    }

    return D17_SP_ACTIVE;
}

static enum D17_SBB_Result SBB_Set_From_ECU_Config(
    uint8 servicePointNumber,
    uint8 servicePointIndex,
    enum D17_SBB_SP_Type servicePointType,
    struct BypassSendConfig* sendConfig)
{
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    CONST_DEF tD17SBBMode* mode = (CONST_DEF tD17SBBMode*) & (P_D17_SrvPtResId[0]);
    sendConfig->IsIndirectTrigger = 0;
    sendConfig->LegacyConfig = NULL;
    sendConfig->AdrTabFromECU = NULL;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

    switch (servicePointType)
    {
    case D17_SP_TYPE_PRE:
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
        switch (mode->StructureVersion)
        {
        case D17_SBB_Structure_Version_2:
            sendConfig->LegacyConfig = (struct BypassLegacyConfig*)
                & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPre);

            sendConfig->IsIndirectTrigger =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].Config.Trigger_Mode_Pre;

            /* SP not active -> Don't need to continue setting up the structure */
            if (!(sendConfig->LegacyConfig &&
                sendConfig->LegacyConfig->AdrTabFromECU &&
                sendConfig->LegacyConfig->DatTabFromECU &&
                /* either direct triggering or a valid address is required */
                ((!sendConfig->IsIndirectTrigger) ||
                    (sendConfig->LegacyConfig->TrgFlgAdr))))
            {
                return D17_SP_NO_DATA_FROM_ECU;
            }

            sendConfig->TriggerNumber =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrigNumPre;
            break;
        case D17_SBB_Structure_Version_3:
            sendConfig->LegacyConfig = (struct BypassLegacyConfig*)
                & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPre);

            /* SP not active -> Don't need to continue setting up the structure */
            if (!(sendConfig->LegacyConfig &&
                sendConfig->LegacyConfig->AdrTabFromECU &&
                sendConfig->LegacyConfig->DatTabFromECU &&
                sendConfig->LegacyConfig->TrgFlgAdr))
            {
                return D17_SP_NO_DATA_FROM_ECU;
            }

            sendConfig->TriggerNumber =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrigNumPre;
            sendConfig->ReadActionID =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].RAIDPre;
            break;
        default:
            /* fall through */
            /* this must not happen */
        case D17_SBB_Structure_Version_31:
        case D17_SBB_Structure_Version_21:
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/
            sendConfig->AdrTabFromECU =
                D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabFromECUPre;

            /* SP not active -> Don't need to continue setting up the structure */
            if (!sendConfig->AdrTabFromECU)
            {
                return D17_SP_NO_DATA_FROM_ECU;
            }

            sendConfig->TriggerFlagAddress =
                D17_ServicePoint_Cfg.V31[servicePointIndex].TrgFlgAdrPre;
            sendConfig->ReadActionID =
                D17_ServicePoint_Cfg.V31[servicePointIndex].RAIDPre;
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
            break;
        }
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

        sendConfig->FailedTriggerFlag = D17_SP_FAILEDTRIGGER_PRE;

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        sendConfig->StartCopyECUData =
            &(D17_SP_Timestamp_StartCopyECUData_Pre[servicePointNumber - 1]);
        sendConfig->TriggerTime =
            &(D17_SP_Timestamp_Trigger_Pre[servicePointNumber - 1]);
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */
        break;
    case D17_SP_TYPE_POST:
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
        switch (mode->StructureVersion)
        {
        case D17_SBB_Structure_Version_2:
            sendConfig->LegacyConfig = (struct BypassLegacyConfig*)
                & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPost);

            sendConfig->IsIndirectTrigger =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].Config.Trigger_Mode_Post;

            /* SP not active -> Don't need to continue setting up the structure */
            if (!(sendConfig->LegacyConfig &&
                sendConfig->LegacyConfig->AdrTabFromECU &&
                sendConfig->LegacyConfig->DatTabFromECU &&
                /* either direct triggering or a valid address is required */
                ((!sendConfig->IsIndirectTrigger) ||
                    (sendConfig->LegacyConfig->TrgFlgAdr))))
            {
                return D17_SP_NO_DATA_FROM_ECU;
            }

            sendConfig->TriggerNumber =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrigNumPost;
            break;
        case D17_SBB_Structure_Version_3:
            sendConfig->LegacyConfig = (struct BypassLegacyConfig*)
                & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPost);

            /* SP not active -> Don't need to continue setting up the structure */
            if (!(sendConfig->LegacyConfig &&
                sendConfig->LegacyConfig->AdrTabFromECU &&
                sendConfig->LegacyConfig->DatTabFromECU &&
                sendConfig->LegacyConfig->TrgFlgAdr))
            {
                return D17_SP_NO_DATA_FROM_ECU;
            }

            sendConfig->TriggerNumber =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrigNumPost;
            sendConfig->ReadActionID =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].RAIDPost;
            break;
        default:
            /* fall through */
            /* this must not happen */
        case D17_SBB_Structure_Version_31:
        case D17_SBB_Structure_Version_21:
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/
            sendConfig->AdrTabFromECU =
                D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabFromECUPost;

            /* SP not active -> Don't need to continue setting up the structure */
            if (!sendConfig->AdrTabFromECU)
            {
                return D17_SP_NO_DATA_FROM_ECU;
            }

            sendConfig->TriggerFlagAddress =
                D17_ServicePoint_Cfg.V31[servicePointIndex].TrgFlgAdrPost;
            sendConfig->ReadActionID =
                D17_ServicePoint_Cfg.V31[servicePointIndex].RAIDPost;
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
            break;
        }
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

        sendConfig->FailedTriggerFlag = D17_SP_FAILEDTRIGGER_POST;

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        sendConfig->TriggerTime =
            &(D17_SP_Timestamp_Trigger_Post[servicePointNumber - 1]);
        sendConfig->StartCopyECUData =
            &(D17_SP_Timestamp_StartCopyECUData_Post[servicePointNumber - 1]);
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */
        break;
    default:
        // TODO: assert or something
        break;
    }

    if (sendConfig->AdrTabFromECU)
    {
        sendConfig->TriggerNumber =
            sendConfig->AdrTabFromECU->Header.Trigger;
    }

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    if (sendConfig->LegacyConfig)
    {
        sendConfig->TriggerFlagAddress = sendConfig->LegacyConfig->TrgFlgAdr;
    }
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

    return D17_SP_ACTIVE; /* SP active according to the Service point address pointers. */
}

static enum D17_SBB_Result SBB_Process_From_ECU(
    uint8 servicePointNumber,
    uint8 servicePointIndex,
    enum D17_SBB_SP_Type servicePointType)
{
    struct BypassSendConfig sendConfig;

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    CONST_DEF tD17SBBMode* mode = (CONST_DEF tD17SBBMode*) & (P_D17_SrvPtResId[0]);
#endif

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
    VOLATILE_DEF uint32 loopCounter = 0;
#else
    uint32 startWaitTime;
    CONST_DEF uint32 waitPeriod =
        Distab17_GetMicrosecondsToTicks(D17_BYPASS_MAX_RAID_WAIT_US);
#endif /* #define D17_ENABLE_BYPASS_STATE_MANAGEMENT */

    if (SBB_Set_From_ECU_Config(
        servicePointNumber,
        servicePointIndex,
        servicePointType,
        &sendConfig) == D17_SP_NO_DATA_FROM_ECU)
    {
        return D17_SP_NO_DATA_FROM_ECU;
    }

    /* Send data to the RP system */

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
    * (sendConfig.StartCopyECUData) = Distab17_GetSystemTime();
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

    if (sendConfig.AdrTabFromECU &&
        (D17_DATA_ACQUISITION_SUCCESS != Distab17_CopyValuesFromECU(sendConfig.AdrTabFromECU)))
    {
        return D17_SP_FROM_ECU_ACQUISITION_ERROR;
    }

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    if (sendConfig.LegacyConfig &&
        (D17_DATA_ACQUISITION_SUCCESS != Distab17_CopyValuesFromECULegacy(sendConfig.LegacyConfig->AdrTabFromECU,
            sendConfig.LegacyConfig->DatTabFromECU)))
    {
        return D17_SP_FROM_ECU_ACQUISITION_ERROR;
    }
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

    /* ETASTEST    */ D17_ProcessCount[servicePointNumber - 1]++;

    switch (mode->StructureVersion)
    {
    default:
        /* this must not be hit */
        /* fall through */
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2
    case D17_SBB_Structure_Version_2:
        /* SBB v2 does not depend on the clearing of the trigger flag
        address */

        /* triggerEntry, *triggerFlag, triggerFlagValue */

        if (sendConfig.IsIndirectTrigger)
        {
            if (servicePointIndex >= (sizeof(TRIGIDVAL) / sizeof(TRIGIDVAL[0])))
            {
                /* Too many active service points */
                return D17_SP_FROM_ECU_INVALID_CONFIG;
            }

            ExecuteTrigger(sendConfig.TriggerNumber,
                sendConfig.TriggerFlagAddress,
                TRIGIDVAL[servicePointIndex]);
        }
        else
        {
            ExecuteTrigger(sendConfig.TriggerNumber, NULL, 0);
        }

        /* ETASTEST    */ D17_TriggerCount[servicePointNumber - 1]++;

        D17_SP_ControlVar[servicePointIndex].Control &=
            ~sendConfig.FailedTriggerFlag;
#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        * (sendConfig.TriggerTime) = Distab17_GetSystemTime();
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */
        break;
#endif /* #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2 */
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3
    case D17_SBB_Structure_Version_3:
        /* fall through */
#endif /* #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3 */
    case D17_SBB_Structure_Version_31:

#ifndef D17_ENABLE_BYPASS_STATE_MANAGEMENT
        startWaitTime = Distab17_GetSystemTime();
#endif /* #ifndef D17_ENABLE_BYPASS_STATE_MANAGEMENT */

        while (!ONE_BYTE_CLEARED(*(sendConfig.TriggerFlagAddress)))
        {
            /* ETASTEST    */ D17_LockMissCount[servicePointNumber - 1]++;
#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
            if ((++loopCounter) > D17_SBB_State_RAIDWaitLoops)
#else
            if (Distab17_IsTimeout(startWaitTime, waitPeriod))
#endif /* #ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT */
            {
                D17_SP_ControlVar[servicePointIndex].Control |=
                    sendConfig.FailedTriggerFlag;
                ++(D17_SP_ControlVar[servicePointIndex].FailedTriggerCounter);
                break;
            }
        }

        if (ONE_BYTE_CLEARED(*(sendConfig.TriggerFlagAddress)))
        {
            Disable_Interrupts();

            if (ONE_BYTE_CLEARED(*(sendConfig.TriggerFlagAddress)))
            {
                ExecuteTrigger(sendConfig.TriggerNumber,
                    sendConfig.TriggerFlagAddress,
                    sendConfig.ReadActionID);

                Enable_Interrupts();

                /* ETASTEST    */ D17_TriggerCount[servicePointNumber - 1]++;

                D17_SP_ControlVar[servicePointIndex].Control &=
                    ~sendConfig.FailedTriggerFlag;

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
                * (sendConfig.TriggerTime) = Distab17_GetSystemTime();
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

                return D17_SP_FROM_ECU_SUCCESS;
            }
            else
            {
                Enable_Interrupts();
                return D17_SP_FROM_ECU_INTERRUPTED;
            }
        }
        else
        {
            return D17_SP_FROM_ECU_RAID_TIMEOUT;
        }
        break;

    case D17_SBB_Structure_Version_21:


        Disable_Interrupts();

        ExecuteTrigger(sendConfig.TriggerNumber, NULL, 0);


        Enable_Interrupts();

        /* ETASTEST    */ D17_TriggerCount[servicePointNumber - 1]++;

        D17_SP_ControlVar[servicePointIndex].Control &=
            ~sendConfig.FailedTriggerFlag;

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        * (sendConfig.TriggerTime) = Distab17_GetSystemTime();
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

        return D17_SP_FROM_ECU_SUCCESS;
    }
}

static enum D17_SBB_Result SBB_Set_To_ECU_Config(
    uint8 servicePointNumber,
    uint8 servicePointIndex,
    enum D17_SBB_SP_Type servicePointType,
    struct BypassReceiveConfig* receiveConfig)
{
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    CONST_DEF tD17SBBMode* mode = (CONST_DEF tD17SBBMode*) & (P_D17_SrvPtResId[0]);
    receiveConfig->LegacyConfig = NULL;
    receiveConfig->AdrTabToECU = NULL;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

    switch (servicePointType)
    {
    case D17_SP_TYPE_PRE:
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
        switch (mode->StructureVersion)
        {
        case D17_SBB_Structure_Version_2:
            /* fall through */
        case D17_SBB_Structure_Version_3:
            receiveConfig->LegacyConfig = (struct BypassLegacyConfig*)
                & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPre);

            /* SP not active -> Don't need to continue setting up the structure */
            if (!(receiveConfig->LegacyConfig &&
                receiveConfig->LegacyConfig->AdrTabToECU &&
                receiveConfig->LegacyConfig->DatTabToECU))
            {
                return D17_SP_NO_DATA_TO_ECU;
            }

#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
            receiveConfig->MaxErrorCount =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].MaxValPre;
#endif
            break;
        default:
            /* fall through */
            /* this must not happen */
        case D17_SBB_Structure_Version_31:
        case D17_SBB_Structure_Version_21:
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/
            receiveConfig->AdrTabToECU =
                D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabToECUPre;

            /* SP not active -> Don't need to continue setting up the structure */
            if (!receiveConfig->AdrTabToECU)
            {
                return D17_SP_NO_DATA_TO_ECU;
            }

#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
            receiveConfig->MaxErrorCount =
                D17_ServicePoint_Cfg.V31[servicePointIndex].MaxValPre;
#endif
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
            break;
        }
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

        receiveConfig->TimeOutFlag = D17_SP_TIMEOUT_PRE_SET;
        receiveConfig->OldCounter =
            &(D17_SP_OldBypassCounterPre[servicePointIndex]);
        receiveConfig->ErrorCounter = (uint8*)
            &(D17_SP_ControlVar[servicePointIndex].ErrCntPre);
        receiveConfig->StartWaitTime =
            &(D17_SP_StartWaitTimePre[servicePointIndex]);
        receiveConfig->TimeOut = P_D17_TimeOutPre[servicePointIndex];
#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
        receiveConfig->CallbackActive = D17_SP_PRE_CALLBACK_ACTIVE;
#endif /*#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK*/
#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
        receiveConfig->TimeOutStatus =
            &(D17_SP_Status_TimeOutPre[servicePointNumber - 1]);
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */
#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        receiveConfig->BypassAnswer =
            &(D17_SP_Timestamp_BypassAnswer_Pre[servicePointNumber - 1]);
        receiveConfig->BypassDataCopied =
            &(D17_SP_Timestamp_BypassDataCopied_Pre[servicePointNumber - 1]);
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

        break;
    case D17_SP_TYPE_POST:

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
        switch (mode->StructureVersion)
        {
        case D17_SBB_Structure_Version_2:
            /* fall through */
        case D17_SBB_Structure_Version_3:
            receiveConfig->LegacyConfig = (struct BypassLegacyConfig*)
                & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPost);

            /* SP not active -> Don't need to continue setting up the structure */
            if (!(receiveConfig->LegacyConfig &&
                receiveConfig->LegacyConfig->AdrTabToECU &&
                receiveConfig->LegacyConfig->DatTabToECU))
            {
                return D17_SP_NO_DATA_TO_ECU;
            }

#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
            receiveConfig->MaxErrorCount =
                D17_ServicePoint_Cfg.V3_V2[servicePointIndex].MaxValPost;
#endif
            break;
        default:
            /* fall through */
            /* this must not happen */
        case D17_SBB_Structure_Version_31:
        case D17_SBB_Structure_Version_21:
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/
            receiveConfig->AdrTabToECU =
                D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabToECUPost;

            /* SP not active -> Don't need to continue setting up the structure */
            if (!receiveConfig->AdrTabToECU)
            {
                return D17_SP_NO_DATA_TO_ECU;
            }

#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
            receiveConfig->MaxErrorCount =
                D17_ServicePoint_Cfg.V31[servicePointIndex].MaxValPost;
#endif
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
            break;
        }
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

        receiveConfig->TimeOutFlag = D17_SP_TIMEOUT_POST_SET;
        receiveConfig->OldCounter =
            &(D17_SP_OldBypassCounterPost[servicePointIndex]);
        receiveConfig->ErrorCounter = (uint8*)
            &(D17_SP_ControlVar[servicePointIndex].ErrCntPost);
        receiveConfig->StartWaitTime =
            &(D17_SP_StartWaitTimePre[servicePointIndex]);
        receiveConfig->TimeOut = P_D17_TimeOutPost[servicePointIndex];
#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
        receiveConfig->CallbackActive = D17_SP_POST_CALLBACK_ACTIVE;
#endif /*#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK*/
#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
        receiveConfig->TimeOutStatus =
            &(D17_SP_Status_TimeOutPost[servicePointNumber - 1]);
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */
#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        receiveConfig->BypassAnswer =
            &(D17_SP_Timestamp_BypassAnswer_Post[servicePointNumber - 1]);
        receiveConfig->BypassDataCopied =
            &(D17_SP_Timestamp_BypassDataCopied_Post[servicePointNumber - 1]);
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

        break;
    default:
        /* TODO: assert or something */
        break;
    }
    return D17_SP_ACTIVE; /* SP active according to the Service point address pointers. */
}

static enum D17_SBB_Result SBB_Process_To_ECU(
    uint8 servicePointNumber,
    uint8 servicePointIndex,
    enum D17_SBB_SP_Type servicePointType)
{
    VOLATILE_DEF int wait_counter = 0;
    struct BypassReceiveConfig receiveConfig;
    tD17BypassReverseData* dataTable = NULL;

    if (SBB_Set_To_ECU_Config(servicePointNumber, servicePointIndex,
        servicePointType, &receiveConfig) == D17_SP_NO_DATA_TO_ECU)
    {
        return D17_SP_NO_DATA_TO_ECU;
    }

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    dataTable = (receiveConfig.AdrTabToECU)
        ? receiveConfig.AdrTabToECU->DataTable
        : (receiveConfig.LegacyConfig)
        ? receiveConfig.LegacyConfig->DatTabToECU
        : NULL;

#else /* #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT */
    dataTable = receiveConfig.AdrTabToECU->DataTable;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

    if (!dataTable)
    {
        return D17_SP_TO_ECU_INVALID_DATATABLE;
    }

    if ((D17_SP_ControlVar[servicePointIndex].Control & receiveConfig.TimeOutFlag) &&
        (dataTable->BypCtr == *(receiveConfig.OldCounter)))
    {
        /* There was a timeout */
        ++(*(receiveConfig.ErrorCounter));

#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
        if ((receiveConfig.CallbackActive) &&
            ((*(receiveConfig.ErrorCounter)) > (receiveConfig.MaxErrorCount)))
        {
            D17_SBB_Error_Callback(servicePointIndex, servicePointType);
            return D17_SP_TO_ECU_ERROR_CALLBACK_INVOKED;
        }
#endif /*#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK*/
    }
    else
    {
        /* New data arrived, but there could have been a raster delay */
        *(receiveConfig.ErrorCounter) = 0;
    }

    *(receiveConfig.StartWaitTime) = Distab17_GetSystemTime();
    while (dataTable->BypCtr == *(receiveConfig.OldCounter))
    {
        if (Distab17_IsTimeout(*(receiveConfig.StartWaitTime), receiveConfig.TimeOut))
        {
            break;
        }
        wait_counter++;
    }

    if (dataTable->BypCtr == *(receiveConfig.OldCounter))
    {
        D17_SP_ControlVar[servicePointIndex].Control |= (receiveConfig.TimeOutFlag);

#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
        * (receiveConfig.TimeOutStatus) = 1;
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
        if ((D17_SBB_State_IsFirstServicePoint) &&
            (*(receiveConfig.ErrorCounter)) > (receiveConfig.MaxErrorCount))
        {
            D17_SBB_State_IsFirstServicePoint = 0;
        }
#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        * (receiveConfig.BypassAnswer) = Distab17_GetSystemTime();
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

        return D17_SP_TO_ECU_TIMEOUT_WHILE_WAITING_FOR_BYPASS_COUNTER;
    }
    else
    {
        int useDataFromRPSystem = 1;
        enum D17_Result result = D17_EVENT_NOT_ACTIVE;

        /* Everything is good -- new data is known to be present */

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        * (receiveConfig.BypassAnswer) = Distab17_GetSystemTime();
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

        D17_SP_ControlVar[servicePointIndex].Control &=
            ~(receiveConfig.TimeOutFlag);

#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
        * (receiveConfig.TimeOutStatus) = 0;
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */

        * (receiveConfig.OldCounter) = dataTable->BypCtr;

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT
        D17_SBB_State_IsFirstServicePoint = 0;
        if (!D17_SBB_State_IsETargetDetected)
        {
            D17_SBB_State_IsETargetDetected = 1;
            Distab17_SBB_Config_Update();
            Distab17_SBB_State_Update();
        }
        useDataFromRPSystem = (BYPASS_ACTIVE == D17_SBB_State);
#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/

        if (!useDataFromRPSystem)
        {
            return D17_SP_TO_ECU_BYPASS_NOT_ACTIVE;
        }

        if (receiveConfig.AdrTabToECU)
        {
            result = Distab17_CopyValuesToECU(receiveConfig.AdrTabToECU);
        }

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
        if (receiveConfig.LegacyConfig)
        {
            result = Distab17_CopyValuesToECULegacy(
                receiveConfig.LegacyConfig->AdrTabToECU,
                receiveConfig.LegacyConfig->DatTabToECU);
        }
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT*/

        if (D17_DATA_ACQUISITION_SUCCESS != result)
        {
            return D17_SP_NO_DATA_TO_ECU;
        }

#ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT
        * (receiveConfig.BypassDataCopied) = Distab17_GetSystemTime();
#endif /* #ifdef D17_ENABLE_BYPASS_TIMESTAMP_MEASUREMENT */

        return D17_SP_TO_ECU_NEW_DATA;
    }
}

static void* HBB_GetValuePtr(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset)
{
    uint8 servicePointIndex;

    if (isEnabled &&
        (D17_SP_ACTIVE == IsDistab17ServicePointActive(servicePointNumber, &servicePointIndex)))
    {
        CONST_DEF VOLATILE_DEF tD17ServicePointDescriptor* cfg =
            &(D17_ServicePoint_Cfg.V31[servicePointIndex]);

        tD17BypassReverseData* datTabToECUPre = cfg->DatTabToECUPre;
        // The A2L files defines an offset of 4 including the header, thus the data offset includes the header size into its offset.
        if (datTabToECUPre && (dataOffset < datTabToECUPre->TableLength + 4))
        {
            // The A2L files defines an offset of 4 including the header, thus the structure pointer starts at the header.
            return (((uint8*)datTabToECUPre) +
                dataOffset +
                ((datTabToECUPre->BypCtr & 1)
                    ? 0
                    : datTabToECUPre->TableLength));
        }
    }

    return NULL;
}

//////////////////////////////////////////////////////////////////////////////


void* Distab17_IsServicePointActiveAndConfiguredForHBB(uint8 servicePointNumber)
{
    uint8 servicePointIndex;

    if (D17_SP_ACTIVE == IsDistab17ServicePointActive(servicePointNumber, &servicePointIndex))
    {
        CONST_DEF VOLATILE_DEF tD17ServicePointDescriptor* cfg =
            &(D17_ServicePoint_Cfg.V31[servicePointIndex]);

        tD17BypassReverseData* datTabToECUPre = cfg->DatTabToECUPre;
        return datTabToECUPre;
    }

    return NULL;
}

uint8 Distab17_SBB_Process(
    uint8 servicePointNumber,
    enum D17_SBB_SP_Type servicePointType)
{
    uint8 servicePointIndex;
    uint8 result = IsServicePointActive(servicePointNumber, &servicePointIndex);

    if (D17_SP_ACTIVE == result)
    {

#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
        D17_SP_Status_ServicePointEnabled[servicePointNumber - 1] = 1;
        D17_SP_Status_FunctionExecution[servicePointNumber - 1] =
            P_D17_DisableFctExec[servicePointIndex];
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */

        /* Send data to the RP system ... */
        result |= SBB_Process_From_ECU(servicePointNumber, servicePointIndex, servicePointType);

        // TODO: Check for any particularily nasty error

        /* ... and receive data from it */
        result |= SBB_Process_To_ECU(servicePointNumber, servicePointIndex, servicePointType);
    }
#ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT
    else
    {
        D17_SP_Status_ServicePointEnabled[servicePointNumber - 1] = 0;
    }
#endif /* #ifdef D17_ENABLE_BYPASS_STATUS_MEASUREMENT */

    return result;
}

uint8 Distab17_HBB_Process(uint8 servicePointNumber)
{
    return Distab17_SBB_Process(servicePointNumber, D17_SP_TYPE_PRE);
}

uint8 Distab17_Get_Bypass_Value_Bit(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint8 ecuValue,
    uint8 bitOffset)
{
    uint8* value_ptr = (uint8*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return ((bitOffset < 8) && (value_ptr))
        ? (!!((*value_ptr) & (1 << bitOffset)))
        : ecuValue;
}

uint8 Distab17_Get_Bypass_Value_uint8(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint8 ecuValue)
{
    uint8* value_ptr = (uint8*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

sint8 Distab17_Get_Bypass_Value_sint8(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    sint8 ecuValue)
{
    sint8* value_ptr = (sint8*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

uint16 Distab17_Get_Bypass_Value_uint16(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint16 ecuValue)
{
    uint16* value_ptr = (uint16*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

sint16 Distab17_Get_Bypass_Value_sint16(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    sint16 ecuValue)
{
    sint16* value_ptr = (sint16*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

uint32 Distab17_Get_Bypass_Value_uint32(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    uint32 ecuValue)
{
    uint32* value_ptr = (uint32*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

sint32 Distab17_Get_Bypass_Value_sint32(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    sint32 ecuValue)
{
    sint32* value_ptr = (sint32*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

real32 Distab17_Get_Bypass_Value_real32(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    real32 ecuValue)
{
    real32* value_ptr = (real32*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

real64 Distab17_Get_Bypass_Value_real64(
    uint8 servicePointNumber,
    uint8 isEnabled,
    uint16 dataOffset,
    real64 ecuValue)
{
    real64* value_ptr = (real64*)
        HBB_GetValuePtr(servicePointNumber, isEnabled, dataOffset);

    return (value_ptr)
        ? *value_ptr
        : ecuValue;
}

#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
void D17_SBB_Error_Callback(uint8 servicePointIndex,
    enum D17_SBB_SP_Type servicePointType)
{
    /* Do something */
}
#endif /*#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK*/

/* ETASTEST    */ #ifdef D17_ENABLE_BYPASS_NB_OF_BYTES_STATUS
/* ETASTEST    */ void Distab17_SBB_NbOfBytes(uint8 servicePointNumber)
/* ETASTEST    */ {
    /* ETASTEST    */   uint8 servicePointIndex;
    /* ETASTEST    */   uint8 result = IsServicePointActive(servicePointNumber, &servicePointIndex);
    /* ETASTEST    */   if (D17_SP_ACTIVE == result)
        /* ETASTEST    */ {
        /* ETASTEST    */     CONST_DEF tD17SBBMode* mode = (CONST_DEF tD17SBBMode*) & (P_D17_SrvPtResId[0]);
        /* ETASTEST    */     switch (mode->StructureVersion)
            /* ETASTEST    */ {
/* ETASTEST    */     #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2
        /* ETASTEST    */     case D17_SBB_Structure_Version_2:
/* ETASTEST    */     #endif /* #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2 */
/* ETASTEST    */     #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3
        /* ETASTEST    */     case D17_SBB_Structure_Version_3:
/* ETASTEST    */     #endif /* #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3 */
/* ETASTEST    */     #if (defined D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2 || defined D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3)
            /* ETASTEST    */; // a label can only be followed by a statement...
            /* ETASTEST    */         CONST_DEF tD17LegacyDistab* AdrTabFromECUPreLegacy = D17_ServicePoint_Cfg.V3_V2[servicePointIndex].AdrTabFromECUPre;
            /* ETASTEST    */         if (AdrTabFromECUPreLegacy)
                /* ETASTEST    */ {
                /* ETASTEST    */           D17_BypassFromEcuBytes[servicePointNumber - 1] = Distab17_getNumberOfBytesFromECULegacy(AdrTabFromECUPreLegacy);
                /* ETASTEST    */
            }
            /* ETASTEST    */
            /* ETASTEST    */         CONST_DEF tD17LegacyReverseDistab* AdrTabToECUPostLegacy = D17_ServicePoint_Cfg.V3_V2[servicePointIndex].AdrTabToECUPost;
            /* ETASTEST    */         if (AdrTabToECUPostLegacy)
                /* ETASTEST    */ {
                /* ETASTEST    */           D17_BypassToEcuBytes[servicePointNumber - 1] = Distab17_getNumberOfBytesToECULegacy(AdrTabToECUPostLegacy);
                /* ETASTEST    */
            }
            /* ETASTEST    */         break;
/* ETASTEST    */     #endif /* if defined SBBV3 or SBBV2 */
        /* ETASTEST    */     case D17_SBB_Structure_Version_31:
        /* ETASTEST    */     case D17_SBB_Structure_Version_21:
            /* ETASTEST    */; // a label can only be followed by a statement...
            /* ETASTEST    */         CONST_DEF tD17EventConfig* AdrTabFromECUPre = D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabFromECUPre;
            /* ETASTEST    */         if (AdrTabFromECUPre)
                /* ETASTEST    */ {
                /* ETASTEST    */           D17_BypassFromEcuBytes[servicePointNumber - 1] = Distab17_getNumberOfBytesFromECU(AdrTabFromECUPre);
                /* ETASTEST    */
            }
            /* ETASTEST    */
            /* ETASTEST    */         CONST_DEF tD17BypassReverseConfig* AdrTabToECUPost = D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabToECUPost;
            /* ETASTEST    */         if (AdrTabToECUPost)
                /* ETASTEST    */ {
                /* ETASTEST    */           D17_BypassToEcuBytes[servicePointNumber - 1] = Distab17_getNumberOfBytesToECU(AdrTabToECUPost);
                /* ETASTEST    */
            }
            /* ETASTEST    */         break;
        /* ETASTEST    */     default:
            /* ETASTEST    */         break;
            /* ETASTEST    */
        }
        /* ETASTEST    */
    }
    /* ETASTEST    */   else
        /* ETASTEST    */ {
        /* ETASTEST    */     // Bypass not used = 0 bytes transfered
        /* ETASTEST    */     D17_BypassFromEcuBytes[servicePointNumber - 1] = 0;
        /* ETASTEST    */     D17_BypassToEcuBytes[servicePointNumber - 1] = 0;
        /* ETASTEST    */
    }
    /* ETASTEST    */
}

/* ETASTEST    */ inline uint16 Distab17_getNumberOfBytesFromECU(CONST_DEF tD17EventConfig* config)
/* ETASTEST    */ {
    /* ETASTEST    */    return (uint16)((config->NoOfVal_8 << 3) + (config->NoOfVal_4 << 2) + (config->NoOfVal_2 << 1) + config->NoOfVal_1);
    /* ETASTEST    */
}

/* ETASTEST    */ inline uint16 Distab17_getNumberOfBytesToECU(CONST_DEF tD17BypassReverseConfig* adrTabToECU)
/* ETASTEST    */ {
    /* ETASTEST    */    uint16 numberOfDataBytes = /* without alignment */
        /* ETASTEST    */    (((adrTabToECU->NoOfVal_8) << 3) +
            /* ETASTEST    */    ((adrTabToECU->NoOfVal_4 + adrTabToECU->NoOfBits_4) << 2) +
            /* ETASTEST    */    ((adrTabToECU->NoOfVal_2 + adrTabToECU->NoOfBits_2) << 1) +
            /* ETASTEST    */    ((adrTabToECU->NoOfVal_1 + adrTabToECU->NoOfBits_1) << 0));
    /* ETASTEST    */    return numberOfDataBytes;
    /* ETASTEST    */
}

/* ETASTEST    */ #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
/* ETASTEST    */ inline uint16 Distab17_getNumberOfBytesFromECULegacy(CONST_DEF tD17LegacyDistab* adrTabFromECU)
/* ETASTEST    */ {
    /* ETASTEST    */    return (uint16)((adrTabFromECU->NoOfVal_8 << 3) + (adrTabFromECU->NoOfVal_4 << 2) + (adrTabFromECU->NoOfVal_2 << 1) + adrTabFromECU->NoOfVal_1);
    /* ETASTEST    */
}
/* ETASTEST    */ inline uint16 Distab17_getNumberOfBytesToECULegacy(CONST_DEF tD17LegacyReverseDistab* adrTabToECU)
/* ETASTEST    */ {
    /* ETASTEST    */    uint16 numberOfDataBytes = /* without alignment */
        /* ETASTEST    */    (((adrTabToECU->NoOfVal_8) << 3) +
            /* ETASTEST    */    ((adrTabToECU->NoOfVal_4 + adrTabToECU->NoOfBits_4) << 2) +
            /* ETASTEST    */    ((adrTabToECU->NoOfVal_2 + adrTabToECU->NoOfBits_2) << 1) +
            /* ETASTEST    */    ((adrTabToECU->NoOfVal_1 + adrTabToECU->NoOfBits_1) << 0));
    /* ETASTEST    */    return numberOfDataBytes;
    /* ETASTEST    */
}
/* ETASTEST    */ #endif

/* ETASTEST    */ #endif // D17_ENABLE_BYPASS_NB_OF_BYTES_STATUS

#endif /*#ifdef D17_ENABLE_BYPASS_SUPPORT*/
