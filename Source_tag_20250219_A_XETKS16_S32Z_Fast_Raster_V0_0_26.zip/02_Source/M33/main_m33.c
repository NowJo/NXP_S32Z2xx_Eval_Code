/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

/* ---------------------------------------------------------------------------- */
/* INCLUDES                                                                     */
/* ---------------------------------------------------------------------------- */
#include <Serial/serial.h>
#include <Serial/stdio_func.h>
#include "target_specific.h"
#include "base.h"
//#include "common_utils.h"
#include "S32Z27.h"
#include "etas_asw.h"
#include "Os_Tasks_M33.h"
#include "main_M33.h"
#include "meas_cal.h"
#include "gpio.h"
#include "rs232.h"

#include "wdt.h"

#ifdef D13_SUPPORT
#include "ETK\Distab13_Fct.h"
#endif

#ifdef UFE_SUPPORT
#include "ufe.h"
#endif

#ifdef SLEW_SUPPORT
#include "slew.h"
#endif

#ifdef RS232_DEBUG_LOGGING
#include "rs232.h"
#endif

/* ---------------------------------------------------------------------------- */
/* MACROS                                                                       */
/* ---------------------------------------------------------------------------- */
#define CORE_ID eCORE_R52_0_INDEX

/* ---------------------------------------------------------------------------- */
/* FUNCTIONS PROTOTYPES                                                         */
/* ---------------------------------------------------------------------------- */
extern void sys_init(void);

/* ---------------------------------------------------------------------------- */
/* VARIABLES                                                                    */
/* ---------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------- */
/* TARGET SPECIFIC FUNCTIONS                                                    */
/* ---------------------------------------------------------------------------- */
// Taken from FSL example code - Mini Program Flash controller cache workaround
/** This is required to fill the cache with unused values in order to update the cached calibrated values, because this project is using too few
parameters. The mini cache is using a 2 way 4 entry cache with 32 byte entries. The cache is however configured to be 1 way 4 entry for the data
reads, while the other part is configured for the instruction reads only. */
void ManualCacheRandomAccess(void)
{
}

void STMChannel0Handler(void)
{
}

PRE_SECTION_DATA(P_ForceReset, ".IRAM_ADAP")
volatile uint8 P_ForceReset=0; //used to test reset by ECU
POST_SECTION_DATA()



/* ---------------------------------------------------------------------------- */
/* USER TASKS                                                                   */
/* ---------------------------------------------------------------------------- */
void Task_Init_Impl_M33(void)
{
#ifdef RS232_DEBUG_LOGGING
    RS232_TxString("SMU Starting...\r\n"); // project information
#endif

    P_ForceReset=0;

    MEAS_RasterCountersM33Init();

#ifdef UFE_SUPPORT
    UFE_UfeInit();
#endif
#ifdef SLEW_SUPPORT
    SLEW_SlewInit();
#endif

}

void Task_1ms_Impl_M33(void)
{

    MEAS_RasterCountersM33(1);
}

void Task_5ms_Impl_M33(void)
{
    MEAS_RasterCountersM33(2);
}

#ifdef USE_WDT
volatile uint8 wdt_skip_service=0;
#endif

void Task_10ms_Impl_M33(void)
{
#ifdef USE_WDT
	if(!wdt_skip_service)
		WDT_Service();
#endif
    ManualCacheRandomAccess(); /* Clears the cache. Thus the calibration values are seen correctly by the uC. */
    //MEAS_PrescalerLedBlinkingM33();
    MEAS_RasterCountersM33(3);
    ETAS_DistabProcessWithTiming(R37);
}

void Task_20ms_Impl_M33(void)
{
    MEAS_RasterCountersM33(4);
}

void Task_50ms_Impl_M33(void)
{
    MEAS_RasterCountersM33(5);
}

void Task_100ms_Impl_M33(void)
{
    MEAS_RasterCountersM33(6);
    ETAS_DistabProcessWithTiming(R38);
}

void Task_200ms_Impl_M33(void)
{
    MEAS_RasterCountersM33(7);
}

void Task_500ms_Impl_M33(void)
{
    MEAS_RasterCountersM33(8);
}


void Task_1000ms_Impl_M33(void)
{
    if(P_ForceReset)
    {
    	P_ForceReset=0;
    	BASE_ResetController();
    }

#ifdef LED_ALIVE_M
    GPIO_ToggleLED(LED_ALIVE_M);
#endif

    UpdateCoreAliveCounter();

    MEAS_RasterCountersM33(9);
    ETAS_DistabProcessWithTiming(R39);
}

void Task_Idle_M33(void)
{
}


/* ---------------------------------------------------------------------------- */
/* MAIN FUNCTION                                                                */
/* ---------------------------------------------------------------------------- */
void Start_M33(void)
{
#ifdef LED_ALIVE_M
    GPIO_ToggleLED(LED_ALIVE_M);
#endif
#if defined(CONSECUTIVE_LED_BLINKING_SUPPORT)
    //GPIO_ToggleLED(LED2_CONSECUTIVE); //Used in startup diagnostics
#endif
    //ReadCoreNumber(0);
    WDT_Init();


    OS_StartOs_M33();
}

