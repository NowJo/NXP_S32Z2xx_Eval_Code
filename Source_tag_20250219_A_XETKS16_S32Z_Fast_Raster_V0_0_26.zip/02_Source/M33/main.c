/**************************************************************************************************
 *
 * Copyright 2021 NXP
 *
 **************************************************************************************************
 *
 * NXP Confidential Proprietary. This software is owned or controlled by NXP and may only be used
 * strictly in accordance with the applicable terms. By expressly accepting such terms or by
 * downloading, installing, activating and/or otherwise using the software, you are agreeing that
 * you have read, and that you agree to comply with and are bound by, such license terms.
 * If you do not agree to be bound by the applicable license terms, then you may not retain,
 * install, activate or otherwise use the software.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
**************************************************************************************************/
/*
 * @file 	  main.c
 * @details   function Main
*/
#include "a_std_type.h"
#include "Serial/serial.h"
#include "Serial/stdio_func.h"
#include "S32Z27.h"
#include "target_specific.h"
#include "main_m33.h"
#include "base.h"
#include "gpio.h"
#include "load_code.h"
#include "ETK_Integration_Cfg.h"

#ifdef SEMIHOSTING
#include <stdio.h>
#endif

#if defined (__ghs__)
    #define __INTERRUPT_SVC  __interrupt
    #define __NO_RETURN__ _Pragma("ghs nowarning 111")
#elif defined (__ICCARM__)
    #define __INTERRUPT_SVC  __svc
    #define __NO_RETURN__ _Pragma("diag_suppress=Pe111")
#elif defined (__DCC__)
    #define __INTERRUPT_SVC  __attribute__ ((interrupt ("SWI")))
    #define __NO_RETURN__
#elif defined (__GNUC__)
    #define __INTERRUPT_SVC  __attribute__ ((interrupt ("SWI")))
    #define __NO_RETURN__
#else
    #define __INTERRUPT_SVC
    #define __NO_RETURN__
#endif

#ifndef ENABLE_INTERRUPT
#define ENABLE_INTERRUPT() __asm__ volatile ("cpsie i"); /* Clear PRIMASK */
#endif
#ifndef DISABLE_INTERRUPT
#define DISABLE_INTERRUPT() __asm__ volatile ("cpsid i"); /* Set PRIMASK */
#endif

extern	void multicore_enable(void);
extern	void SystemInit(void);

void INIT_InitTimers(void)
{
	int n;
	//There are 4 channels
	for(n=0; n<4; n++)
	{
#if defined(GCC_VERSION)&&(GCC_VERSION < 10)

    SMU__STM_0.CHANNEL[n].CMP.R = 0x0;
    SMU__STM_0.CHANNEL[n].CCR.R = 0x0; //No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    SMU__STM_0.CHANNEL[n].CIR.R |=0x1;
	}
	if(eHW_Type_TU16&M_Hardware_TypeM33)
	{
		SMU__STM_0.CR.R = 0x3; // CPS = 0 (div by 1); FRZ = 1 (stops in Debug); Enable = 1;
	}
	else
	{
	    SMU__STM_0.CR.R = 0x103; // CPS = 1 (div by 2); FRZ = 1 (stops in Debug); Enable = 1;
	}
#else

    IP_SMU__STM_0->CHANNEL[n].CMP = 0x0;
    IP_SMU__STM_0->CHANNEL[n].CCR = 0x0; //No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    IP_SMU__STM_0->CHANNEL[n].CIR |=0x1;
	}
	if(eHW_Type_TU16&M_Hardware_TypeM33)
	{
		IP_SMU__STM_0->CR = 0x3; // CPS = 0 (div by 1); FRZ = 1 (stops in Debug); Enable = 1;
	}
	else
	{
		IP_SMU__STM_0->CR = 0x103; // CPS = 0 (div by 2); FRZ = 1 (stops in Debug); Enable = 1;
	}
#endif

}

int main(void)
{
	DISABLE_INTERRUPT();
	DisableCache();

	INIT_InitTimers();

	GPIO_Init();  //Initialize before core starts so can use for diagnostics

#if !defined(GCC_VERSION)&&defined(__GNUC__)
	SystemInit();
#endif
	LinFlex_Init();	//Initialize LinFlex0 for serial interface

#ifdef BOOT_CORE_M33
#ifdef RS232_DEBUG_LOGGING
	RS232_TxString("Loading RTU0 code.\n\r");
#endif
#ifdef DEBUG_CORE_START
	SIUL2_1.GPDO65.R ^=0x1;
#endif
	LoadCodeSections();
#ifdef DEBUG_CORE_START
	SIUL2_1.GPDO65.R ^=0x1;
#endif
#ifdef RS232_DEBUG_LOGGING
	RS232_TxString("Releasing RTU0 from reset.\n\r");
#endif
	multicore_enable();
#ifdef DEBUG_CORE_START
	SIUL2_1.GPDO65.R ^=0x1;
#endif
#endif

    ENABLE_INTERRUPT()

	Start_M33();
    return 0;
}


