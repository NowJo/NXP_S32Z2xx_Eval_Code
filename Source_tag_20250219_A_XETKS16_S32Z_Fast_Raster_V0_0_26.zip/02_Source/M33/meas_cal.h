/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef _MEASURE_H_
#define _MEASURE_H_

#include "target_specific.h" //eCORE_MAX
#include "base.h"

/*
 *
 #include "ETK\ETK_Integration_Cfg.h"
#include "ETK\ETK_SER_Coldstart.h"
#include "ETK\ETK_SER_Handshake.h"
#include "ETK\Distab17_Processes.h"
*/
#define NRO_CORES 1

#define DISTAB_RASTER_EVENTS (NRO_CORES * 32)
#define NUMBER_MEAS_RASTERS (NRO_CORES * 10)

#ifdef TRACE_SUPPORT
#define UINT32_TRACE_BLOCK 1024
//#define UINT32_TRACE_BLOCK 200
#define UINT16_TRACE_BLOCK 20
#define UINT8_TRACE_BLOCK 10

#define ASM_NOP   asm("nop");
#define BURST_PREVENT ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP ASM_NOP
#endif

enum RasterCounterIndex {
	R00, //R00 is not used
	//Core 0
	R01= 1, R02, R03, R04, R05, R06, R07, R08, R09,
	//Core 1
	R10,	R11, R12, R13, R14, R15, R16, R17, R18,
	//Core 2
	R19,	R20, R21, R22, R23, R24, R25, R26, R27,
	//Core 3
	R28, R29, R30, R31, R32, R33, R34, R35, R36,
	//M33
	R37, R38, R39,
	RMAX
};

//M33 is not using float if want to use it then the A2L needs to be fixed
//#define FLOAT32_SUPPORT
//#define FLOAT64_SUPPORT

//Only the R52 is used for CAL blocks so declare on command line
//#define CAL_MEASURE_BLOCKS
//#define CAL_MEASURE_V2

//#define UFE_SUPPORT
//#define SLEW_SUPPORT

// ***** Structs *****
typedef struct stTaskParameters
{
    uint32 Period;              /* Unit is ticks */
    void(*Body)(void);
} tTaskParameters;

typedef struct stTaskMeasurements
{
    uint32 DeltaT;              /* Unit is ticks */
    uint32 LastActivation;
    uint32 ActivationCounter;
    uint32 ExecutionTime;
} tTaskMeasurements;

//memory class structure for parameters
typedef struct stCalMax
{ //Best order to avoid alignment issues
    sint32  sint32_max;
    uint32  uint32_max;
    sint16  sint16_max;
    uint16  uint16_max;
    sint8   sint8_max;
    uint8   uint8_max;
} tCalMax;

typedef struct stMeasSint8
{
    sint8 sint8_01;
    sint8 sint8_02;
    sint8 sint8_03;
    sint8 sint8_04;
    sint8 sint8_05;
    sint8 sint8_06;
    sint8 sint8_07;
    sint8 sint8_08;
} tMeasSint8;

typedef struct stMeasSint16
{
    sint16 sint16_01;
    sint16 sint16_02;
    sint16 sint16_03;
    sint16 sint16_04;
    sint16 sint16_05;
    sint16 sint16_06;
    sint16 sint16_07;
    sint16 sint16_08;
} tMeasSint16;

typedef struct stMeasSint32
{
    sint32 sint32_01;
    sint32 sint32_02;
    sint32 sint32_03;
    sint32 sint32_04;
    sint32 sint32_05;
    sint32 sint32_06;
    sint32 sint32_07;
    sint32 sint32_08;
} tMeasSint32;

typedef struct stMeasUint8
{
    uint8 uint8_01;
    uint8 uint8_02;
    uint8 uint8_03;
    uint8 uint8_04;
    uint8 uint8_05;
    uint8 uint8_06;
    uint8 uint8_07;
    uint8 uint8_08;
} tMeasUint8;

typedef struct stMeasUint16
{
    uint16 uint16_01;
    uint16 uint16_02;
    uint16 uint16_03;
    uint16 uint16_04;
    uint16 uint16_05;
    uint16 uint16_06;
    uint16 uint16_07;
    uint16 uint16_08;
} tMeasUint16;

typedef struct stMeasUint32
{
    uint32 uint32_01;
    uint32 uint32_02;
    uint32 uint32_03;
    uint32 uint32_04;
    uint32 uint32_05;
    uint32 uint32_06;
    uint32 uint32_07;
    uint32 uint32_08;
} tMeasUint32;

typedef struct stMeasFloat32
{
    real32 fl32_01;
    real32 fl32_02;
    real32 fl32_03;
    real32 fl32_04;
    real32 fl32_05;
    real32 fl32_06;
    real32 fl32_07;
    real32 fl32_08;
} tMeasFloat32;

typedef struct stMeasFloat64
{
    real64 fl64_01;
    real64 fl64_02;
    real64 fl64_03;
    real64 fl64_04;
    real64 fl64_05;
    real64 fl64_06;
    real64 fl64_07;
    real64 fl64_08;
} tMeasFloat64;

//memory class structure for variables in RAM section
typedef struct stMeas
{
    tMeasSint8 sint8;
    tMeasUint8 uint8;
    tMeasSint16 sint16;
    tMeasUint16 uint16;
    tMeasSint32 sint32;
    tMeasUint32 uint32;

#ifdef FLOAT32_SUPPORT
    tMeasFloat32 fl32;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
    tMeasFloat64 fl64;
#endif // FLOAT64_SUPPORT

} tMeas;

typedef struct stVersion
{
    uint8 VersionX; // Major
    uint8 VersionY; // Minor
    uint8 VersionZ; // Patch
} tVersion;

#ifdef TRACE_SUPPORT
typedef struct stTraceVarBlock
{
    //Struct is = 4 + 4*(100) + 4 + 2 + 2*(25) + 1 + 1*(50) + 1 => 512 bytes (0x200)
    uint32 uint32_byCatch_00;                   // Offset: 0
    uint32 uint32_array[UINT32_TRACE_BLOCK];    // Offset: 4
    uint32 dummy;                               // Not necessarily used for all trace windows (for trigger by value this might not be used). Offset = 0x194 (404) -> 4 + 4*(100)
    uint16 uint16_byCatch_00;                   // Offset: 4 + 4*(100) + 4 = 408
    uint16 uint16_array[UINT16_TRACE_BLOCK];    // Offset: 4 + 4 * (100) + 4 + 2 = 410
    uint8 uint8_byCatch_00;                     // Offset: 4 + 4 * (100) + 4 + 2 + 2*(25) = 460
    uint8 uint8_array[UINT8_TRACE_BLOCK];       // Offset: 4 + 4 * (100) + 4 + 2 + 2*(25) + 1 = 461
    uint8 uint8_byCatch_01;                     // Offset: 4 + 4 * (100) + 4 + 2 + 2*(25) + 1 + 1*(50) = 511
} tTraceVarBlock;
#endif

#ifdef CAL_MEASURE_V2
typedef struct stCalMeasureV2
{
    sint8 S8_1;   /* min=-128.0, max=127.0, ident, limit=yes */
    sint8 S8_2;   /* min=-128.0, max=127.0, ident, limit=yes */
    sint8 S8_3;   /* min=-128.0, max=127.0, ident, limit=yes */
    sint8 S8_4;   /* min=-128.0, max=127.0, ident, limit=yes */
    uint8 U8_1;   /* min=0.0, max=255.0, ident, limit=yes */
    uint8 U8_2;   /* min=0.0, max=255.0, ident, limit=yes */
    uint8 U8_3;   /* min=0.0, max=255.0, ident, limit=yes */
    uint8 U8_4;   /* min=0.0, max=255.0, ident, limit=yes */
    sint16 S16_1; /* min=-32768.0, max=32767.0, ident, limit=yes */
    sint16 S16_2; /* min=-32768.0, max=32767.0, ident, limit=yes */
    sint16 S16_3; /* min=-32768.0, max=32767.0, ident, limit=yes */
    uint16 U16_1; /* min=0.0, max=65535.0, ident, limit=yes */
    uint16 U16_2; /* min=0.0, max=65535.0, ident, limit=yes */
    uint16 U16_3; /* min=0.0, max=65535.0, ident, limit=yes */
    sint32 S32_1; /* min=-2147483648.0, max=2147483647.0, ident, limit=yes */
    sint32 S32_2; /* min=-2147483648.0, max=2147483647.0, ident, limit=yes */
    uint32 U32_1; /* min=0.0, max=4294967295.0, ident, limit=yes */
    uint32 U32_2; /* min=0.0, max=4294967295.0, ident, limit=yes */
#ifdef FLOAT32_SUPPORT
    real32 F32_1; /* min=-oo, max=+oo, ident, limit=no */
    real32 F32_2; /* min=-oo, max=+oo, ident, limit=no */
#endif
#ifdef FLOAT64_SUPPORT
    real64 F64_1; /* min=-oo, max=+oo, ident, limit=no */
    real64 F64_2; /* min=-oo, max=+oo, ident, limit=no */
#endif
} tCalMeasureV2;
#endif

#ifdef CAL_MEASURE_BLOCKS
typedef struct stCalMeasureBlocks
{
    sint8 Sint8_matrix[30];   /* min=-128.0, max=127.0, ident, limit=no */
    uint8 Uint8_matrix[30];   /* min=0.0, max=255.0, ident, limit=no */
    sint16 Sint16_matrix[30]; /* min=-32768.0, max=32767.0, ident, limit=no */
    uint16 Uint16_matrix[30]; /* min=0.0, max=65535.0, ident, limit=no */
    sint32 Sint32_matrix[30]; /* min=-2147483648.0, max=2147483647.0, ident, limit=no */
    uint32 Uint32_matrix[30]; /* min=0.0, max=4294967295.0, ident, limit=no */

    sint8 Sint8_array[6]; /* min=-128.0, max=127.0, ident, limit=no */
    uint8 Uint8_array[6]; /* min=0.0, max=255.0, ident, limit=no */
    sint16 Sint16_array[6];   /* min=-32768.0, max=32767.0, ident, limit=no */
    uint16 Uint16_array[6];   /* min=0.0, max=65535.0, ident, limit=no */
    sint32 Sint32_array[6];   /* min=-2147483648.0, max=2147483647.0, ident, limit=no */
    uint32 Uint32_array[6];   /* min=0.0, max=4294967295.0, ident, limit=no */

#ifdef FLOAT32_SUPPORT
    real32 Fl32_matrix[30];   /* min=-oo, max=+oo, ident, limit=no */
    real32 Fl32_array[6]; /* min=-oo, max=+oo, ident, limit=no */
#endif
#ifdef FLOAT64_SUPPORT
    real64 Fl64_matrix[30];   /* min=-oo, max=+oo, ident, limit=no */
    real64 Fl64_array[6]; /* min=-oo, max=+oo, ident, limit=no */
#endif
} tCalMeasureBlocks;
#endif
// ***** !Structs *****

// ***** Function declarations *****
void MEAS_UpdateEmuRamTestingVariables(void);
void MEAS_RasterCountersM33Init(void);
void MEAS_RasterCountersM33(uint8 index);
void MEAS_IncrementFctM33(VOLATILE_DEF tMeas* meas);
void MEAS_PrescalerLedBlinkingM33(void);


#ifdef CAL_MEASURE_BLOCKS
void MEAS_UpdateCalMeasureBlocks(void);
#endif
// ***** !Function declarations *****

extern VOLATILE_DEF tMeas M_I_RasterMeasM33[];
extern VOLATILE_DEF tMeas M_E_RasterMeasM33[];


extern VOLATILE_DEF uint32 DistabExecTimeM33[];

#endif

