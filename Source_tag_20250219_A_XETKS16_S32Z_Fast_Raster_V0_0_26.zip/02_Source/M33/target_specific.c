/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

/* ---------------------------------------------------------------------------- */
/* INCLUDES                                                                     */
/* ---------------------------------------------------------------------------- */

#include "target_specific.h"
#include "base.h"
#include "ETK_SectionMacro.h"
#include "wdt.h"


#ifdef COORDINATED_CORE_START
//Use this to coordinate that init between cores.
PRE_SECTION_BSS(cores_ready, ".common_core_share")
volatile uint8 cores_ready[eCORE_MAX]={0};
POST_SECTION_BSS()
#endif 

PRE_SECTION_BSS(AliveCounter, ".common_core_share")
//This is here because is is shared between all cores and is used to see if the cores are running
volatile uint32 AliveCounter[eCORE_MAX] = { 0 };
POST_SECTION_BSS()

/*############################################################################################
#ARM Get Core ID
############################################################################################
*/
uint8 Get_Core_ID(void) {
    uint32 corenum= *(uint32 *)(MSCM_COREXNUM);

    return (uint8)(corenum);
}



/*----------------------------------------------------------------------------*
 *  Function: GetCoreIndex(void)
 *
 *  Purpose: This function translates from the core identifier to the index used
 *           in this application for things like array indexes.
 *           R52 Cores will be 0-4 M33 is 8 lock steps are not used separately
 */
uint8 GetCoreIndex(void)
{
    return (eCORE_M33_INDEX);
}

/*----------------------------------------------------------------------------*
 *  Function: AllCoresReady(void)
 *
 *  Purpose: This function is used to know when to start the tasks on all the
 *           cores.  It is used when a coordination is needed between the cores
 *           before starting.
 */
bool GetAllCoresReady(void) {
    bool status=TRUE;
    for(int n=0; n< eCORE_MAX; n++) {
        if( 0==cores_ready[n]) {
            status=FALSE; //If any core is not ready set flag and exit
            break;
        }
    }
    return status;
}



/*----------------------------------------------------------------------------*
 *  Function: AllCoresReady(void)
 *
 *  Purpose: This function is used to know when to start the tasks on all the
 *           cores.  It is used when a coordination is needed between the cores
 *           before starting.
 */
bool WaitAllCoresReady(uint32 timeout_ms) {
    bool status=TRUE;
    bool timeout=FALSE;
    uint32 start = BASE_GetSystemTime();
 	while( !GetAllCoresReady() && !timeout) {
     	SetCoreReady();  //Works better if also set here
        timeout=BASE_Check_Timeout(start, timeout_ms*1000);
        WDT_Service();
    };
    if( timeout){
        status=FALSE;
    }
    return status;
}

/*----------------------------------------------------------------------------*
 *  Function: SetCoreReady(void)
 *
 *  Purpose: This function is used to set the state of a core so that the
 *           start the tasks on all the cores.  It is used when a coordination
 *           is needed between the cores before starting.
 */
void SetCoreReady(void) {
    eCORE_INDEX_T idx=GetCoreIndex();
    if( eCORE_MAX > idx){
        cores_ready[idx]=TRUE;
    }
}

/*----------------------------------------------------------------------------*
 *  Function: GetCoreStatus()
 *
 *  Purpose: This function is used to get the state of a core so that the
 *           start the tasks on all the cores.  It is used when a coordination
 *           is needed between the cores before starting.
 */
bool GetCoreStatus(uint8 core_index) {
    bool status=FALSE;
    if( eCORE_MAX > core_index){
        status=cores_ready[core_index];
    }
    return status;
}


/*----------------------------------------------------------------------------*
 *  Function: UpdateCoreAliveCounter()
 *
 *  Purpose: This function is used to increment a counter that corresponds to a
 *           core so that we can see that the core is running. This is intended
 *           to be called from a user periodic task.
 */
void UpdateCoreAliveCounter(void){
    eCORE_INDEX_T idx=GetCoreIndex();
    if( eCORE_MAX > idx){
    	uint32 tmp=AliveCounter[idx];
    	tmp++;
        AliveCounter[idx]=tmp;
    }

}

/*
uint32 corenum_correct[4]={0};
uint32 corenum_incorrect[4]={0};
uint32 corenum_incorrect_value[4][10]={
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678},
		{0x12345678, 0x12345678,0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678,	0x12345678}
};
void GetCoreNum(uint8 idx)
{
	uint32_t corenum= (*( uint32_t *)(MSCM_COREXNUM));
	uint8_t corenum8= (uint8_t)(*( uint32_t *)(MSCM_COREXNUM));
	int n;
	if(idx == corenum8)
	{
		corenum_correct[idx]++;
	}
	else
	{
		corenum_incorrect[idx]++;
		for(n=0;n<10;n++)
		{
			if( 0x12345678 == corenum_incorrect_value[idx][n])
			{
				corenum_incorrect_value[idx][n]=corenum;
				break;
			}
		}

	}
}

void GetCoreNum2(uint8 idx)
{
	uint8_t corenum= (uint8_t)(*( uint32_t *)(MSCM_COREXNUM));
	int n;
	if(idx == (uint8_t)corenum)
	{
		corenum_correct[idx]++;
	}
	else
	{
		corenum_incorrect[idx]++;
		for(n=0;n<10;n++)
		{
			if( 0x12345678 == corenum_incorrect_value[idx][n])
			{
				corenum_incorrect_value[idx][n]=corenum;
				break;
			}
		}

	}
}
*/

void DisableCache(void)
{
	SMU__LMEM64.PCCCR.B.ENCACHE=0;
}


void InvalidateCache(void)
{
	SMU__LMEM64.PCCCR.B.GO=1;
}
