/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

#include "etas_asw.h"

#ifdef INCA_CORE_R52
void ETAS_EtkHandshakeCheckAndExecuteStartup(void)
{

    SER_Initial_Handshake_Execute();
}

void ETAS_EtkHandshakeCheckAndExecuteCyclic(void)
{

    // Cyclic checks the Mailbox IN if there is a new handshake
    if ((eNone == handshakeType) || (eAdvanced == handshakeType && ECU_ETK_ADV_Status.ETK_ES_Master_Present == 0))
    {
        if (SER_ETK_Check_Protocol_Handshake())
        {
            SER_ETK_Handshake_End();

#ifdef RS232_DEBUG_LOGGING
            RS232_TxString("Cyclic Handshake !\r\n");
            RS232_PrintHandshakeInfo();
#endif

            //SER_ETK_AfterHandshake is not called because Coldstart, RP_Wait and Flash Request is already missed
        }
    }
}

void ETAS_PageSwitchCheckAndExecution(void)
{
    /* Verification if ETK is available is possible in order to avoid checking page switch request when no ETK is connected */

    /* Check if page switch was requested */
    if (SER_ETK_Page_Switch_Check_By_ECU() == 1)
    {
        /* Page Switch Requested */
        SER_ETK_Page_Switch_By_ECU();
    }
}

void ETAS_CopyCodeCheckCyclic(void)
{
    /* All if's and variables below are just relevant for System Test */

    /* Advanced code check --  copies the flash code check pattern to the ram address */
    CodeCheckCylceTime_ASD = ACTIVE_PAGE_UINT32(P_CodeCheckCycleTime_ASD);
    /* P_CodeCheckCycleTime_ASD is deprecated, it used to calibrate how often the copy would happen */
    /* This check below is kept in order to avoid copying if this value is 0 */
    if (ACTIVE_PAGE_UINT32(P_CodeCheckCycleTime_ASD) != 0)
    {
        if (ACTIVE_PAGE_UINT8(P_WriteCodeCheckPattern_cyclic_Enable) == 1)
        {
            CopyCodeCheckPattern_cyclic(ACTIVE_PAGE_UINT8(P_Change_RAM_Pattern)); /* arg: 0 -> copy correct pattern; 1 -> copy wrong patter (for test purposes only) */
        }
    }
}

#endif

/* This function performs the Distab copy process and trigger. It should be called at the end of each task (raster) with the proper Event ID */
void ETAS_DistabProcessWithTiming(uint32 index)
{
    /* Verification if ETK is available is possible in order to avoid processing table when no ETK is connected */
    DISTAB_TIMING_PRE();
    InvalidateCache(); /* Clears the cache. Thus the calibration values are seen correctly by the uC. */

    Distab17_Process(index);

#ifdef TRACE_SUPPORT
    /*
    This is the trigger for "normal" trace controlled by the customer. Supplementary D17 trace trigger is performed inside of D17 function.
    It could be triggered at the end of the task directly, but in this example it is inside of this function for convenience.
    If SUD17_32BIT is needed then you can only successfully use the trace overlay on variables that are updated in 32bit accesses
    */
    traceTrigger = index;
 #endif

    DISTAB_TIMING_POST(index);
}

