/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include <string.h>
#include "base.h"
#include "Serial/serial.h"
#include "Serial/stdio_func.h"
#include "hw_type.h"

#include "ETK_Integration_cfg.h"
#include "version_defs.h"

#ifdef RS232_DEBUG_LOGGING
#include "rs232.h"

uint8 RS232DebugLevel = RS232_DEBUG_LEVEL;

#ifdef INCA_CORE_R52

#include "ETK_SER_Handshake.h"

//get project info
void RS232_ProjectInfo(void)
{

    RS232_TxString("********************************************************\n\r");
    RS232_TxString("*                   ETAS Group                         *\n\r");
    RS232_TxString("*                      S32Z                            *\n\r");
    RS232_TxString("*                                                      *\n\r");
#if (defined CPUTYPE_RH850_E2x_FCC1)
    RS232_TxString("*      RH850 E2xFCC1 project for XETK-S22/FETK-T3      *\n\r");
    RS232_TxString("*                    without RTA-OS     *\n\r");
#endif

#if (defined CPUTYPE_RH850_E2x_FCC2)
    RS232_TxString("*      RH850 E2xFCC2 project for XETK-S22/FETK-T3      *\n\r");
    RS232_TxString("*                    without RTA-OS     *\n\r");
#endif

#if (defined CPUTYPE_RH850_E2x_PD)
    RS232_TxString("*             RH850 E2x PD project for XETK-S22        *\n\r");
    RS232_TxString("*                    without RTA-OS     *\n\r");
#endif
    RS232_TxString("*                                                      *\n\r");

    RS232_TxString("*           version:      ");
    RS232_TxDecByte(VERSION_X);
    RS232_TxString(".");
    RS232_TxDecByte(VERSION_Y);
    RS232_TxString(".");
    RS232_TxDecByte(VERSION_Z);
    RS232_TxString("                       *\n\r");
    RS232_TxString("*           compiled at: ");

    RS232_TxString(" ");
	RS232_TxString( __DATE__);
	RS232_TxString(" ");
	RS232_TxString( __TIME__);

    RS232_TxString("         *\r\n");

    RS232_TxString("*                                                      *\n\r");

    RS232_TxString("********************************************************\n\r");
}

void RS232_CmdInfo(void)
{

    RS232_TxString("********************************************************\n\r");
    RS232_TxString("* please select:                                       *\n\r");
    RS232_TxString("* <m>       Command Menu                               *\n\r");
    RS232_TxString("* <p>       Project Information                        *\n\r");
    RS232_TxString("* <0-4>     RS232 Debug Information Level              *\n\r");
    RS232_TxString("********************************************************\n\r");
}


//RS232 Debug Info
void RS232_DebugInfo(void)
{
    uint8 ReceiveData;

    ReceiveData = RS232_GetData(); // Returns the input value if it is different from the previous one only !!

    //check if received data is valid
    if (ReceiveData != 0)
    {
        //check Receive Data
        switch (ReceiveData)
        {
        case 0x00:
            break;

        case 0x30:
        case 0x31:
        case 0x32:
        case 0x33:
        case 0x34: // <0-4>
            RS232DebugLevel = ReceiveData - 0x30;
            RS232_TxString("RS232 Debug Information Level ");
            RS232_TxDecByte(RS232DebugLevel);
            RS232_TxString(" is selected\r\n");
            break;

        case 0x70: // <p>
            RS232_ProjectInfo();
            break;

        case 0x6D: // <m>
        	RS232_CmdInfo();

        default:
            // We should not send any message here because if a tool writes by mistake a value in the RS232 input this will delay greatly the other tasks of the project (delay between 10ms and 200 ms)
            break;
        }
    }
}

/* This function reads out the content of the receive buffer register which contains the received data.
It will return 0 if the read value is the same as the previous one or return the value if there is a difference. */
uint8 RS232_GetData(void)
{
	if(eHW_Type_TU16 == M_Hardware_Type)
	{
	    char recbuf[2];
		uart_0_getchar(&recbuf[0]);
		return (uint8)recbuf[0];
	}
	else
	{
		return 0;
	}

}


void RS232_PrintHandshakeInfo(void)
{

    if (handshakeType == eNone)
    {
        RS232_TxString("No ETK was detected or detected wrongly. Disable Distabs to prevent incorrect Distab execution !\r\n");
    }
    else if (handshakeType == eLegacy)
    {
        if (ECU_ETK_Status.ETK_Available)
        {
            RS232_TxString("(X)ETK detected and available !\r\n");
            RS232_TxString("Legacy Handshake Register was used !\r\n");

            if (ECU_ETK_Status.ETK_Power_Failure)
            {
                RS232_TxString("Power failure detected !\r\n");
                RS232_TxString_Debug_Level_4("Serial ETK: Disable Distabs after power failure to prevent incorrect Distab execution !\r\n");
            }
            else
            {
                RS232_TxString("NO power failure !\r\n");
            }
        }
        else
        {
            RS232_TxString("Legacy Handshake Register was used but no (x)ETK performed the handshake, so (X)ETK is not available !\r\n");
        }
    }
    else if (handshakeType == eAdvanced)
    {
        if (ECU_ETK_ADV_Status.ETK_Available)
        {
            RS232_TxString("(F/X)ETK detected and available !\r\n");

            if (handshakeStored[1] == 0) // First Handshake
            {
                RS232_TxString("Advanced Handshake Register was used with first pattern = 0x");
                RS232_TxHexLong(handshakeStored[0]);
                RS232_TxString(" !\r\n");

            }
            else
            {
                RS232_TxString("Advanced Handshake Register was used with second pattern = 0x");
                RS232_TxHexLong(handshakeStored[1]);
                RS232_TxString(" !\r\n");
            }

            if (!ECU_ETK_ADV_Status.ETK_ES_Master_Present)
            {
                RS232_TxString("ES Master is not Present, 2nd handshake might happen\r\n");
            }

            if (!ECU_ETK_ADV_Status.ETK_RAM_Valid)
            {
                RS232_TxString("Power failure on RAM detected !\r\n");
            }

            if (!ECU_ETK_ADV_Status.ETK_Data_Valid)
            {
                RS232_TxString("Power failure on DATA detected !\r\n");
            }

            if (ECU_ETK_ADV_Status.ETK_MC_Wait)
            {
                RS232_TxString("ColdStart Requested !\r\n");
            }

            if (ECU_ETK_ADV_Status.ETK_RP_Wait)
            {
                RS232_TxString("RP Wait Requested !\r\n");
            }

            if (ECU_ETK_ADV_Status.ETK_CalWakeUp)
            {
                RS232_TxString("Calibration Wake Up Requested !\r\n");
            }

            if (ECU_ETK_ADV_Status.ETK_Flash_Request)
            {
                RS232_TxString("Flash Request Requested !\r\n");
            }

        }
        else
        {
            RS232_TxString("Advanced Handshake Register was used but no (F/X)ETK performed the handshake, so (F/X)ETK is not available !\r\n");
        }
    }
}

#endif //INCA_CORE_R52

void RS232_TxByte(char cData)
{
    printf("%c", cData);
}


void RS232_TxHexByte(uint8 ucData)
{
    printf("%02X", ucData);
}

void RS232_TxDecByte(uint8 ucData)
{
    printf("%02d", ucData);
}


void RS232_TxHexWord(uint16 uwData)
{
    printf("%04X", uwData);
}
void RS232_TxHexLong(uint32 ulData)
{
    printf("%08X", (unsigned int)(ulData));
}

void RS232_TxString(CONST_DEF char* str)
{
    printf((char *)str);
}

void RS232_TxString_Debug_Level_2(char* str)
{
    if(2<=RS232DebugLevel)
    {
        printf(str);
    }
}

void RS232_TxString_Debug_Level_3(char* str)
{
    if(3<=RS232DebugLevel)
    {
        printf(str);
    }
}

void RS232_TxString_Debug_Level_4(char* str)
{
    if(4<=RS232DebugLevel)
    {
        printf(str);
    }
}


#endif
