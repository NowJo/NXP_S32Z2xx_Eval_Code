


#include "wdt.h"
#include "base.h"
#include "target_specific.h"
    
#ifdef USE_WDT

void WDT_Init(void)
{
  uint8 cpu_id=Get_Core_ID();
  uint32 wdt_timeout = MSEC_TO_TICKS(30);
  
  //Fixed Service Sequence. To service the watchdog, write the fixed sequence 0xA602, 0xB480 to SR.
  switch(cpu_id)
  {
   case eCORE_R52_0_INDEX:
    		/* Clear soft lock bit */
    		RTU0__SWT_0.SR.R = SWT_SERVICE_CODE_SLK_1;  //Clear soft lock bit 1/2
    		RTU0__SWT_0.SR.R = SWT_SERVICE_CODE_SLK_2;  //Clear soft lock bit 2/2

    	    while(RTU0__SWT_0.CR.B.SLK == 1);
    	     /*set timeout period */
    	    RTU0__SWT_0.TO.R = wdt_timeout;
    	     /*enable the watchdog, stop watchdog in debug mode */
    	   //RTU0__SWT_0.CR.R = 0xFF000141; //Generate a interrupt request
    	    RTU0__SWT_0.CR.R = 0xFF000103; //Generate a reset request
    	     /*Clear SWT Interrupt flag */
    	    RTU0__SWT_0.IR.B.TIF = 1;
    break;

   case eCORE_R52_1_INDEX:
    		/* Clear soft lock bit */
    		RTU0__SWT_1.SR.R = SWT_SERVICE_CODE_SLK_1;  //Clear soft lock bit 1/2
    		RTU0__SWT_1.SR.R = SWT_SERVICE_CODE_SLK_2;  //Clear soft lock bit 2/2

    	    while(RTU0__SWT_0.CR.B.SLK == 1);
    	     /*set timeout period */
    	    RTU0__SWT_1.TO.R = wdt_timeout;
    	     /*enable the watchdog, stop watchdog in debug mode */
    	   //RTU0__SWT_0.CR.R = 0xFF000141; //Generate a interrupt request
    	    RTU0__SWT_1.CR.R = 0xFF000103; //Generate a reset request
    	     /*Clear SWT Interrupt flag */
    	    RTU0__SWT_1.IR.B.TIF = 1;
    break;

   case eCORE_R52_2_INDEX:
    		/* Clear soft lock bit */
    		RTU0__SWT_2.SR.R = SWT_SERVICE_CODE_SLK_1;  //Clear soft lock bit 1/2
    		RTU0__SWT_2.SR.R = SWT_SERVICE_CODE_SLK_2;  //Clear soft lock bit 2/2

    	    while(RTU0__SWT_2.CR.B.SLK == 1);
    	     /*set timeout period */
    	    RTU0__SWT_2.TO.R = MSEC_TO_TICKS(30);
    	     /*enable the watchdog, stop watchdog in debug mode */
    	   //RTU0__SWT_0.CR.R = 0xFF000141; //Generate a interrupt request
    	    RTU0__SWT_2.CR.R = 0xFF000103; //Generate a reset request
    	     /*Clear SWT Interrupt flag */
    	    RTU0__SWT_2.IR.B.TIF = 1;
    break;

   case eCORE_R52_3_INDEX:
    		/* Clear soft lock bit */
    		RTU0__SWT_3.SR.R = SWT_SERVICE_CODE_SLK_1;  //Clear soft lock bit 1/2
    		RTU0__SWT_3.SR.R = SWT_SERVICE_CODE_SLK_2;  //Clear soft lock bit 2/2

    	    while(RTU0__SWT_3.CR.B.SLK == 1);
    	     /*set timeout period */
    	    RTU0__SWT_3.TO.R = wdt_timeout;
    	     /*enable the watchdog, stop watchdog in debug mode */
    	   //RTU0__SWT_0.CR.R = 0xFF000141; //Generate a interrupt request
    	    RTU0__SWT_3.CR.R = 0xFF000103; //Generate a reset request
    	     /*Clear SWT Interrupt flag */
    	    RTU0__SWT_3.IR.B.TIF = 1;
    break;
    
   case eCORE_M33_INDEX:
	   /*Disable other WDT interrupts */
		RTU0__SWT_0.CR.B.WEN=0;
		RTU0__SWT_1.CR.B.WEN=0;
		RTU0__SWT_2.CR.B.WEN=0;
		RTU0__SWT_3.CR.B.WEN=0;
		RTU1__SWT_0.CR.B.WEN=0;
		RTU1__SWT_1.CR.B.WEN=0;
		RTU1__SWT_2.CR.B.WEN=0;
		RTU1__SWT_3.CR.B.WEN=0;

		/* Clear soft lock bit */
		SMU__SWT.SR.R = SWT_SERVICE_CODE_SLK_1;  //Clear soft lock bit 1/2
		SMU__SWT.SR.R = SWT_SERVICE_CODE_SLK_2;  //Clear soft lock bit 2/2

	    while(SMU__SWT.CR.B.SLK == 1);
	     /*set timeout period */
		SMU__SWT.TO.R = wdt_timeout;
	     /*enable the watchdog, stop watchdog in debug mode */
	   //SWT_0.CR.R = 0xFF000141; //Generate a interrupt request
		SMU__SWT.CR.R = 0xFF000103; //Generate a reset request
	     /*Clear SWT Interrupt flag */
		SMU__SWT.IR.B.TIF = 1;

  }
}

void WDT_Service(void)
{
  uint8 cpu_id=Get_Core_ID();

  //Fixed Service Sequence. To service the watchdog, write the fixed sequence 0xA602, 0xB480 to SR.
  switch(cpu_id)
  {
  case eCORE_R52_0_INDEX:
     RTU0__SWT_0.SR.R = SWT_SERVICE_CODE_1;
     RTU0__SWT_0.SR.R = SWT_SERVICE_CODE_2;
     break;
  case eCORE_R52_1_INDEX:
     RTU0__SWT_1.SR.R = SWT_SERVICE_CODE_1;
     RTU0__SWT_1.SR.R = SWT_SERVICE_CODE_2;
     break;
  case eCORE_R52_2_INDEX:
     RTU0__SWT_2.SR.R = SWT_SERVICE_CODE_1;
     RTU0__SWT_2.SR.R = SWT_SERVICE_CODE_2;
     break;
  case eCORE_R52_3_INDEX:
     RTU0__SWT_3.SR.R = SWT_SERVICE_CODE_1;
     RTU0__SWT_3.SR.R = SWT_SERVICE_CODE_2;
     break;
     
  case eCORE_M33_INDEX:
	 SMU__SWT.SR.R = SWT_SERVICE_CODE_1;
	 SMU__SWT.SR.R = SWT_SERVICE_CODE_2;
     break;
  }
}


void WDT_Disable(void)
{
	SMU__SWT.CR.B.WEN=0;
	RTU0__SWT_0.CR.B.WEN=0;
	RTU0__SWT_1.CR.B.WEN=0;
	RTU0__SWT_2.CR.B.WEN=0;
	RTU0__SWT_3.CR.B.WEN=0;
	RTU1__SWT_0.CR.B.WEN=0;
	RTU1__SWT_1.CR.B.WEN=0;
	RTU1__SWT_2.CR.B.WEN=0;
	RTU1__SWT_3.CR.B.WEN=0;
}


#endif //USE_WDT


void WDT_Wait_To_Die(void)
{
#ifdef USE_WDT
	  uint8 cpu_id=Get_Core_ID();
	  uint32 wen=0;

	  //Fixed Service Sequence. To service the watchdog, write the fixed sequence 0xA602, 0xB480 to SR.
	  switch(cpu_id)
	  {
	  case eCORE_R52_0_INDEX:
		 wen=RTU0__SWT_0.CR.B.WEN;
	     break;
	  case eCORE_R52_1_INDEX:
		 wen=RTU0__SWT_0.CR.B.WEN;
	     break;
	  case eCORE_R52_2_INDEX:
		 wen=RTU0__SWT_0.CR.B.WEN;
	     break;
	  case eCORE_R52_3_INDEX:
		 wen=RTU0__SWT_0.CR.B.WEN;
	     break;

	  case eCORE_M33_INDEX:
 		 SMU__SWT.CR.R = 0xFF000103; //Generate a reset request
		 wen=SMU__SWT.CR.B.WEN=1;
	     break;
	  }

	  if(1==wen)
	  {
		  while(1);
	  }
#endif
	  RESET_CONTROLLER();
}

