
#ifndef _WDT_H_
#define _WDT_H_

//Do we use the WDT?
//#define USE_WDT

#include "s32z27.h"
#include "target_specific.h"


#ifdef USE_WDT

//  When CR[SMD] is keyed service mode to SR
#define SWT_SERVICE_CODE_SLK_1 0xC520
#define SWT_SERVICE_CODE_SLK_2 0xD928
#define SWT_SERVICE_CODE_1 0xA602
#define SWT_SERVICE_CODE_2 0xB480

//    RTU0__SWT_0.CO.B.CNT=0x100;
//    PMC.SSR.B.POR_WDOG_EVENT
    
void WDT_Init(void);
void WDT_Service(void);
void WDT_Disable(void);

#else

#define WDT_Init()
#define WDT_Service()
#define WDT_Disable()

#endif //USE_WDT

void WDT_Wait_To_Die(void);


#endif //_WDT_H_
