/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef __A_STD_TYPE_H__
#define __A_STD_TYPE_H__


/* The following is used to define variable types if not already available. See
 * target_specific.h for more details.  This file is provided for the needs of
 * the demonstrator but can easily been changed to eliminate types that are
 * missing in your environment.
 */

#if defined (__STDC_VERSION__) && (__STDC_VERSION__ >= 199901L)
 /*C99 compiler available */
 #if !defined(NO_STDINT_H)
  #include <stdint.h>
  #include <stdbool.h>
  #include <stddef.h>
 #endif /* !defined(NO_STDINT_H) */
#endif

#if !defined(GCC_VERSION)&&defined(__GNUC__)
#define GCC_VERSION (__GNUC__  \
                                   + __GNUC_MINOR__ / 100 \
                                   + __GNUC_PATCHLEVEL__ /10000)
#endif

#if defined(GCC_VERSION)&&(GCC_VERSION >= 10)
#include "PlatformTypes.h"
#else

#ifndef _STDBOOL_H
typedef unsigned char  bool;
#endif


#ifdef _UINT8_T_DECLARED
    typedef uint8_t uint8;
#else
    typedef unsigned char  uint8;
#endif
#ifdef _INT8_T_DECLARED
    typedef int8_t sint8;
#else
    typedef signed char    sint8;
#endif
#ifdef _UINT16_T_DECLARED
    typedef uint16_t uint16;
#else
    typedef unsigned short uint16;
#endif
#ifdef _INT16_T_DECLARED
    typedef int16_t sint16;
#else
    typedef signed short   sint16;
#endif
#ifdef _UINT32_T_DECLARED
    typedef uint32_t uint32;
#else
    typedef unsigned long  uint32;
#endif
#ifdef _INT32_T_DECLARED
    typedef int32_t sint32;
#else
    typedef signed long    sint32;
#endif

/* declared in GCC 10 compiler */
typedef volatile signed char        vint8_t;
typedef volatile unsigned char      vuint8_t;
typedef volatile signed short       vint16_t;
typedef volatile unsigned short     vuint16_t;
typedef volatile long signed int    vint32_t;
typedef volatile long unsigned int  vuint32_t;
typedef volatile signed long long   vint64_t;
typedef volatile unsigned long long vuint64_t;
#endif


#ifndef TRUE
 #if !defined(NO_STDINT_H)
    /*implements TRUE_FALSE_enumeration*/
    #define TRUE (true)
 #else
    #define TRUE (1)
 #endif /* !defined(NO_STDINT_H) */
#endif

#ifndef FALSE
 #if !defined(NO_STDINT_H)
    /*implements TRUE_FALSE_enumeration*/
    #define FALSE (false)
 #else
    #define FALSE (0)
 #endif /* !defined(NO_STDINT_H) */
#endif

typedef unsigned char  bit8;
typedef unsigned short bit16;
typedef unsigned long  bit32;

typedef unsigned int   uint;
typedef signed int     sint;
typedef double         real;
typedef float          real32;
typedef double         real64;


#ifndef TYPEDEF_ULONGULONG
#define TYPEDEF_ULONGULONG
typedef     struct ulonglong
{
    uint32      hWrd;
    uint32      lWrd;
} ustr64;
#endif // #ifndef TYPEDEF_ULONGULONG

#endif /* __A_STD_TYPE_H */
