/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef __GPIO_H__
#define __GPIO_H__

#include "ETK_Integration_Cfg.h"

//defines for LEDs
#define LED_ON 1
#define LED_OFF !LED_ON


#ifdef USE_IO
//The consecutive blinking is only on the TU16
#define CONSECUTIVE_LED_BLINKING_SUPPORT

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
#define LED_INCREASE 0
#define LED_DECREASE 1
// Time spent waiting in function execution cycles for the next LED to be set to output mode when the direction of the blinking changes.
#define LED_STANDBY_TIME 1

#define LED0_CONSECUTIVE  48    //PAD_048_ETH_1_MII_TXD_0
#define LED1_CONSECUTIVE  49    //PAD_049_ETH_1_MII_TXD_1
#define LED2_CONSECUTIVE  50    //PAD_050_ETH_1_MII_TXD_2
#define LED3_CONSECUTIVE  51    //PAD_051_ETH_1_MII_TXD_3
#define LED4_CONSECUTIVE  52    //PAD_052_ETH_1_MII_RXCLK
#define LED5_CONSECUTIVE  53    //PAD_053_ETH_1_MII_RXDV
#define LED6_CONSECUTIVE  54    //PAD_054_ETH_1_MII_RXD_0
#define LED7_CONSECUTIVE  55    //PAD_055_ETH_1_MII_RXD_1

#endif

#define LED_CAL 40   //This is CLKOUT1 on the board No LEDs available and is controlled by a calibration
#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
//These are only available on the TU16
#define LED_HSTYPE  LED0_CONSECUTIVE
#define LED_PAGE    LED1_CONSECUTIVE
#else
//#define LED_HSTYPE 0
//#define LED_PAGE 0
//#define LED_ALIVE 0
#endif
#define LED_ALIVE_M 41   //This is CLKOUT0 on the board No LEDs available


//functions
void GPIO_Init(void);
void GPIO_ToggleLED(uint8 PinNo);
void GPIO_TurnLedOn(uint8 PinNo);
void GPIO_TurnLedOff(uint8 PinNo);

#if defined(CONSECUTIVE_LED_BLINKING_SUPPORT)
void GPIO_Led_YesEtk(void);
void GPIO_Led_NoEtk(void);
void GPIO_LedBlinkingInit(uint8 mode);
#endif

void GPIO_Led_AdvHandshake(uint8 state);
void GPIO_Led_WP_Active(uint8 state);

#if defined(CONSECUTIVE_LED_BLINKING_SUPPORT)&&defined(INCA_CORE_R52)
void GPIO_LedBlinkingConsecutive(void);
#endif

#endif

#endif
