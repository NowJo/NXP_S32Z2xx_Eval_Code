/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "target_specific.h"
#include "ETK_Integration_Cfg.h"
#include "gpio.h"

PRE_SECTION_DATA(M_Hardware_TypeM33, ".HW_TYPE_M33")
volatile ENUM_HW_TYPE M_Hardware_TypeM33;
POST_SECTION_DATA()

PRE_SECTION_DATA(M_Hardware_Type, ".HW_TYPE")
volatile ENUM_HW_TYPE M_Hardware_Type;
POST_SECTION_DATA()


#define HARDWARE_IDENTIFICATION_TU16_TEST_PIN   135
#define HARDWARE_IDENTIFICATION_TU16_Source_PIN 136


#ifdef USE_IO

//How long do we give the signal to stabilize before we say it did not happen
#define MAX_LOOP_COUNTER_HW_ID 10


/* This hardware check is intended to be called at startup only once to avoid a issue with pins. */
ENUM_HW_TYPE HWT_IsTU16_Check(void)
{
    //Use a loop counter since this may be called before the timers are initialized!
	uint32 timeout=0;
	ENUM_HW_TYPE rtn=eHW_Type_Unknown;
    uint8 set_pin=1; //!(SIUL2_4.GPDO135.B.PDO_N);
    uint32 restore_MSCR_value[2];
    uint8 restore_GPD_SETTING[2];

    //To be correct this would disable interrupts also but we do not have them enabled in the refsys

    restore_MSCR_value[0] = SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_TEST_PIN].R;
    restore_MSCR_value[1] = SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_Source_PIN].R;

    restore_GPD_SETTING[0]=SIUL2_4.GPDO136.R;
    restore_GPD_SETTING[1]=SIUL2_4.GPDI135.R;


#if defined(HARDWARE_IDENTIFICATION_TU16_TEST_PIN)&&defined(HARDWARE_IDENTIFICATION_TU16_Source_PIN)
    /* These 2 pins are used to figure out if the Tu16 is attached because the two are tied together */
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_TEST_PIN].B.IBE = 1;  /* Input Buffer Enable */
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_TEST_PIN].B.TRC = 0;  /* Termination Resistor Control 1?? */
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_TEST_PIN].B.SSS = 0;  /* Source Signal Select */
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_TEST_PIN].B.OBE = 0;  /* GPIO Output Buffer Enable */

    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_Source_PIN].B.IBE = 0;  /* Input Buffer Enable */
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_Source_PIN].B.TRC = 0;  /* Termination Resistor Control */
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_Source_PIN].B.SSS = 0;  /* Source Signal Select */
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_Source_PIN].B.OBE = 1;  /* GPIO Output Buffer Enable */
#else
#error Must have the loopback pins defined
#endif
   	SIUL2_4.GPDO136.R = set_pin; //Set source to opposite of test pin

	while( 	SIUL2_4.GPDI135.R != set_pin  && MAX_LOOP_COUNTER_HW_ID>timeout++); //Check return pin status

	if( MAX_LOOP_COUNTER_HW_ID>timeout)
	{
        timeout=0;
		set_pin=!set_pin;

		SIUL2_4.GPDO136.R = set_pin; //Set pin low
		while( 	SIUL2_4.GPDI135.R != set_pin  && MAX_LOOP_COUNTER_HW_ID>timeout++); //Check return pin status

		if( MAX_LOOP_COUNTER_HW_ID>timeout)
		{
			rtn=eHW_Type_TU16; //Now we know this is a TU16!
		}
	}

	SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_TEST_PIN].R = restore_MSCR_value[0];
    SIUL2_4.MSCR[HARDWARE_IDENTIFICATION_TU16_Source_PIN].R=restore_MSCR_value[1];
    SIUL2_4.GPDO136.R=restore_GPD_SETTING[0];
    return rtn;
}
#endif  //USE_IO

