/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

/* ---------------------------------------------------------------------------- */
/* INCLUDES                                                                     */
/* ---------------------------------------------------------------------------- */
#include "target_specific.h"
#include "base.h"
#include "gpio.h"
#include "meas_cal.h"
#include "etas_asw.h"
#include "Os_Tasks_Cpu3.h"
#include "main_cpu3.h"
#include "wdt.h"

#ifdef D13_SUPPORT
#include "ETK\Distab13_Fct.h"
#endif

#ifdef UFE_SUPPORT
#include "ufe.h"
#endif

#ifdef SLEW_SUPPORT
#include "slew.h"
#endif

#ifdef RS232_DEBUG_LOGGING
#include "rs232.h"
#endif

/* ---------------------------------------------------------------------------- */
/* MACROS                                                                       */
/* ---------------------------------------------------------------------------- */
#define CORE_ID eCORE_R52_3_INDEX

/* ---------------------------------------------------------------------------- */
/* FUNCTIONS PROTOTYPES                                                         */
/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* VARIABLES                                                                    */
/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* TARGET SPECIFIC FUNCTIONS                                                    */
/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* USER TASKS                                                                   */
/* ---------------------------------------------------------------------------- */
void Task_Init_Impl_Cpu3(void)
{
#ifdef RS232_DEBUG_LOGGING
    RS232_TxString("Cpu3 Starting...\r\n"); // project information
#endif

}

/* 50us Task
void Task_50us_Impl_Cpu3(void)
{
    MEAS_RasterCounters(R30);
    ETAS_DistabProcessWithTiming(R30);
}
*/

void Task_1ms_Impl_Cpu3(void)
{
    MEAS_RasterCounters(R28);
    MEAS_TraceCounters(&pe3TraceVar_01);
    ETAS_DistabProcessWithTiming(R28);
}

void Task_5ms_Impl_Cpu3(void)
{
    /* Periodic Check for Page Switch and Execution if requested is done in Cpu0*/
    /* Advanced code check --  copies the flash code check pattern to the ram address in Cpu0*/

    MEAS_RasterCounters(R29);
    ETAS_DistabProcessWithTiming(R29);
}

void Task_10ms_Impl_Cpu3(void)
{
	WDT_Service();
	InvalidateCache();
    MEAS_RasterCounters(R30);
    ETAS_DistabProcessWithTiming(R30);
}

void Task_20ms_Impl_Cpu3(void)
{
    MEAS_RasterCounters(R31);
    ETAS_DistabProcessWithTiming(R31);
}

void Task_50ms_Impl_Cpu3(void)
{
    MEAS_RasterCounters(R32);
    ETAS_DistabProcessWithTiming(R32);
}

void Task_100ms_Impl_Cpu3(void)
{
    MEAS_RasterCounters(R33);
    ETAS_DistabProcessWithTiming(R33);
}

void Task_200ms_Impl_Cpu3(void)
{
    MEAS_RasterCounters(R34);
    MEAS_UpdateEmuRamTestingVariables(); /* Updates the measurements of the corresponding test calibration parameters */
    ETAS_DistabProcessWithTiming(R34);
}

void Task_500ms_Impl_Cpu3(void)
{

#ifdef RS232_DEBUG_LOGGING
    RS232_DebugInfo();
#endif

    MEAS_RasterCounters(R35);
    ETAS_DistabProcessWithTiming(R35);
}

void Task_1000ms_Impl_Cpu3(void)
{
    UpdateCoreAliveCounter();
    MEAS_RasterCounters(R36);
    ETAS_DistabProcessWithTiming(R36);
}


void Task_Idle_Cpu3(void)
{
}

/* ---------------------------------------------------------------------------- */
/* MAIN FUNCTION                                                                */
/* ---------------------------------------------------------------------------- */
void Start_Cpu3(void)
{
	InvalidateCache();
   //Board init was done in SMU

    Task_Init_Impl_Cpu3();

    WDT_Init();
    OS_StartOs_Cpu3();
}

