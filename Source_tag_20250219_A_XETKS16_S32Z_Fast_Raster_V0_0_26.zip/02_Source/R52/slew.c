/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

#include "slew.h"

#ifdef SLEW_SUPPORT
PRE_SECTION_DATA(".IRAM_DATA")
VOLATILE_DEF tTestingRangeVar TestingRange_01 = { {2147483647, 32767, 127, 0}, {0, 0, 0, 0} };
POST_SECTION_DATA()

PRE_SECTION_RODATA(".SLEW_DATA")
CONST_DEF VOLATILE_DEF tSlewRange SlewRange_01 = { { {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0} }, { {0, 0, 0}, {0, 0, 0}, {0, 0, 0, 0} }, {0} };
POST_SECTION_RODATA()

void SLEW_SlewInit(void)
{
    TestingRange_01.Static.U8 = 127;
    TestingRange_01.Static.U16 = 32767;
    TestingRange_01.Static.U32 = 2147483647;
    TestingRange_01.Counter.U8 = 0;
    TestingRange_01.Counter.U16 = 0;
    TestingRange_01.Counter.U32 = 0;
}

void SLEW_SlewProcess(void)
{
    TestingRange_01.Static.U8 = 127;
    TestingRange_01.Static.U16 = 32767;
    TestingRange_01.Static.U32 = 2147483647;
    TestingRange_01.Counter.U8++;
    TestingRange_01.Counter.U16++;
    TestingRange_01.Counter.U32++;

    SLEW_SlewProcessTestingRange(&TestingRange_01, &SlewRange_01);
}

uint8 SLEW_SlewEvalU8(VOLATILE_DEF uint8 var, CONST_DEF VOLATILE_DEF tSlewU8* slew)
{
    if (ACTIVE_PAGE_UINT16(slew->state) == 0)
    {
        (var = var);
    }
    else if (ACTIVE_PAGE_UINT16(slew->state) == 1)
    {
        (var = var + ACTIVE_PAGE_UINT8(slew->modify));
    }
    else if (ACTIVE_PAGE_UINT16(slew->state) == 2)
    {
        (var = ACTIVE_PAGE_UINT8(slew->absolute));
    }

    return var;
}

uint16 SLEW_SlewEvalU16(VOLATILE_DEF uint16 var, CONST_DEF VOLATILE_DEF tSlewU16* slew)
{
    if (ACTIVE_PAGE_UINT16(slew->state) == 0)
    {
        (var = var);
    }
    else if (ACTIVE_PAGE_UINT16(slew->state) == 1)
    {
        (var = var + ACTIVE_PAGE_UINT16(slew->modify));
    }
    else if (ACTIVE_PAGE_UINT16(slew->state) == 2)
    {
        (var = ACTIVE_PAGE_UINT16(slew->absolute));
    }

    return var;
}

uint32 SLEW_SlewEvalU32(VOLATILE_DEF uint32 var, CONST_DEF VOLATILE_DEF tSlewU32* slew)
{
    if (ACTIVE_PAGE_UINT16(slew->state) == 0)
    {
        (var = var);
    }
    else if (ACTIVE_PAGE_UINT16(slew->state) == 1)
    {
        (var = var + ACTIVE_PAGE_UINT32(slew->modify));
    }
    else if (ACTIVE_PAGE_UINT16(slew->state) == 2)
    {
        (var = ACTIVE_PAGE_UINT32(slew->absolute));
    }

    return var;
}

void SLEW_SlewProcessTestingGroup(VOLATILE_DEF tTestingGroupVar* var, CONST_DEF VOLATILE_DEF tSlewGroup* slewgroup)
{
    var->U8 = SLEW_SlewEvalU8(var->U8, &slewgroup->SlewU8);
    var->U16 = SLEW_SlewEvalU16(var->U16, &slewgroup->SlewU16);
    var->U32 = SLEW_SlewEvalU32(var->U32, &slewgroup->SlewU32);
}

void SLEW_SlewProcessTestingRange(VOLATILE_DEF tTestingRangeVar* var, CONST_DEF VOLATILE_DEF tSlewRange* slewrange)
{
    SLEW_SlewProcessTestingGroup(&var->Static, &slewrange->Static);
    SLEW_SlewProcessTestingGroup(&var->Counter, &slewrange->Counter);
}

#endif
