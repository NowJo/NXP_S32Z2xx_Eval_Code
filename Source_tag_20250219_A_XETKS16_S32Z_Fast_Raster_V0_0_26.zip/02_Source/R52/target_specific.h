/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef _TARGET_SPECIFIC_H_
#define _TARGET_SPECIFIC_H_

#include "a_std_type.h"
#include "S32Z27.h"
#include "hw_type.h"

/* Including needed modules to compile this module/procedure */
#include "project.h"  //Is it a multicore project?


#ifndef ENABLE_INTERRUPT
#define ENABLE_INTERRUPT() __asm__ volatile ("cpsie i"); /* Clear PRIMASK */
#endif
#ifndef DISABLE_INTERRUPT
#define DISABLE_INTERRUPT() __asm__ volatile ("cpsid i"); /* Set PRIMASK */
#endif

//The USE_TRIGGER_SEMAPHORE is needed when using multiple cores with the same trigger to prevent loss of data
//Using separate trigger locations
//#define USE_TRIGGER_SEMAPHORE

#ifdef USE_TRIGGER_SEMAPHORE
#include <stdatomic.h>
#endif

/* ---------------------------------------------------------------------------- */
/* CPU specific Settings                                                        */
/* This is used to let the application how to convert mailbox information from  */
/* the host system.                                                             */
/* ---------------------------------------------------------------------------- */
// Distinguish between Motorola / Intel Type Memory Usage
#if defined(__BYTE_ORDER) && __BYTE_ORDER == __BIG_ENDIAN || \
    defined(__BIG_ENDIAN__) || \
    defined(__ARMEB__) || \
    defined(__THUMBEB__) || \
    defined(__AARCH64EB__) || \
    defined(_MIBSEB) || defined(__MIBSEB) || defined(__MIBSEB__)
// It's a big-endian target architecture
    #define PROCESSOR_MEM_TYPE_BIG_ENDIAN     // Motorola Type Memory Usage
#elif defined(__BYTE_ORDER) && __BYTE_ORDER == __LITTLE_ENDIAN || \
    defined(__LITTLE_ENDIAN__) || \
    defined(__ARMEL__) || \
    defined(__THUMBEL__) || \
    defined(__AARCH64EL__) || \
    defined(_MIPSEL) || defined(__MIPSEL) || defined(__MIPSEL__)
// It's a little-endian target architecture
    #define PROCESSOR_MEM_TYPE_LITTLE_ENDIAN  // Intel Type Memory Usage
#else
    //Could make this default instead of error but could end up with issues
#error "I don't know what architecture this is, in order to define byte order!"
#endif


//Any decent optimizer will resolve this at compile-time. gcc does at -O1.
#define Is_Big_Endian()    (*(etas_uint16 *)"\0\xff" < 0x100)
#define Is_Little_Endian() (*(etas_uint16 *)"\0\xff" > 0x100)


#define MSCM_COREXTYPE 0x419A0000
#define MSCM_COREXNUM  0x419A0004

/* ---------------------------------------------------------------------------- */
/* Use USE_VOLATILE_DEF if compiler can handle volatile const declarations!     */
/* Use VOLATILE_DEF to define the volatile keyword                              */
/* ---------------------------------------------------------------------------- */
#define USE_VOLATILE_DEF  // Enable when FAR_DEF define shall be used
                        // -> Disable if not needed or compiler does not support
                        // empty define declaration
//Can override the defaults in the ETK project here if needed.
#define VOLATILE_DEF volatile
#define CONST_DEF const
#define CAL_DEF CONST_DEF VOLATILE_DEF
//#define FAR_DEF

/** Timer conversion formula used for the  BASE_Check_Timeout function. (e.g. number of ticks for 1 usec - 40 ticks/us for 40 MHz) */
/* STM Clock is currently 800 MHz */
#define SMU_TICKS_USEC (50)
#define RTU_TICKS_USEC (67)
#ifdef CORE_M33
#define TICKS_PER_USEC (SMU_TICKS_USEC)  /*100/2 to accommodate the tu16*/
#else
#define TICKS_PER_USEC (RTU_TICKS_USEC)   /*133/2 to accommodate the tu16*/
#endif
#define TICKS_TO_USEC(ticks) ((ticks)/TICKS_PER_USEC)   // Converts ticks input to uS
#define TICKS_TO_MSEC(ticks) ((ticks)/(TICKS_PER_USEC*1000))   // Converts ticks input to uS
#define USEC_TO_TICKS(us) ((us)*TICKS_PER_USEC)         // Converts uS input to ticks
#define MSEC_TO_TICKS(ms) ((ms)*1000*TICKS_PER_USEC)    // Converts ms input to ticks

#define SYSTEM_COUNTER RTU0__STM_0.CNT.R


//Use this defined to make sure that the cores do not start until all the initialization has been finished. Important when core0 initializes RAM used by other cores.
#define COORDINATED_CORE_START


#define MDM_OFFSET_INTERNAL  (0x1c11000UL)
#define MDM_XETK_AP (*(volatile struct MDM_AP_tag *)(0x4C000000UL + MDM_OFFSET_INTERNAL))

#define read_mpidr() ({							\
	unsigned long long __mpidr;					\
	__asm volatile("mrc p15, 0, %0, c0, c0, 5"	\
		: "=r" (__mpidr)						\
		:										\
		: "cc");								\
	__mpidr;									\
})

#define clusterid() ((read_mpidr() >> 8) & 1)
#define coreid() (read_mpidr() & 0xFF)

//Function Prototypes
uint8 Get_Core_ID(void);
uint8 GetCoreIndex(void);

#ifdef COORDINATED_CORE_START
bool GetAllCoresReady(void);
bool WaitAllCoresReady(uint32 timeout_ms);
void SetCoreReady(void);
bool GetCoreStatus(uint8 core_index);
#endif
void UpdateCoreAliveCounter(void);
void DisableCache(void);
void InvalidateCache(void);

#ifdef USE_TRIGGER_SEMAPHORE

uint8 INIT_Trigger_S4(void);
uint8 Triger_S4_SpinLock(void);
uint8 Triger_S4_SpinUnlock(void);
#endif


static inline void RESET_CONTROLLER(void)
{
    	MC_RGM.DRET.B.DRET=0;  //Clear the lock in reset register
     	MC_RGM.FRET.B.FRET=0x0;
//     	MC_RGM.ERCTRL.B.ERASSERT=0x1b;   //Put pins in a safe state 0x1b is used in self test

		/* MC_ME destructive reset */
		MC_ME.MODE_CONF.B.DEST_RST=1;
		MC_ME.MODE_UPD.B.MODE_UPD=1;
		/* Direct MC_ME_CTL_KEY */
		MC_ME.CTL_KEY.R = 0x5AF0;
		/* Inverted MC_ME_CTL_KEY */
		MC_ME.CTL_KEY.R = 0xA50F;
}


#endif
