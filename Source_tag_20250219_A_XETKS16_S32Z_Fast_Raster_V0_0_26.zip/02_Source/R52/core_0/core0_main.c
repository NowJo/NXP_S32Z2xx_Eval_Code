 /**************************************************************************************************
 *
 * Copyright 2021 NXP
 *
 **************************************************************************************************
 *
 * NXP Confidential Proprietary. This software is owned or controlled by NXP and may only be used
 * strictly in accordance with the applicable terms. By expressly accepting such terms or by
 * downloading, installing, activating and/or otherwise using the software, you are agreeing that
 * you have read, and that you agree to comply with and are bound by, such license terms.
 * If you do not agree to be bound by the applicable license terms, then you may not retain,
 * install, activate or otherwise use the software.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
**************************************************************************************************/
//#include "common_utils.h"
#include "S32Z27.h"
#include "common_utils.h"
//#include "serial.h"
//#include "stdio_func.h"
#include "target_specific.h"
#include "main_cpu0.h"
#include "hw_type.h"


//#define RTU_STAND_ALONE_BOOT	// Define this to indicate this project is booting directly from BootROM or Serial Boot Bypass, so it will perform clocks setup.

extern void sys_init(void);

//This is done so that system events observed in INCA have the same time base.
static inline void SyncTimerAdjustment(void)
{
   uint32 new_time;

   new_time = ((SMU__STM_0.CNT.R/SMU_TICKS_USEC)*RTU_TICKS_USEC)+12; //allow a few extra us to account for writing the new values

   RTU0__STM_0.CNT.R=new_time;
   RTU1__STM_0.CNT.R=new_time+4;
}

void INIT_InitTimers(void)
{
    int n;
	uint32 clock_init;
	if(eHW_Type_TU16&M_Hardware_Type)
	{
		clock_init = 0x3; // CPS = 0 (div by 1); FRZ = 1 (stops in Debug); Enable = 1;
	}
	else
	{
	    clock_init = 0x103; // CPS = 1 (div by 2); FRZ = 1 (stops in Debug); Enable = 1;
	}

	DISABLE_INTERRUPT();

    // Initialize free run counters
	//There are 4 channels
	for(n=0; n<4; n++)
	{
    RTU0__STM_0.CHANNEL[n].CMP.R = 0x0;
    RTU0__STM_0.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU0__STM_0.CHANNEL[n].CIR.R |=0x1;//Clear IRQ
#if (CORES==MULTICORE)
    RTU0__STM_1.CHANNEL[n].CMP.R = 0x0;
    RTU0__STM_1.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU0__STM_1.CHANNEL[n].CIR.R |=0x1;//Clear IRQ

    RTU0__STM_2.CHANNEL[n].CMP.R = 0x0;
    RTU0__STM_2.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU0__STM_2.CHANNEL[n].CIR.R |=0x1;//Clear IRQ

    RTU0__STM_3.CHANNEL[n].CMP.R = 0x0;
    RTU0__STM_3.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU0__STM_3.CHANNEL[n].CIR.R |=0x1;//Clear IRQ

    RTU1__STM_0.CHANNEL[n].CMP.R = 0x0;
    RTU1__STM_0.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU1__STM_0.CHANNEL[n].CIR.R |=0x1;//Clear IRQ

    RTU1__STM_1.CHANNEL[n].CMP.R = 0x0;
    RTU1__STM_1.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU1__STM_1.CHANNEL[n].CIR.R |=0x1;//Clear IRQ

    RTU1__STM_2.CHANNEL[n].CMP.R = 0x0;
    RTU1__STM_2.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU1__STM_2.CHANNEL[n].CIR.R |=0x1;//Clear IRQ

    RTU1__STM_3.CHANNEL[n].CMP.R = 0x0;
    RTU1__STM_3.CHANNEL[n].CCR.R = 0x0;//No IRQ assert if this is enabled then we have to tie it to a function else we get an unrecoverable error
    RTU1__STM_3.CHANNEL[n].CIR.R |=0x1;//Clear IRQ

#endif
	}

    RTU0__STM_0.CR.R   = clock_init;

#if (CORES==MULTICORE)
    RTU0__STM_1.CR.R   = clock_init;
    RTU0__STM_2.CR.R   = clock_init;
    RTU0__STM_3.CR.R   = clock_init;

    RTU1__STM_0.CR.R   = clock_init;
    RTU1__STM_1.CR.R   = clock_init;
    RTU1__STM_2.CR.R   = clock_init;
    RTU1__STM_3.CR.R   = clock_init;
#endif

	//Sync the timers used for system timing
    SyncTimerAdjustment();

}

/*Before this RAM is read we need to initialize it */
void InitSharedRAM(void)
{
/*
#ifdef RTU_STAND_ALONE_BOOT
	RTU0__SRAMCTL_D0.RAMIAS.R=0x31780000;
	RTU0__SRAMCTL_D0.RAMIAE.R=0x317BFFFF;
	RTU0__SRAMCTL_D0.RAMCR.R=0x1;

	RTU0__SRAMCTL_D1.RAMIAS.R=0x317C0000;
	RTU0__SRAMCTL_D1.RAMIAE.R=0x317FFFFF;
	RTU0__SRAMCTL_D1.RAMCR.R=0x1;

	RTU0__SRAMCTL_D2.RAMIAS.R=0x31800000;
	RTU0__SRAMCTL_D2.RAMIAE.R=0x3187FFFF;
	RTU0__SRAMCTL_D2.RAMCR.R=0x1;

	while( !
	((RTU0__SRAMCTL_D0.RAMSR.R&1) &
	 (RTU0__SRAMCTL_D1.RAMSR.R&1) &
	 (RTU0__SRAMCTL_D2.RAMSR.R&1)));

#endif
*/
}

void core_loop_forever(void)
{

	MPU_setup_asm();
	ENABLEFPU();
	INTC_setup_core1();
	LLPP_setup_asm();

	DisableCache();

    SetCoreReady();  //Core started
    WaitAllCoresReady(500); //Wait no more than 500ms core all cores to start
    while(1){
    	UpdateCoreAliveCounter();
    	BASE_WaitInMicroSeconds(20000);
    }
}

int main(void)
{
	DisableCache();
    InitSharedRAM();
    MPU_setup_asm();
    ENABLEFPU();
    INTC_setup_core0();
    LLPP_setup_asm();

#ifdef RTU_STAND_ALONE_BOOT
    sys_init();	// Perform system clocks setup

    // Serial setup done by SMU
    LinFlex_Init();
#else
    HWT_InitHW_Type();
#endif

    INIT_InitTimers();
    Start_Cpu0();

    return 0;
}


