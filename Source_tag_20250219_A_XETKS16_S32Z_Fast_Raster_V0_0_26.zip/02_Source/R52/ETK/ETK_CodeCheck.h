/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef __ETK_H__
#define __ETK_H__

#include "ETK_Integration_Cfg.h"
#include "ETK_SER_Page_Ctrl_Fct.h"
#include "CompileTime.h"


#include "base.h"
#include "target_specific.h"
#ifdef RS232_DEBUG_LOGGING
#include "rs232.h"
#endif


//defines
#define ETK_PRESENCE_PATTERN_VALUE     0x12345678
#define ERROR_PATTERN_DATE             0x11223344
#define ERROR_PATTERN_TIME             0x55667788
#define write_correct_RAM_Pattern      0x0
#define write_wrong_RAM_Pattern        0x1


//function prototypes
#ifdef PARALLEL_ETK
uint8 PresenceCheck(void);
#endif

void CopyCodeCheckPattern_cyclic(uint8 Error_Pattern);
void initRAMCheckPattern(void);
uint8 CodeCheck_WP(void);
uint8 CodeCheck_RP(void);

void Check_PageSwitch_after_CodeCheck(uint8 state_ASD);
void OMD_Adaptive_Force_Fail_Parameters_Update(uint8 RPREQ_Fail, uint8 WPREQ_Fail, uint8 MOREQ_Fail);

/* Extern ASCET adaptive parameter defines */
extern VOLATILE_DEF uint8 PageSwitch_depending_on_CodeCheck;
extern VOLATILE_DEF uint8 RPREQ_Force_Fail;
extern VOLATILE_DEF uint8 WPREQ_Force_Fail;
extern VOLATILE_DEF uint8 MOREQ_Force_Fail;

extern VOLATILE_DEF uint32 CODE_CHECK_PATTERN_RAM_DATE;
extern VOLATILE_DEF uint32 CODE_CHECK_PATTERN_RAM_TIME;

//ETK Code check pattern in EMURAM section
extern VOLATILE_DEF uint32 CODE_CHECK_PATTERN_EMURAM_DATE;
extern VOLATILE_DEF uint32 CODE_CHECK_PATTERN_EMURAM_TIME;

#endif







