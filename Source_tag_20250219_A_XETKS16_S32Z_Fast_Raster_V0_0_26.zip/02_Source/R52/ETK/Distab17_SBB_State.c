/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

#include "Distab17_SBB_State.h"
#include "Distab17_Inst.h"

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
struct BypassLegacyConfig {
    uint32* TrgFlgAdr;
    CONST_DEF tD17LegacyDistab* AdrTabFromECU;
    void* DatTabFromECU;
    CONST_DEF tD17LegacyReverseDistab* AdrTabToECU;
    tD17LegacyBypassReverseData* DatTabToECU;
};
#endif

#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT

//* ETASTEST    */ extern uint32 SBB_SP_TriggerCount[];
//* ETASTEST    */ extern uint32 SBB_SP_ProcessCount[];
//* ETASTEST    */ extern uint32 SBB_SP_LockMissCount[];

/* ETASTEST    */ static void ReinitializeInternalCounters(void)
/* ETASTEST    */ {
    /* ETASTEST    */     int i;
    /* ETASTEST    */
    /* ETASTEST    */     for (i = 0; i < D17_MAXNUM_AVAILABLE_SERVICEPOINTS; i++)
        /* ETASTEST    */ {
        /* ETASTEST    */         D17_TriggerCount[i] = 0;
        /* ETASTEST    */         D17_ProcessCount[i] = 0;
        /* ETASTEST    */         D17_LockMissCount[i] = 0;
        /* ETASTEST    */
    }

/* ETASTEST    */     #ifdef RTT_TEST
    /* ETASTEST    */     uint8 srvPtNumber;

    /* ETASTEST    */     // Initializes RTT measurement variables
    /* ETASTEST    */     for (srvPtNumber = 0; srvPtNumber < D17_MAXNUM_AVAILABLE_SERVICEPOINTS; srvPtNumber++)
        /* ETASTEST    */ {
        /* ETASTEST    */       D17_BypRTT_Sum[srvPtNumber] = 0.0;
        /* ETASTEST    */       D17_BypRTT_Min[srvPtNumber] = 0xFFFFFFFF;
        /* ETASTEST    */       D17_BypRTT_Max[srvPtNumber] = 0;
        /* ETASTEST    */       D17_BypRTT_CountNumber[srvPtNumber] = 0;
        /* ETASTEST    */       D17_BypRTT_Avg[srvPtNumber] = 0;
        /* ETASTEST    */
        /* ETASTEST    */
    }
/* ETASTEST    */     #endif
    /* ETASTEST    */
}


static uint32 CalculateWaitLoops(void)
{
    CONST_DEF uint32 startTime = Distab17_GetSystemTime();
    CONST_DEF uint32 waitTime =
        Distab17_GetMicrosecondsToTicks(D17_BYPASS_MAX_RAID_WAIT_US);
    VOLATILE_DEF uint32 loopcounter = 0;

    while (!Distab17_IsTimeout(startTime, waitTime))
    {
        ++loopcounter;
    }

    return loopcounter;
}

void Distab17_SBB_Init(void)
{
    D17_SBB_State_IsETargetDetected = 0;
    D17_SBB_State_IsFirstServicePoint = 1;
    D17_SBB_State = INACTIVE;
    D17_SBB_State_RAIDWaitLoops = CalculateWaitLoops();
    D17_SBB_State_StructureVersion = D17_SBB_Structure_Version_NONE;
    D17_SBB_State_StructureType = D17_SBB_Structure_Type_DYNAMIC;
    D17_SBB_State_FeatureMode = D17_SBB_Mode_BASIC;

    /* ETASTEST    */ ReinitializeInternalCounters();
}

void Distab17_SBB_Config_Update(void)
{
    CONST_DEF tD17SBBMode* mode = (CONST_DEF tD17SBBMode*) & (P_D17_SrvPtResId[0]);

    uint8 srvPtNumber, servicePointIndex;

    VOLATILE_DEF tD17BypassReverseConfig* AdrTabToECU;
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    VOLATILE_DEF struct BypassLegacyConfig* LegacyConfig;
#endif

    switch (mode->StructureVersion)
    {
    case D17_SBB_Structure_Version_31:
        D17_SBB_State_StructureVersion = D17_SBB_Structure_Version_31;
        break;
    case D17_SBB_Structure_Version_21:
        D17_SBB_State_StructureVersion = D17_SBB_Structure_Version_21;
        break;
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3
    case D17_SBB_Structure_Version_3:
        D17_SBB_State_StructureVersion = D17_SBB_Structure_Version_3;
        break;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V3*/
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2
    case D17_SBB_Structure_Version_2:
        D17_SBB_State_StructureVersion = D17_SBB_Structure_Version_2;
        break;
#endif /*#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT_V2*/
    default:
        D17_SBB_State_StructureVersion = D17_SBB_Structure_Version_NONE;
        break;
    }

    switch (mode->StructureType)
    {
    default:
        /* Fall through */
    case D17_SBB_Structure_Type_DYNAMIC:
        D17_SBB_State_StructureType = D17_SBB_Structure_Type_DYNAMIC;
        break;
    case D17_SBB_Structure_Type_STATIC:
        D17_SBB_State_StructureType = D17_SBB_Structure_Type_STATIC;
        break;
    }

    switch (mode->FeatureMode)
    {
    default:
        /* Fall through */
    case D17_SBB_Mode_BASIC:
        D17_SBB_State_FeatureMode = D17_SBB_Mode_BASIC;
        break;
    case D17_SBB_Mode_EXTENDED:
        D17_SBB_State_FeatureMode = D17_SBB_Mode_EXTENDED;
        break;
    case D17_SBB_Mode_SELECTED:
        D17_SBB_State_FeatureMode = D17_SBB_Mode_SELECTED;
        break;
    }


    /* Updating the bypass last counter values with the initial values present in RAM before the bypass activation.
    This should be done to prevent an unsynchronised copy to ECU routine, where the copy routine would get activated once the counter was deemed to be modified.
    This would cause an unsynchronised run in the case when the initial value is different from 0. */
#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    if (DISTAB17_IS_CONFIGURED_SBB_V3 || DISTAB17_IS_CONFIGURED_SBB_V2)
    {
        for (srvPtNumber = 1; srvPtNumber <= D17_MAXNUM_AVAILABLE_SERVICEPOINTS; srvPtNumber++)
        {
            /* The index starts at zero, but the P_D17_SrvPtResId entry is 1-based
            (zero is used to indicate "inactive", see above) -> subtract one */
            servicePointIndex = P_D17_SrvPtResId[srvPtNumber] - 1;

            if (servicePointIndex != (uint8)(SP_INACTIVE - 1)) // The Inactive value is 0x00 but the servicePointIndex value was just decremented by 1. The Inactive value to test here is 0xFF.
            {
                if (P_D17_SrvPtEnabled[servicePointIndex])
                {
                    /* Check for both pre- and post-function configuration */
                    LegacyConfig = (struct BypassLegacyConfig*) & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPre);

                    if (LegacyConfig->AdrTabToECU && LegacyConfig->DatTabToECU)
                    {
                        D17_SP_OldBypassCounterPre[servicePointIndex] = LegacyConfig->DatTabToECU->BypCtr;
                    }

                    LegacyConfig = (struct BypassLegacyConfig*) & (D17_ServicePoint_Cfg.V3_V2[servicePointIndex].TrgFlgAdrPost);

                    if (LegacyConfig->AdrTabToECU && LegacyConfig->DatTabToECU)
                    {
                        D17_SP_OldBypassCounterPost[servicePointIndex] = LegacyConfig->DatTabToECU->BypCtr;
                    }
                }
            }
        }
    }
    else if (DISTAB17_IS_CONFIGURED_SBB_V31 || DISTAB17_IS_CONFIGURED_SBB_V21)
#else
    if (DISTAB17_IS_CONFIGURED_SBB_V31 || DISTAB17_IS_CONFIGURED_SBB_V21)
#endif // #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
    {
        for (srvPtNumber = 1; srvPtNumber <= D17_MAXNUM_AVAILABLE_SERVICEPOINTS; srvPtNumber++)
        {
            /* The index starts at zero, but the P_D17_SrvPtResId entry is 1-based
            (zero is used to indicate "inactive", see above) -> subtract one */
            servicePointIndex = P_D17_SrvPtResId[srvPtNumber] - 1;

            if (servicePointIndex != (uint8)(SP_INACTIVE - 1)) // The Inactive value is 0x00 but the servicePointIndex value was just decremented by 1. The Inactive value to test here is 0xFF.
            {
                if (P_D17_SrvPtEnabled[servicePointIndex])
                {
                    /* Check for both pre- and post-function configuration */
                    AdrTabToECU = (VOLATILE_DEF*)D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabToECUPre;

                    if (AdrTabToECU && AdrTabToECU->DataTable)
                    {
                        D17_SP_OldBypassCounterPre[servicePointIndex] = AdrTabToECU->DataTable->BypCtr;
                    }

                    AdrTabToECU = (VOLATILE_DEF*)D17_ServicePoint_Cfg.V31[servicePointIndex].AdrTabToECUPost;

                    if (AdrTabToECU && AdrTabToECU->DataTable)
                    {
                        D17_SP_OldBypassCounterPost[servicePointIndex] = AdrTabToECU->DataTable->BypCtr;
                    }

#ifdef RTT_TEST
                    Distab17_SBB_NbOfBytes(P_D17_ResIdSrvPt[servicePointIndex]);
#endif

                }
            }
        }
    }

}

void Distab17_SBB_State_Update(void)
{
    enum D17_SBB_Enable_State oldState;

    do
    {
        oldState = D17_SBB_State;

        switch (D17_SBB_State)
        {
        case INACTIVE:
            if (ENABLE_NOW == P_D17_SBB_Enable)
            {
                D17_SBB_State = WAITING_FOR_ACTIVATION;
            }
            else
            {
                if (DISTAB17_IS_CONFIGURED_SBB)
                {
                    if ((D17_SBB_State_IsFirstServicePoint) &&
                        (ENABLE_AFTER_RESET == P_D17_SBB_Enable))
                    {
                        D17_SBB_State = WAITING_FOR_STIMDATA_AFTER_RESET;
                    }
                    else
                    {
                        D17_SBB_State = WAITING_FOR_SETTING_OF_LABEL;
                    }
                }
            }
            break;
        case WAITING_FOR_ACTIVATION:
            if (ENABLE_NOW == P_D17_SBB_Enable)
            {
                if (DISTAB17_IS_CONFIGURED_SBB)
                {
                    D17_SBB_State = WAITING_FOR_STIMDATA;
                }
            }
            else
            {
                D17_SBB_State = INACTIVE;
            }
            break;
        case WAITING_FOR_SETTING_OF_LABEL:
            if (ENABLE_NOW == P_D17_SBB_Enable)
            {
                D17_SBB_State = WAITING_FOR_STIMDATA;
            }
            else
            {
                if (!DISTAB17_IS_CONFIGURED_SBB)
                {
                    D17_SBB_State = INACTIVE;
                }
            }
            break;
        case WAITING_FOR_STIMDATA_AFTER_RESET:
            if (DISTAB17_IS_CONFIGURED_SBB &&
                (ENABLE_AFTER_RESET == P_D17_SBB_Enable))
            {
                if (D17_SBB_State_IsETargetDetected)
                {
                    D17_SBB_State = BYPASS_ACTIVE;
                }
            }
            else
            {
                D17_SBB_State = INACTIVE;
            }
            break;
        case WAITING_FOR_STIMDATA:
            if (ENABLE_NOW == P_D17_SBB_Enable)
            {
                if (DISTAB17_IS_CONFIGURED_SBB)
                {
                    if (D17_SBB_State_IsETargetDetected)
                    {
                        D17_SBB_State = BYPASS_ACTIVE;
                    }
                }
                else
                {
                    D17_SBB_State = WAITING_FOR_ACTIVATION;
                }
            }
            else
            {
                D17_SBB_State = WAITING_FOR_SETTING_OF_LABEL;
            }
            break;
        case BYPASS_ACTIVE:
            switch (P_D17_SBB_Enable)
            {
            case DISABLE:
                D17_SBB_State = BYPASS_TRIGGERED_NO_STIMDATA_USED;
                /* ETASTEST    */ ReinitializeInternalCounters();
                break;
            case DISABLE_SERVICE:
                D17_SBB_State = DISABLED;
                /* ETASTEST    */ ReinitializeInternalCounters();
                break;
            default:
                if (!DISTAB17_IS_CONFIGURED_SBB)
                {
                    D17_SBB_State = WAITING_FOR_ACTIVATION;
                    /* ETASTEST    */ ReinitializeInternalCounters();
                }
                break;
            }
            break;
        case BYPASS_TRIGGERED_NO_STIMDATA_USED:
            if (DISABLE_SERVICE == P_D17_SBB_Enable)
            {
                D17_SBB_State = DISABLED;
            }
            break;
        default:
            /* Fall through */
        case DISABLED:
            break;
        }
    } while (oldState != D17_SBB_State);
}

#endif /*#ifdef D17_ENABLE_BYPASS_STATE_MANAGEMENT*/
