
#include "ETK_Integration_Cfg.h"

#if defined(TRG_ON_REG)
 PRE_SECTION_BSS(bRegTrigger_Active, ".common_core_share")
 VOLATILE_DEF uint8 bRegTrigger_Active; /* This will be set to let the functions know to use registers or RAM. Set when Handshake is done */
 POST_SECTION_BSS()
#endif