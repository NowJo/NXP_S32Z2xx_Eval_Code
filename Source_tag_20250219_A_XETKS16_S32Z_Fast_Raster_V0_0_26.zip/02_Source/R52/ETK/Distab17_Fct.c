/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
/***************************************************************************//**
* \file  Distab17_Fct.c
* \brief file containing the function implementation to process a Distab event
*
* This file contains the definition of the function that processes an individual
* (and active) non-TDM Distab event
*******************************************************************************/
#include "ETK_Integration_Cfg.h"
#include "Distab17_Fct.h"


typedef union __sud17_u32 {
	uint32 U;
	uint8  B[4];
	uint16 W[2];
}sud17_u32_t;

enum D17_Result Distab17_CopyValuesFromECU(CONST_DEF tD17EventConfig* config)
{
    /*******************************************************************************
    * \fn  Distab17_CopyValuesFromECU
    * \brief processes the Distab, copies data
    * \param config Distab17 event configuration for this event
    *
    * The distab function parses the display table (ordered address table written
    * by a measurement or rapid prototyping tool) and copies the values at these
    * ECU memory addresses to a dedicated output buffer that can be read by these
    * tools.
    *
    * The caller must have asserted that this event is valid (contains the
    * correct version number, a valid pointer to the output area, and is not
    * configured for TDM).
    *******************************************************************************/

    /* pointers to measurement output buffers */
#ifndef SUD17_32BIT
    uint8* dst_ptr1;
    uint16* dst_ptr2;
    ustr64* dst_ptr8;
#endif
    uint32* dst_ptr4;

    /* the current data source */
    void* CONST_DEF* src_addr_ptr;

    /* pointer to storage buffer */

#ifndef SUD17_32BIT
    dst_ptr8 = (ustr64*)&(config->Header.Output->FirstEntry);

#else
    sud17_u32_t write32bit = {0};
    dst_ptr4 = (uint32*)&(config->Header.Output->FirstEntry);

#endif

    /* Number of 8, 4, 2, and 1 byte variables */
#ifdef DISTAB_LONGWORD_OPTIMIZATION
  // With uint16 the GHS compiler will do an AND with the register 21 (0xFFFF value) before checking the value in a loop every time...
  // This optimization also removes the -1 operation to the loop counter replaced by the loop command.
    uint32 no_of_val_8 = (uint32)config->NoOfVal_8;
    uint32 no_of_val_4 = (uint32)config->NoOfVal_4;
    uint32 no_of_val_2 = (uint32)config->NoOfVal_2;
    uint32 no_of_val_1 = (uint32)config->NoOfVal_1;
#else
    uint16 no_of_val_8 = config->NoOfVal_8;
    uint16 no_of_val_4 = config->NoOfVal_4;
    uint16 no_of_val_2 = config->NoOfVal_2;
    uint16 no_of_val_1 = config->NoOfVal_1;
#endif

    /* pointer to start of the table where the first address to copy */
    src_addr_ptr = &(config->FirstEntry);

    /**********************     ustr64      ***********************************/

    /* data acquisition: copy all 8-byte values */
    while (no_of_val_8 > 0)
    {
#ifndef SUD17_32BIT
        *dst_ptr8++ = *((ustr64*)*src_addr_ptr++);
        no_of_val_8--;
#else
        uint32* src_addr_ptr_tmp;
        src_addr_ptr_tmp = (uint32*)*src_addr_ptr++;
        *dst_ptr4++ = *src_addr_ptr_tmp++;
        *dst_ptr4++ = *src_addr_ptr_tmp++;
        no_of_val_8--;
#endif
    }

    /**********************     uint32      ***********************************/

#ifndef SUD17_32BIT
    dst_ptr4 = (uint32*)dst_ptr8;
#endif
    while (no_of_val_4 > 0)
    {
        *dst_ptr4++ = *((uint32*)*src_addr_ptr++);
        no_of_val_4--;
    }

    /**********************     uint16      ***********************************/
#ifndef SUD17_32BIT
    dst_ptr2 = (uint16*)dst_ptr4;
    while (no_of_val_2 > 0)
    {
        *dst_ptr2++ = *((uint16*)*src_addr_ptr++);
        no_of_val_2--;
    }
#else
    while ((no_of_val_2 / 2) > 0)
    {
        write32bit.W[0] = *((uint16*)*src_addr_ptr++);
        write32bit.W[1] = *((uint16*)*src_addr_ptr++);
        *dst_ptr4++ = write32bit.U;
        no_of_val_2 -= 2;
    }

    // Dealing with remainder 2-byte variables and padding with possible 1-byte variables or zeros
    if (0 < no_of_val_2)
    {
        write32bit.U = 0;
        write32bit.W[0] = *((uint16*)*src_addr_ptr++);
        for (uint8 i = 0; (no_of_val_1 > 0) && (i < 2); i++)
        {
        	//Only one 2 byte so fill the rest (up to 2 bytes) with available one byte variables
            write32bit.B[2+i] += *((uint8*)*src_addr_ptr++);
            no_of_val_1--;
        }

        *dst_ptr4++ = write32bit.U;
        no_of_val_2--;
    }
#endif
    /**********************     uint8       ***********************************/

#ifndef SUD17_32BIT
    dst_ptr1 = (uint8*)dst_ptr2;
    while (no_of_val_1 > 0)
    {
        *dst_ptr1++ = *((uint8*)*src_addr_ptr++);
        no_of_val_1--;
    }
#else
while ((no_of_val_1 / 4) > 0)
    {

		write32bit.B[0] = *((uint8*)*src_addr_ptr++);
		write32bit.B[1] = *((uint8*)*src_addr_ptr++);
		write32bit.B[2] = *((uint8*)*src_addr_ptr++);
		write32bit.B[3] = *((uint8*)*src_addr_ptr++);
        *dst_ptr4++ = write32bit.U;
        no_of_val_1 -= 4;
    }

    // Dealing with remainder 1-byte variables or zeros
    if ( 0 < no_of_val_1 )
    {
        write32bit.U = 0;
        for (uint8 i = 0; (no_of_val_1 > 0) && (i < 4); i++)
        {
            write32bit.B[i] = *((uint8*)*src_addr_ptr++);
            no_of_val_1--;
        }

        *dst_ptr4++ = write32bit.U;
    }
#endif
    return D17_DATA_ACQUISITION_SUCCESS;
}

#ifdef D17_ENABLE_BYPASS_SUPPORT

struct CopyToECUConfig
{
    uint16 NoOfVal_8;
    uint16 NoOfVal_4;
    uint16 NoOfVal_2;
    uint16 NoOfVal_1;
    uint16 NoOfBits_4;
    uint16 NoOfBits_2;
    uint16 NoOfBits_1;
    void* CONST_DEF* Address_Ptr;
    void* Value_Ptr;
};

static enum D17_Result CopyValuesToECU(struct CopyToECUConfig* config)
{
    int i;

    CONST_DEF uint32 numberOfAddresses =
        config->NoOfVal_8 +
        config->NoOfVal_4 + config->NoOfBits_4 +
        config->NoOfVal_2 + config->NoOfBits_2 +
        config->NoOfVal_1 + config->NoOfBits_1;

    void* value_ptr = config->Value_Ptr;
    void* CONST_DEF* adr_ptr = config->Address_Ptr;
    CONST_DEF void* bitmask_ptr = config->Address_Ptr + numberOfAddresses;

#ifdef D17_ENABLE_BYPASS_CHECKS
    CONST_DEF ustr64* value_ptr_8 = (ustr64*)(value_ptr);
    CONST_DEF uint32* value_ptr_4 = (uint32*)(value_ptr_8 + config->NoOfVal_8);
    CONST_DEF uint16* value_ptr_2 = (uint16*)(value_ptr_4 + config->NoOfVal_4 + config->NoOfBits_4);
    CONST_DEF uint8* value_ptr_1 = (uint8*)(value_ptr_2 + config->NoOfVal_2 + config->NoOfBits_2);

    CONST_DEF uint32 numberOfDataBytes = /* without alignment */
        (((config->NoOfVal_8) << 3) +
            ((config->NoOfVal_4 + config->NoOfBits_4) << 2) +
            ((config->NoOfVal_2 + config->NoOfBits_2) << 1) +
            ((config->NoOfVal_1 + config->NoOfBits_1) << 0));

    CONST_DEF void* value_ptr_end = (uint8*)value_ptr + numberOfDataBytes;

    CONST_DEF ustr64* CONST_DEF* adr_ptr8 = (ustr64**)adr_ptr;
    CONST_DEF uint32* CONST_DEF* adr_ptr4 = (uint32**)(adr_ptr8 + config->NoOfVal_8);
    CONST_DEF uint16* CONST_DEF* adr_ptr2 = (uint16**)(adr_ptr4 + config->NoOfVal_4 + config->NoOfBits_4);
    CONST_DEF uint8* CONST_DEF* adr_ptr1 = (uint8**)(adr_ptr2 + config->NoOfVal_2 + config->NoOfBits_2);

    CONST_DEF uint32* bitmask_ptr_4 = (uint32*)(adr_ptr + numberOfAddresses);
    CONST_DEF uint16* bitmask_ptr_2 = (uint16*)(bitmask_ptr_4 + config->NoOfBits_4);
    CONST_DEF uint8* bitmask_ptr_1 = (uint8*)(bitmask_ptr_2 + config->NoOfBits_2);

    /** The address pointer also checks the masks in the offset. However the 1byte mask is only 1 byte big. Thus we have to use an uint8 address offset instead of the 4 byte default address offset. */
    CONST_DEF void* adr_ptr_end = ((uint8*)adr_ptr) + ((numberOfAddresses + config->NoOfBits_4) << 2) + (config->NoOfBits_2 << 1) + config->NoOfBits_1;

    if (((uint32*)(adr_ptr1 + config->NoOfVal_1 + config->NoOfBits_1)) != bitmask_ptr_4)
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    /* 64-bit values */

#ifdef D17_ENABLE_BYPASS_CHECKS
    if ((value_ptr != value_ptr_8) || (adr_ptr != (void**)adr_ptr8))
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    for (i = 0; i < config->NoOfVal_8; ++i)
    {
        *((ustr64*)*(adr_ptr++)) = *((*(ustr64**)&value_ptr)++);
    }

    /* 32-bit values */

#ifdef D17_ENABLE_BYPASS_CHECKS
    if ((value_ptr != value_ptr_4) || (adr_ptr != (void**)adr_ptr4))
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    for (i = 0; i < config->NoOfVal_4; ++i)
    {
        *((uint32*)*(adr_ptr++)) = *((*(uint32**)&value_ptr)++);
    }

    /* 32-bit masked values */

#ifdef D17_ENABLE_BYPASS_CHECKS
    if (bitmask_ptr != bitmask_ptr_4)
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    for (i = 0; i < config->NoOfBits_4; ++i)
    {
        *((uint32*)*adr_ptr) =
            (*((uint32*)*adr_ptr) & ~(*((*(uint32**)&bitmask_ptr)++))) |
            *((*(uint32**)&value_ptr)++);
        ++adr_ptr;
    }

    /* 16-bit values */

#ifdef D17_ENABLE_BYPASS_CHECKS
    if ((value_ptr != value_ptr_2) || (adr_ptr != (void**)adr_ptr2))
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    for (i = 0; i < config->NoOfVal_2; ++i)
    {
        *((uint16*)*(adr_ptr++)) = *((*(uint16**)&value_ptr)++);
    }

    /* 16-bit masked values */

#ifdef D17_ENABLE_BYPASS_CHECKS
    if (bitmask_ptr != bitmask_ptr_2)
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    for (i = 0; i < config->NoOfBits_2; ++i)
    {
        *((uint16*)*adr_ptr) =
            (*((uint16*)*adr_ptr) & ~(*((*(uint16**)&bitmask_ptr)++))) |
            *((*(uint16**)&value_ptr)++);
        ++adr_ptr;
    }

    /* 8-bit values */

#ifdef D17_ENABLE_BYPASS_CHECKS
    if ((value_ptr != value_ptr_1) || (adr_ptr != (void**)adr_ptr1))
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    for (i = 0; i < config->NoOfVal_1; ++i)
    {
        *((uint8*)*(adr_ptr++)) = *((*(uint8**)&value_ptr)++);
    }

    /* 8-bit masked values */

#ifdef D17_ENABLE_BYPASS_CHECKS
    if (bitmask_ptr != bitmask_ptr_1)
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    for (i = 0; i < config->NoOfBits_1; ++i)
    {
        *((uint8*)*adr_ptr) =
            (*((uint8*)*adr_ptr) & ~(*((*(uint8**)&bitmask_ptr)++))) |
            *((*(uint8**)&value_ptr)++);
        ++adr_ptr;
    }

#ifdef D17_ENABLE_BYPASS_CHECKS
    if (bitmask_ptr != adr_ptr_end)
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }

    if (value_ptr != value_ptr_end)
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif

    return D17_DATA_ACQUISITION_SUCCESS;
}

enum D17_Result Distab17_CopyValuesToECU(CONST_DEF tD17BypassReverseConfig* adrTabToECU)
{
    struct CopyToECUConfig config;
    tD17BypassReverseData* dataTable = adrTabToECU->DataTable;

#ifdef D17_ENABLE_BYPASS_CHECKS
    CONST_DEF uint32 numberOfDataBytes = /* without alignment */
        (((adrTabToECU->NoOfVal_8) << 3) +
            ((adrTabToECU->NoOfVal_4 + adrTabToECU->NoOfBits_4) << 2) +
            ((adrTabToECU->NoOfVal_2 + adrTabToECU->NoOfBits_2) << 1) +
            ((adrTabToECU->NoOfVal_1 + adrTabToECU->NoOfBits_1) << 0));

    /* add alignment (already part of the given table length) */
    CONST_DEF uint32 expectedTableLength = (numberOfDataBytes + 3) & (~3);

    if (dataTable->TableLength != expectedTableLength)
    {
        return D17_DATA_ACQUISITION_CONSISTENCY_ERROR;
    }
#endif /* #ifdef D17_ENABLE_BYPASS_CHECKS */

    //Get the start of the address and cast to a pointer this is compatable with INCA in both 64bit and 32bit compile mode
    config.Address_Ptr = &(adrTabToECU->FirstAddress);

    config.Value_Ptr = (dataTable->BypCtr & 1)
        ? &(dataTable->FirstValue)
        : &(dataTable->FirstValue) + dataTable->TableLength;

    config.NoOfVal_8 = adrTabToECU->NoOfVal_8;
    config.NoOfVal_4 = adrTabToECU->NoOfVal_4;
    config.NoOfBits_4 = adrTabToECU->NoOfBits_4;
    config.NoOfVal_2 = adrTabToECU->NoOfVal_2;
    config.NoOfBits_2 = adrTabToECU->NoOfBits_2;
    config.NoOfVal_1 = adrTabToECU->NoOfVal_1;
    config.NoOfBits_1 = adrTabToECU->NoOfBits_1;

    return CopyValuesToECU(&config);
}

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
enum D17_Result Distab17_CopyValuesFromECULegacy(
    CONST_DEF tD17LegacyDistab* adrTabFromECU,
    void* datTabFromECU)
{
    /* the current data source */
    void* CONST_DEF* adr_ptr = &(adrTabFromECU->FirstAddress);

    /* loop index */
    int i;

    if (!adrTabFromECU->Active)
    {
        return D17_DATA_TABLE_NOT_ACTIVE;
    }

    /* 8-byte values */

    for (i = 0; i < adrTabFromECU->NoOfVal_8; ++i)
    {
        *((*((ustr64**)&datTabFromECU))++) = *((ustr64*)*adr_ptr++);
    }

    /* 4-byte values */

    for (i = 0; i < adrTabFromECU->NoOfVal_4; ++i)
    {
        *((*((uint32**)&datTabFromECU))++) = *((uint32*)*adr_ptr++);
    }

    /* 2-byte values */

    for (i = 0; i < adrTabFromECU->NoOfVal_2; ++i)
    {
        *((*((uint16**)&datTabFromECU))++) = *((uint16*)*adr_ptr++);
    }

    /* 1-byte values */

    for (i = 0; i < adrTabFromECU->NoOfVal_1; ++i)
    {
        *((*((uint8**)&datTabFromECU))++) = *((uint8*)*adr_ptr++);
    }

    return D17_DATA_ACQUISITION_SUCCESS;
}


enum D17_Result Distab17_CopyValuesToECULegacy(
    CONST_DEF tD17LegacyReverseDistab* adrTabToECU,
    tD17LegacyBypassReverseData* datTabToECU)
{
    struct CopyToECUConfig config;

    CONST_DEF uint32 numberOfDataBytes = /* without alignment */
        (((adrTabToECU->NoOfVal_8) << 3) +
            ((adrTabToECU->NoOfVal_4 + adrTabToECU->NoOfBits_4) << 2) +
            ((adrTabToECU->NoOfVal_2 + adrTabToECU->NoOfBits_2) << 1) +
            ((adrTabToECU->NoOfVal_1 + adrTabToECU->NoOfBits_1) << 0));

    /* add alignment (already part of given table-length) */
    CONST_DEF uint32 tableLength = (numberOfDataBytes + 3) & (~3);

    //Get the start of the address will be compatable with INCA in both 64bit and 32bit compile mode
    config.Address_Ptr = &(adrTabToECU->FirstAddress);

    config.Value_Ptr = (datTabToECU->BypCtr & 1)
        ? &(datTabToECU->FirstValue)
        : &(datTabToECU->FirstValue) + tableLength;

    config.NoOfVal_8 = adrTabToECU->NoOfVal_8;
    config.NoOfVal_4 = adrTabToECU->NoOfVal_4;
    config.NoOfBits_4 = adrTabToECU->NoOfBits_4;
    config.NoOfVal_2 = adrTabToECU->NoOfVal_2;
    config.NoOfBits_2 = adrTabToECU->NoOfBits_2;
    config.NoOfVal_1 = adrTabToECU->NoOfVal_1;
    config.NoOfBits_1 = adrTabToECU->NoOfBits_1;

    return CopyValuesToECU(&config);
}

#endif /* #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT */

#endif /* #ifdef D17_ENABLE_BYPASS_SUPPORT */


#if defined(TRG_ON_RAM)||defined(TRG_ON_REG)
extern VOLATILE_DEF uint8 bRegTrigger_Active;

static inline void SetHwTrigger(uint8 myTrigger)
{
#ifdef TRG_ON_REG
	if( bRegTrigger_Active)
	{
		if (myTrigger < 32)
		{
			DBG_TRG(0) = (1U << myTrigger);
		}
#if 1<DBG_TRG_MAX
		else if ((myTrigger >= 32) && (myTrigger < 64))
		{
			DBG_TRG(1) =  (1U << (myTrigger - 32));
		}
#endif
#if 2<DBG_TRG_MAX
		else if ((myTrigger >= 64) && (myTrigger < 96))
		{
			DBG_TRG(2) = (1U << (myTrigger - 64));
		}
#endif
#if 3<DBG_TRG_MAX
		else if ((myTrigger >= 96) && (myTrigger < 128))
		{
			DBG_TRG(3) = (1U << (myTrigger - 96));
		}
#endif
#if 4<DBG_TRG_MAX
	    else if ((myTrigger >= 128) && (myTrigger < 160))
	    {
	        /* DBG_TRG4 is a 32 bit register used for the ETK triggers */
	        DBG_TRG(4) = (1 << (myTrigger - 128)); // it's an = but the trigger is not overwritten, this is an special register that can only set bits never reset - only ETK can reset
	    }
#endif
#if 5<DBG_TRG_MAX
	    else if ((myTrigger >= 160) && (myTrigger < 192))
	    {
	        /* DBG_TRG5 is a 32 bit register used for the ETK triggers */
	        DBG_TRG(5) = (1 << (myTrigger - 160)); // it's an = but the trigger is not overwritten, this is an special register that can only set bits never reset - only ETK can reset
	    }
#endif
#if 6<DBG_TRG_MAX
	    else if ((myTrigger >= 192) && (myTrigger < 224))
	    {
	        /* DBG_TRG6 is a 32 bit register used for the ETK triggers */
	        DBG_TRG(6) = (1 << (myTrigger - 192)); // it's an = but the trigger is not overwritten, this is an special register that can only set bits never reset - only ETK can reset
	    }
#endif
#if 7<DBG_TRG_MAX
	    else // (myTrigger >= 224)
	    {
	        /* DBG_TRG7 is a 32 bit register used for the ETK triggers */
	        DBG_TRG(7) = (1 << (myTrigger - 224)); // it's an = but the trigger is not overwritten, this is an special register that can only set bits never reset - only ETK can reset
	    }
#endif
		else
		{
			// Up to 128 HW triggers supported
		}
	}
#endif
#if defined(TRG_ON_RAM)&&defined(TRG_ON_REG)
	else
#endif
#ifdef TRG_ON_RAM
	{
		if (myTrigger < 32)
		{
			RAM_INTERFACE.Trg32 ^= (1U << myTrigger);
		}
		else if ((myTrigger >= 32) && (myTrigger < 64))
		{
			RAM_INTERFACE.Trg64 = RAM_INTERFACE.Trg64 ^ (1U << (myTrigger - 32));
		}
		else if ((myTrigger >= 64) && (myTrigger < 96))
		{
			RAM_INTERFACE.Trg96 = RAM_INTERFACE.Trg96 ^ (1U << (myTrigger - 64));
		}
		else if ((myTrigger >= 96) && (myTrigger < 128))
		{
			RAM_INTERFACE.Trg128 = RAM_INTERFACE.Trg128 ^ (1U << (myTrigger - 96));
		}
		else if ((myTrigger >= 128) && (myTrigger < 160))
		{
			RAM_INTERFACE.Trg160 = RAM_INTERFACE.Trg160 ^ (1U << (myTrigger - 128));
		}
		else if ((myTrigger >= 160) && (myTrigger < 192))
		{
			RAM_INTERFACE.Trg192 = RAM_INTERFACE.Trg192 ^ (1U << (myTrigger - 160));
		}
		else if ((myTrigger >= 192) && (myTrigger < 224))
		{
			RAM_INTERFACE.Trg224 = RAM_INTERFACE.Trg224 ^ (1U << (myTrigger - 192));
		}
		//else if ((myTrigger >= 224) && (myTrigger <= 255))
		else if ((myTrigger >= 224) )  //Since uint8 passed in do not need the < check
		{
			RAM_INTERFACE.Trg256 = RAM_INTERFACE.Trg256 ^ (1U << (myTrigger - 224));
		}
		else
		{
			// Up to 256 HW triggers supported
		}
	}
#endif
}
#endif

void Set_ETKTrigger_D17(uint8 myTrigger, uint32* myTrigAdr, uint32 myTrigId_Val)
{
    // Set Trigger Identifier Flag
    *myTrigAdr = (uint32)myTrigId_Val;
    SetHwTrigger(myTrigger);
}
