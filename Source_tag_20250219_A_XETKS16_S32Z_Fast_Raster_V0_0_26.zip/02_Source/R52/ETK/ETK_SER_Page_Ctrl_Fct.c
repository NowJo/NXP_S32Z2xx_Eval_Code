/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "ETK_SER_Page_Ctrl_Fct.h"
#include "rs232.h"

extern uint8 RS232DebugLevel;

enum ePage_Values M_Active_Page = _Undefined;
enum ePage_Values M_Start_Page = _Undefined;

#ifdef OVL_POINTER_SUPPORTED
PRE_SECTION_DATA(gPage_off_group0, ".PageOffset")
uint32 gPage_off_group0 = 0; // gPage_off = 0 for reference page cluster 0 working page.
POST_SECTION_DATA()

PRE_SECTION_DATA(gPage_off_group1, ".PageOffset")
uint32 gPage_off_group1 = 0; // gPage_off = 0 for reference page cluster 1 working page.
POST_SECTION_DATA()

PRE_SECTION_DATA(gPage_off_group2, ".PageOffset")
uint32 gPage_off_group2 = 0; // gPage_off = 0 for reference page M33 working page.
POST_SECTION_DATA()
#endif

void Disable_Interrupts(void);
void Enable_Interrupts(void);

#ifdef CHECK_EXPECTED_HANDLE
#ifdef USE_VOLATILE_DEF
 extern uint8 Check_IsExpectedHandle(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
#else
 extern uint8 Check_IsExpectedHandle( struct OMD_TABLE* OMD_table_Ptr);
#endif
#endif

// **********************************************************
PRE_SECTION_BSS(Page_Switch_Mailbox, ".ETK_PageSwitch_MemClass")
VOLATILE_DEF struct Page_Switching_Mailbox_Struct Page_Switch_Mailbox;
POST_SECTION_BSS()

PRE_SECTION_BSS(OMD_table, ".ETK_OMDTable_MemClass")
#ifdef OMD_CID_VERSION_2
VOLATILE_DEF union OMD_TABLE_V1_V2  OMD_table;
#else
VOLATILE_DEF struct OMD_TABLE  OMD_table;
#endif
POST_SECTION_BSS()

uint32 firstModifyRequest = 0; // Used to check if a MORQ in the Request mailbox or a WPREQ in the init page is the first executed after a startup so that the RABR, OMASK, and OTAR registers are initialized

void SER_ETK_PowerFail_Page_Init(uint8 P_ProtocolBasedPageSwitch)
{
    // Disable Overlay to make sure ECU runs from Flash
    /* Disables the calibration handles. Switch to the RP. */
    Disable_Calibration_Handles();

    if (P_ProtocolBasedPageSwitch)
    {
        Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
        
#ifdef LED_PAGE
               GPIO_Led_WP_Active(LED_OFF);
#endif
        M_Active_Page = RP_RS;
    }

#ifdef RS232_DEBUG_LOGGING
    RS232_TxString_Debug_Level_3("Power fail detected: Disable Overlay -> RP !\r\n");
#endif
}

void SER_ETK_Page_Init_and_Check_WP(uint8 P_ProtocolBasedPageSwitch)
{

    VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr = (struct OMD_TABLE*) & OMD_table.OMD_V1;

#ifdef RS232_DEBUG_LOGGING
    RS232_TxString_Debug_Level_4("Serial ETK: Page Init in case of available OMD  !\r\n");
#endif

    if (P_ProtocolBasedPageSwitch) // Protocol Based Page switch enabled
    {
        if (RPREQ_PATTERN == Page_Switch_Mailbox.Start_Page) // Reference page Requested
        {

#ifdef RS232_DEBUG_LOGGING
            RS232_TxString_Debug_Level_3("Start Page RP requested -> Disable Overlay !\r\n");
#endif

            M_Start_Page = RP_RS;

            // verifies the OMD header (CID, version, number of EMU-Handles defined, and the OMD table size compared to the expected one for the target)
            if (Check_OMD(OMD_table_Ptr) == 1)   // OMD Table header correctly defined
            {
                // checks the OMD checksum
                if (Check_OMD_Checksum(OMD_table_Ptr) == 1)   // checksum test passed
                {
                    Process_OMD_RPREQ_Start_Page(OMD_table_Ptr);

                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
                    GPIO_Led_WP_Active(LED_OFF);
#endif
                    M_Active_Page = RP_RS;

#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString_Debug_Level_3(" -> RPAK!\r\n");
#endif
                }
                else // wrong checksum
                {
                    /* Disables the calibration handles. Switch to the RP. */
                    Disable_Calibration_Handles();

                    Page_Switch_Mailbox.Error_Code = OMD_ERR_STARTPAGE;  // Start Page RP request - Incorrect OMD - Forced to RP state
                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
                    GPIO_Led_WP_Active(LED_OFF);
#endif
                    M_Active_Page = RP_RS;

#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString("OMD ERROR: Checksum not equal !\r\n");
#endif
                }
            }
            else // incorrect OMD table header
            {
                /* Disables the calibration handles. Switch to the RP. */
                Disable_Calibration_Handles();

                Page_Switch_Mailbox.Error_Code = OMD_ERR_STARTPAGE;  // Start Page RP request - Incorrect OMD - Forced to RP state
                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
                      GPIO_TurnLedOff(LED_PAGE);
#endif
                M_Active_Page = RP_RS;

#ifdef RS232_DEBUG_LOGGING
                RS232_TxString("OMD ERROR : Incorrect OMD header ! \r\n");
#endif
            }
        } // Reference page Requested
        else if (WPREQ_PATTERN == Page_Switch_Mailbox.Start_Page) // Working Page  Requested
        {
#ifdef RS232_DEBUG_LOGGING
            RS232_TxString_Debug_Level_3("Start Page WP requested !\r\n");
#endif

            M_Start_Page = WP_AS;

#ifdef CODECHECK_WP_BEFORE_PAGESWITCH

            /* Advanced Code check used to check if the ECU pattern was copied by the ETK in the A2L specified RAM region
            Doesn't block the process if it fails with PageSwitch_depending_on_CodeCheck set to false. Blocks the process if PageSwitch_depending_on_CodeCheck is set to true.  */
            if (1 == CodeCheck_WP() || (!PageSwitch_depending_on_CodeCheck))
            {
#endif // #ifdef CODECHECK_WP_BEFORE_PAGESWITCH

                // verifies the OMD header (CID, version, number of EMU-Handles defined, and the OMD table size compared to the expected one for the target)
                if ( 1 == Check_OMD(OMD_table_Ptr) )   // OMD Table header correctly defined
                {
                    // checks the OMD checksum
                    if ( 1 == Check_OMD_Checksum(OMD_table_Ptr) )   // checksum test passed
                    {
                        // checks if the Activate EMU-Handles in the OMD table only use the available EMU-Handles
                        if (1 == Check_availableHandles(OMD_table_Ptr) )   // check passed - no unavailable handle activated
                        {
#ifdef CHECK_EXPECTED_HANDLE
                            // check if the handles are the expected ones
                            if ( 1 == Check_IsExpectedHandle(OMD_table_Ptr) ) // check passed - handles are expected ones
                            {
#endif //! #ifdef CHECK_EXPECTED_HANDLE
                                // Processes the OMD table for the Target Adress changes and configures the different calibration registers - WP request specific function
                                if ( 1 == Process_OMD_WPREQ_Start_Page(OMD_table_Ptr) )   // process OMD was successful
                                {
                                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPACK_PATTERN;
#ifdef LED_PAGE
                                    GPIO_Led_WP_Active(LED_ON);
#endif
                                    M_Active_Page = WP_AS;

#ifdef RS232_DEBUG_LOGGING
                                    RS232_TxString_Debug_Level_3(" -> WPAK!\r\n");
#endif
                                }
                                else // process OMD failed
                                {
                                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                                    RS232_TxString("OMD Processing ERROR !\r\n -> WPER!\r\n");
#endif
                                }
#ifdef CHECK_EXPECTED_HANDLE
                            }
                            else // At least one handle is expected
                            {
                                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                                RS232_TxString("OMD ERROR: Not expected handle !\r\n");
#endif
                            }
#endif //! #ifdef CHECK_EXPECTED_HANDLE
                        }
                        else // Invalid EMU-Handle
                        {
                            Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                            RS232_TxString("OMD ERROR: Invalid EMU-Handle used !\r\n");
#endif
                        }
                    }
                    else // wrong checksum
                    {
                        Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                        RS232_TxString("OMD ERROR: Checksum not equal !\r\n");
#endif
                    }
                }
                else // incorrect OMD table header
                {
                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString("OMD ERROR : Incorrect OMD header ! \r\n");
#endif
                }

#ifdef CODECHECK_WP_BEFORE_PAGESWITCH
            }
            else // CodeCheck_WP failed and PageSwitch_depending_on_CodeCheck set to true - Codecheck blocks the page switching if it fails
            {
                Page_Switch_Mailbox.Error_Code = OMD_ERR_CODECHCK; // CodeCheck pattern WP failed
                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                RS232_TxString("OMD ERROR : CodeCheck pattern WP failed ! \r\n");
#endif
            }

#endif // #ifdef CODECHECK_WP_BEFORE_PAGESWITCH
        }  // Working Page  Requested
        else // Unknown or Unexpected value
        {
#ifdef RS232_DEBUG_LOGGING
            RS232_TxString_Debug_Level_3("Start Page undefined -> Disable Overlay !\r\n");
#endif

            M_Start_Page = _Undefined;

            if (!(SER_ETK_PowerFailure_Check())) // If the Ram is valid (no power failure), the OMD is not cleared by the ECU and can be read.
            {
                // verifies the OMD header (CID, version, number of EMU-Handles defined, and the OMD table size compared to the expected one for the target)
                if (1 == Check_OMD(OMD_table_Ptr) )   // OMD Table header correctly defined
                {
                    // checks the OMD checksum
                    if (1 == Check_OMD_Checksum(OMD_table_Ptr) )   // checksum test passed
                    {
                        Process_OMD_RPREQ_Start_Page(OMD_table_Ptr); // Initialize the calibration registers if possible

                        Page_Switch_Mailbox.Error_Code = OMD_ERR_INVSTART; // Unknown or unexpected pattern found in the page switch mailbox start page
                        Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
                        GPIO_Led_WP_Active(LED_OFF);
#endif
                        M_Active_Page = RP_RS;

#ifdef RS232_DEBUG_LOGGING
                        RS232_TxString_Debug_Level_3(" Ram_Valid bit detected -> Calibration registers initialized if not yet done !\r\n");
#endif
                    }
                    else // wrong checksum
                    {
                        /* Disables the calibration handles. Switch to the RP. */
                        Disable_Calibration_Handles();

                        Page_Switch_Mailbox.Error_Code = OMD_ERR_INVSTART; // Unknown or unexpected pattern found in the page switch mailbox start page
                        Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
                        GPIO_Led_WP_Active(LED_OFF);
#endif
                        M_Active_Page = RP_RS;

#ifdef RS232_DEBUG_LOGGING
                        RS232_TxString("OMD ERROR: Checksum not equal !\r\n");
#endif
                    }
                }
                else // incorrect OMD table header
                {
                    /* Disables the calibration handles. Switch to the RP. */
                    Disable_Calibration_Handles();

                    Page_Switch_Mailbox.Error_Code = OMD_ERR_INVSTART; // Unknown or unexpected pattern found in the page switch mailbox start page
                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
                    GPIO_Led_WP_Active(LED_OFF);
#endif
                    M_Active_Page = RP_RS;

#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString("OMD ERROR : Incorrect OMD header ! \r\n");
#endif
                }
            }
            else // If the EMU RAM was cleared due to an invalid RAM, then the mailbox and the OMD have also been reset. Initialize to the RP in this case.
            {
                /* Disables the calibration handles. Switch to the RP. */
                Disable_Calibration_Handles();

                Page_Switch_Mailbox.Error_Code = OMD_ERR_DATARAM; // Trying to read the mailbox after a RAM invalidation without a DATA invalidation will give this strange error case as the mailbox will also be cleared by the RAM invalidation...
                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
               GPIO_Led_WP_Active(LED_OFF);
#endif
                M_Active_Page = RP_RS;
            }
        }// Unknown or Unexpected value
    } // if Protocol Based Pageswitch
}


uint8 SER_ETK_Page_Switch_Check_By_ECU(void)
{
    // Check if Pageswitch is necessary
    if (RPREQ_PATTERN == Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK
        || WPREQ_PATTERN == Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK
        || MOREQ_PATTERN == Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK)
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_4("\r\nPAGE SWITCH Requested \r\n");
#endif

        return 1; // Page switch requested
    }
    else
    {
        return 0;  // No Page switch requested
    }
}

void SER_ETK_Page_Switch_By_ECU(void)
{

    VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr = (struct OMD_TABLE*) & OMD_table.OMD_V1;


#ifdef RS232_DEBUG_LOGGING
    RS232_TxString_Debug_Level_4("Start Page Switch by the ECU\r\n");
#endif

    if (RPREQ_PATTERN == Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK) // Reference page Requested
    {

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_3("RP Request \r\n");
#endif

        if (0 == RPREQ_Force_Fail )
        {
            // verifies the OMD header (CID, version, number of EMU-Handles defined, and the OMD table size compared to the expected one for the target)
            if ( 1 == Check_OMD(OMD_table_Ptr) )   // OMD Table header correctly defined
            {
                // checks the OMD checksum
                if ( 1 == Check_OMD_Checksum(OMD_table_Ptr) )   // checksum test passed
                {
#ifdef ENDINIT_PROTECTION_DISABLED
                    Disable_Calibration_Handles(); // Disables the calibration handles
#else
                    Disable_Interrupts();

                    Disable_Calibration_Handles(); // Disables the calibration handles

                    Enable_Interrupts();
#endif

                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPACK_PATTERN;
#ifdef LED_PAGE
                    GPIO_Led_WP_Active(LED_OFF);
#endif
                    M_Active_Page = RP_RS;

#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString_Debug_Level_3(" -> RPAK!\r\n");
#endif
                }
                else // wrong checksum
                {
    				Page_Switch_Mailbox.Error_Code = OMD_ERR_CHECKSUM; // Forced RP request FAIL configured
                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPERR_PATTERN;
                    
#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString("OMD ERROR: Checksum not equal !\r\n");
#endif
                }
            }
            else // incorrect OMD table header
            {
                // If we get here the value will be set in the check of OMD
                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPERR_PATTERN;
                
#ifdef RS232_DEBUG_LOGGING
                RS232_TxString("OMD ERROR : Incorrect OMD header ! \r\n");
#endif
            }
        }
        else // Forced RP request FAIL configured
        {
            Page_Switch_Mailbox.Error_Code = OMD_ERR_RPRQFAIL; // Forced RP request FAIL configured
            Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = RPERR_PATTERN;
            
#ifdef RS232_DEBUG_LOGGING
            RS232_TxString("OMD ERROR : Forced RPREQ FAIL requested by an adaptive parameter ! \r\n");
#endif
        }
    }  // Reference page Requested
    else if (WPREQ_PATTERN == Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK) // Working Page Requested
    {
    	
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_3("WP Request \r\n");
#endif

        if (WPREQ_Force_Fail == 0) // Forced WP request FAIL NOT configured
        {
#ifdef CODECHECK_WP_BEFORE_PAGESWITCH

            /* Advanced Code check used to check if the ECU pattern was copied by the ETK in the A2L specified RAM region
                    Doesn't block the process if it fails with PageSwitch_depending_on_CodeCheck set to 0. Blocks the process if PageSwitch_depending_on_CodeCheck is set to 1.  */
            if ( 1 == CodeCheck_WP()  || (!PageSwitch_depending_on_CodeCheck))
            {
#endif // #ifdef CODECHECK_WP_BEFORE_PAGESWITCH

                // verifies the OMD header (CID, version, number of EMU-Handles defined, and the OMD table size compared to the expected one for the target)
                if ( 1 == Check_OMD(OMD_table_Ptr) )   // OMD Table header correctly defined
                {
                    // checks the OMD checksum
                    if ( 1 == Check_OMD_Checksum(OMD_table_Ptr) )   // checksum test passed
                    {
                        // checks if the Activate EMU-Handles in the OMD table only use the available EMU-Handles
                        if ( 1 == Check_availableHandles(OMD_table_Ptr) )   // check passed - no unavailable handle activated
                        {
#ifdef CHECK_EXPECTED_HANDLE
                            // check if the handles are the expected ones
                            if ( 1 == Check_IsExpectedHandle(OMD_table_Ptr) ) // check passed - handles are expected ones
                            {
#endif //! #ifdef CHECK_EXPECTED_HANDLE
#ifdef ENDINIT_PROTECTION_DISABLED
                                Enable_Calibration_Handles(OMD_table_Ptr); // Activates/Disables the OMD defined calibration handles
#else
                                Disable_Interrupts();

                                Set_Calibration_Handles(OMD_table_Ptr); // Activates/Disables the OMD defined calibration handles

                                Enable_Interrupts();
#endif

                                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPACK_PATTERN;
#ifdef LED_PAGE
                                GPIO_Led_WP_Active(LED_ON);
#endif
                                M_Active_Page = WP_AS;

#ifdef RS232_DEBUG_LOGGING
                                RS232_TxString_Debug_Level_3(" -> WPAK!\r\n");
#endif
#ifdef CHECK_EXPECTED_HANDLE
                            }
                            else // At least one handle is expected
                            {
                                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                                RS232_TxString("OMD ERROR: Not expected handle !\r\n");
#endif
                            }
#endif //! #ifdef CHECK_EXPECTED_HANDLE
                        }
                        else // Invalid EMU-Handle
                        {
                            Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;
                            
#ifdef RS232_DEBUG_LOGGING
                            RS232_TxString("OMD ERROR: Invalid EMU-Handle used !\r\n");
#endif
                        }
                    }
                    else // wrong checksum
                    {
                        Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;
                        
#ifdef RS232_DEBUG_LOGGING
                        RS232_TxString("OMD ERROR: Checksum not equal !\r\n");
#endif
                    }
                }
                else // incorrect OMD table header
                {
                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;
                    
#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString("OMD ERROR : Incorrect OMD header ! \r\n");
#endif
                }

#ifdef CODECHECK_WP_BEFORE_PAGESWITCH
            }
            else // CodeCheck_WP failed and PageSwitch_depending_on_CodeCheck set to true - Codecheck blocks the page switching if it fails
            {
                Page_Switch_Mailbox.Error_Code = OMD_ERR_CODECHCK; // CodeCheck pattern WP failed
                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                RS232_TxString("OMD ERROR : CodeCheck pattern WP failed ! \r\n");
#endif
            }

#endif // #ifdef CODECHECK_WP_BEFORE_PAGESWITCH
        }

        else // Forced WP request FAIL configured
        {
            Page_Switch_Mailbox.Error_Code = OMD_ERR_WPRQFAIL; // Forced WP request FAIL configured
            Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = WPERR_PATTERN;
#ifdef RS232_DEBUG_LOGGING
            RS232_TxString("OMD ERROR : Forced WPREQ FAIL requested by an adaptive parameter ! \r\n");
#endif
        }

    }  // Working Page  Requested
    /* MOREQ is currently not supported on startup. This will switch to the Reference page, and also send a RPACK pattern. */
    else if (MOREQ_PATTERN == Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK) // Modify Request
    {
    	
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_3("Modify Request \r\n");
#endif

        if (MOREQ_Force_Fail == 0) // Forced Modify request FAIL NOT configured
        {
            // verifies the OMD header (CID, version, number of EMU-Handles defined, and the OMD table size compared to the expected one for the target)
            if ( 1 == Check_OMD(OMD_table_Ptr) )   // OMD Table header correctly defined
            {
                // checks the OMD checksum
                if ( 1 == Check_OMD_Checksum(OMD_table_Ptr) )   // checksum test passed
                {
                    // checks if the Activate EMU-Handles in the OMD table only use the available EMU-Handles
                    if ( 1 == Check_availableHandles(OMD_table_Ptr) )   // check passed - no unavailable handle activated
                    {
                        // Processes the OMD table for the Target Adress changes and configures the different calibration registers - Modify request specific function
                        if ( 1 == Process_OMD_MORQ(OMD_table_Ptr) )   // process OMD was successful
                        {
                            Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = MOACK_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                            RS232_TxString_Debug_Level_3(" -> MOAK!\r\n");
#endif
                        }
                        else // process OMD failed
                        {
                            Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = MOERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                            RS232_TxString("OMD Processing ERROR !\r\n -> MOER!\r\n");
#endif
                        }
                    }
                    else // Invalid EMU-Handle
                    {
                        Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = MOERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                        RS232_TxString("OMD ERROR: Invalid EMU-Handle used !\r\n");
#endif
                    }
                }
                else // wrong checksum
                {
                    Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = MOERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString("OMD ERROR: Checksum not equal !\r\n");
#endif
                }
            }
            else // incorrect OMD table header
            {
                Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = MOERR_PATTERN;

#ifdef RS232_DEBUG_LOGGING
                RS232_TxString("OMD ERROR : Incorrect OMD header ! \r\n");
#endif
            }
        }
        else // Forced Modify request FAIL configured
        {
            Page_Switch_Mailbox.Error_Code = OMD_ERR_MORQFAIL; // Forced Modify request FAIL configured
            Page_Switch_Mailbox.Page_Switching_Pattern_REQ_ACK = MOERR_PATTERN;
#ifdef RS232_DEBUG_LOGGING
            RS232_TxString("OMD ERROR : Forced MOREQ FAIL requested by an adaptive parameter ! \r\n");
#endif
        }
    }  // Modify Request
}

/* Calculates and then checks the OMD checksum and returns 1 if the test passes, or 0 if it fails. The size of the OMD should be a multiple of 4 bytes.
The OMD checksum calculates the checksum with an XOR function starting from the OMD_Size field in the OMD just under the Checksum field and it calculates it until the end of the table. */
uint8 Check_OMD_Checksum(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
    uint32* Ptr_Checksum;
    uint32* EndPtr_Checksum;
    uint32 checksum;

    uint32 OMD_Length_32BitValues = (OMD_table_Ptr->OMD_Size + 16)/4; // Adding the OMD header to get the end of the table into the checksum, then dividing by 4 to get the number of 32 bit values


    Ptr_Checksum = (uint32*)(OMD_table_Ptr)+3;  // The checksum start value is the OMD_Size value (4th 32bit value in the OMD)
    EndPtr_Checksum = (uint32*)(OMD_table_Ptr)+OMD_Length_32BitValues;  // points to the end of the OMD

    checksum = 0;
    // Calculate the OMD Checksum
    while (Ptr_Checksum < EndPtr_Checksum)
    {
        checksum = checksum ^ *Ptr_Checksum;
        Ptr_Checksum++;
    }

    if (checksum == OMD_table_Ptr->Checksum)   // calculated checksum corresponds to the checksum in the OMD table
    {
        return 1;  // Checksum test passed
    }
    else // wrong checksum value
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_CHECKSUM; // Checksum of OMD is invalid

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("\r\n PAGESWITCH OMD CHECKSUM ERROR !\r\nOMD ERROR: Checksum not equal !\r\nOMD Checksum: ");
        RS232_TxHexLong(OMD_table_Ptr->Checksum);
        RS232_TxString("\r\nECU calculated Checksum : ");
        RS232_TxHexLong(checksum);
        RS232_TxString("\r\n");
#endif

        return 0;  // Checksum test failed
    }
}

/* Checks the OMD table to see if the defined value for the EMU handles number corresponds to the maximum supported by the target ECU.
  Also checks if the OMD_Size is the same as the one expected by the ECU.
  Returns 1 upon success, or 0 if the test fails.
  The CID and OMD_Size values can be read with the 0 value in the initial startup phase. This would meand that the OMD table is empty and was not set up by the ETK.
*/
uint8 Check_OMD(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
#ifdef RS232_DEBUG_LOGGING
    RS232_TxString_Debug_Level_4("Checking the OMD table !\r\n");
#endif

    // Incorrect CID of the OMD - Currently implemented value is 1 and 2 - Indicates incompatible layout changes.
    if (!(
#ifdef OMD_CID_VERSION_1      
      (OMD_CID_VERSION_1 == OMD_table_Ptr->CID ) 
#endif
#if defined(OMD_CID_VERSION_1)&&defined(OMD_CID_VERSION_2)
      || 
#endif
#ifdef OMD_CID_VERSION_2
      (OMD_CID_VERSION_2 == OMD_table_Ptr->CID )
#endif
      ))
    {
        if ( 0 == OMD_table_Ptr->CID  && 0 == OMD_table_Ptr->OMD_Size ) //  The OMD table is empty and was not set up by the ETK.
        {
            Page_Switch_Mailbox.Error_Code = OMD_ERR_EMPTY; // Incorrect CID of the OMD
            // This can happen in the initial ECU startup phase and should not always be considered as an error. Therefore we don't use an error code in the mailbox in this case.
#ifdef RS232_DEBUG_LOGGING
            RS232_TxString_Debug_Level_3("The OMD table is empty and was not set up by the ETK !\r\n");
#endif
            return 0;
        }
        else // The OMD table was set up by the ETK with a wrong CID.
        {
            Page_Switch_Mailbox.Error_Code = OMD_ERR_CID; // Incorrect CID of the OMD

#ifdef RS232_DEBUG_LOGGING
            RS232_TxString("ERROR: Incorrect CID of the OMD !\r\n");

            RS232_TxString("OMD CID = ");
            RS232_TxHexLong(OMD_table_Ptr->CID);
            RS232_TxString("\r\nExpected value = 1 or 2\r\n");
            //RS232_TxHexLong(OMD_CID_VERSION_1);
            //RS232_TxString("\r\n");
#endif

            return 0;
        }
    }
    else if (OMD_table_Ptr->Version != IMPLEMENTED_OMD_VERSION) //  Incorrect extension version of the CID in the OMD - Currently implemented value is 0 - Compatible extensions check for an existing CID.
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_VER; //  Incorrect version of the OMD

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ERROR: Incorrect version of the OMD !\r\n");

        RS232_TxString("OMD Version = ");
        RS232_TxHexLong(OMD_table_Ptr->Version);
        RS232_TxString("\r\nExpected value = ");
        RS232_TxHexLong(IMPLEMENTED_OMD_VERSION);
        RS232_TxString("\r\n");
#endif

        return 0;
    }
#ifdef OMD_CID_VERSION_1    
    else if ((OMD_CID_VERSION_1 == OMD_table_Ptr->CID ) && (NUMBER_OMD_MAX_CALIB_HANDLES < OMD_table_Ptr->EMU_Handles_Number )) // Exceeded the maximum number of calibration handles value
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_NROHANDLES; // Exceeded the maximum number of calibration handles value

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ERROR: Exceeded the maximum number of calibration handles value !\r\n");

        RS232_TxString("OMD Number of EMU-Handles = ");
        RS232_TxHexLong(OMD_table_Ptr->EMU_Handles_Number);
        RS232_TxString("\r\nExpected value <= ");
        RS232_TxHexLong(NUMBER_OMD_MAX_CALIB_HANDLES);
        RS232_TxString("\r\n");
#endif

        return 0;
    }
#endif
#ifdef OMD_CID_VERSION_2
    else if ((OMD_CID_VERSION_2 == OMD_table_Ptr->CID ) && (OMDV2_MAX_CALIB_HANDLES_NUMBER < OMD_table_Ptr->EMU_Handles_Number )) // Exceeded the maximum number of calibration handles value
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_NROHANDLES; // Exceeded the maximum number of calibration handles value

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ERROR: Exceeded the maximum number of calibration handles value !\r\n");

        RS232_TxString("OMD Number of EMU-Handles = ");
        RS232_TxHexLong(OMD_table_Ptr->EMU_Handles_Number);
        RS232_TxString("\r\nExpected value <= ");
        RS232_TxHexLong(OMDV2_MAX_CALIB_HANDLES_NUMBER);
        RS232_TxString("\r\n");
#endif

        return 0;
    }
#endif
#ifdef OMD_CID_VERSION_1
    else if ((OMD_CID_VERSION_1 == OMD_table_Ptr->CID ) && (OMD_table_Ptr->OMD_Size != ((OMD_table_Ptr->EMU_Handles_Number * 4) + 4 + (16 * NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION)))) // Incorrect OMD table size
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_SIZE; // Incorrect OMD table size defined

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ERROR: Incorrect OMD table size defined !\r\n");

        RS232_TxString("OMD_Size = ");
        RS232_TxHexLong(OMD_table_Ptr->OMD_Size);
        RS232_TxString("\r\nExpected value = ");
        RS232_TxHexLong(((OMD_table_Ptr->EMU_Handles_Number * 4) + 4 + (16 * NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION)));
        RS232_TxString("\r\n");
#endif

        return 0;
    }
#endif
#ifdef OMD_CID_VERSION_2
    else if ((OMD_CID_VERSION_2 == OMD_table_Ptr->CID ) && (OMD_table_Ptr->OMD_Size != ((OMD_table_Ptr->EMU_Handles_Number * 12) + 4 + (16 * OMDV2_NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION)))) // Incorrect OMD table size
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_SIZE; // Incorrect OMD table size defined

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ERROR: Incorrect OMD table size defined !\r\n");

        RS232_TxString("OMD_Size = ");
        RS232_TxHexLong(OMD_table_Ptr->OMD_Size);
        RS232_TxString("\r\nExpected value = ");
        RS232_TxHexLong(((OMD_table_Ptr->EMU_Handles_Number * 12) + 4 + (16 * OMDV2_NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION)));
        RS232_TxString("\r\n");
#endif
        return 0;
    }
#endif
    else // The OMD table is correctly defined. -> Check passed
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_4("Check: Correct OMD table !\r\n");
#endif

        return 1;
    }
}

/* Returns 1 if no unavailable EMU handle are activated in the OMD, and 0 if an illegal activation is found. */
uint8 Check_availableHandles(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
    uint32 compareTmp;
    uint32 result = 0;
    int i, maxLoop = 0;

    //uint32 OMDV2_NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION = (OMD_table_Ptr->EMU_Handles_Number +31)/ 32;


#ifdef RS232_DEBUG_LOGGING
    RS232_TxString_Debug_Level_4("Checking the available EMU-Handles for activation !\r\n");
#endif

    if (OMD_CID_VERSION_1 == OMD_table_Ptr->CID )
    {
        maxLoop = NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION;
    }
    else if (OMD_CID_VERSION_2 == OMD_table_Ptr->CID )
    {
        maxLoop = OMDV2_NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION;
    }

    for (i = 0; i < maxLoop; i++)
    {
        compareTmp = OMD_table_Ptr->Available_EMU_Handles[i];
        // If we try to activate a non available handle we will get a value different from 0 after an XOR.
        result |= (compareTmp | OMD_table_Ptr->Activate_EMU_Handles[i]) ^ compareTmp;
    }

    if (result == 0) // no unavailable EMU handle activated
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_4("Available EMU Handles Check: Correct OMD table !\r\n");
#endif

        return 1;
    }
    else
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_ACTHANDLES; // Not available EMU-Handle activated in OMD

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ERROR: Not available EMU-Handle activated !\r\n");
        RS232_TxString("Compare XOR = ");
        RS232_TxHexLong(result);
        RS232_TxString(" \r\n");
#endif

        return 0;
    }
}


/* Returns an OR - Accumulated value of the activated handles.
If the returned value is 0 then no handles are activated in the OMD table. */
uint32 Get_Activated_EMU_Handles_Accum(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
    uint32 result = 0;
    int i, maxLoop = 0;

    //uint32 OMDV2_NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION = (OMD_table_Ptr->EMU_Handles_Number + 31) / 32;


    if (OMD_CID_VERSION_1 == OMD_table_Ptr->CID )
    {
        maxLoop = NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION;
    }
    else if (OMD_CID_VERSION_2 == OMD_table_Ptr->CID )
    {
        maxLoop = OMDV2_NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION;
    }

    for (i = 0; i < maxLoop; i++)
    {
        result |= OMD_table_Ptr->Activate_EMU_Handles[i];
    }

    return result;
}


/* Updates the RABR, OTAR, and OMASK registers in all the CPUs with the defined values of the OMD if required.
The RABR and OMASK registers are set up at the first execution of this function after a restart.
The tiles are also set up and configured for calibration access if available according to the Allocate EMU-Handle value of the OMD.
Returns 1 upon success, or 0 if it fails. */
uint8 Process_OMD_MORQ(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{

    // Initial configuration of the RABR and OMASK registers.
    if (firstModifyRequest == 0)
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_2("OMD Process: First Activation - Initializing the Calibration handles !\r\n");
#endif

#ifdef ENDINIT_PROTECTION_DISABLED
        // Configures the initial value of the RABR, OTAR and OMASK registers used for the calibration configuration, and sets the OVC_ENABLE value for the required CPU cores
        Initialize_Calib_Registers();
#else
        Disable_Interrupts();
        // Configures the initial value of the RABR, OTAR and OMASK registers used for the calibration configuration, and sets the OVC_ENABLE value for the required CPU cores
        Initialize_Calib_Registers(OMD_table_Ptr);

        Enable_Interrupts();
#endif

        firstModifyRequest = 1; // first step of the first Modify request processed
    }

#ifndef ENDINIT_PROTECTION_DISABLED
    Disable_Interrupts();
#endif

    /** In some cases the OMD table is set up during the startup of the ECU with the activate EMU-Handles bit set for the WP mode.
    The table contains the correct state for the WP mode calibration handle activation.
    However, the problem is that the Working page request (WPRQ) comes only after a Modify Request (MORQ) in the case of the XETK-S20.
    And the calibration handles should only be disabled during a MORQ.
    The activation of the WP mode will be done after through a WPRQ written in the mailbox by the ETK.
    Thus we check here if the calibration mode is set to the reference page (RP), which means that no emulation is currently activated.
    If we are in RP mode, the calibration handles are not set with the value present in the OMD table as all the handles are disabled. */
    if (Check_Calibration_Handles_in_RP_mode() != 1) // Only updates the calibration handles activation register if the ECU is not in RP.
    {
        // Sets the calibration handles to Activate/Disabled state
        Set_Calibration_Handles(OMD_table_Ptr); // Activates/Disables the OMD defined calibration handles
    }

    if (firstModifyRequest == 1) // first Modifiy request currently processed - initializing all the OTAR registers
    {
        // Configures ALL the OTAR registers with the OMD target addresses for the emulation target addresses
        Update_All_OvlHandleReg(OMD_table_Ptr);

        firstModifyRequest = 2; // first Modify request completely processed
    }
    else // standard modify request - only updating the OTAR registers with the modify bits set to 1
    {
        // Configures the OTAR register with the modifications in the OMD for the emulation target addresses
        Update_OvlHandleReg(OMD_table_Ptr);
    }

#ifndef ENDINIT_PROTECTION_DISABLED
    Enable_Interrupts();
#endif

    return 1;
}



/* Start page WPREQ specific function - Same as Process_OMD_MORQ but the Enable_Calibration_Handles function is executed after the Update_OvlHandleReg function !!
This function should only be called in the handshake procedure, because the tiles are not configured inside it.
Updates the RABR, OTAR, and OMASK registers in all the CPUs with the defined values of the OMD if required.
The RABR and OMASK registers are set up at the first execution of this function after a restart.
The tiles don't need to be set up and configured for calibration access because this step has already been executed during the previous step of the handshake when checking for the RAM_Valid bit.
Returns 1 upon success, or 0 if it fails. */
uint8 Process_OMD_WPREQ_Start_Page(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
    // Initial configuration of the RABR and OMASK registers.

    if (firstModifyRequest == 0)
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_2("OMD Process: First Activation - Initializing the Calibration handles !\r\n");
#endif

#ifdef ENDINIT_PROTECTION_DISABLED
        // Configures the initial value of the RABR, OTAR and OMASK registers used for the calibration configuration, and sets the OVC_ENABLE value for the required CPU cores
        Initialize_Calib_Registers();
#else
        Disable_Interrupts();
        // Configures the initial value of the RABR, OTAR and OMASK registers used for the calibration configuration, and sets the OVC_ENABLE value for the required CPU cores
        Initialize_Calib_Registers(OMD_table_Ptr);

        Enable_Interrupts();
#endif

        firstModifyRequest = 1; // first step of the first WP request in the start page processed
    }


#ifndef ENDINIT_PROTECTION_DISABLED
    Disable_Interrupts();
#endif

    if (1 == firstModifyRequest ) // first Modifiy request currently processed - initializing all the OTAR registers
    {
        // Configures ALL the OTAR registers with the OMD target addresses for the emulation target addresses
        Update_All_OvlHandleReg(OMD_table_Ptr);

        firstModifyRequest = 2; // first WP request in the start page completely processed
    }
    else // standard modify request - only updating the OTAR registers with the modify bits set to 1
    {
        // Configures the OTAR register with the modifications in the OMD for the emulation target addresses
        Update_OvlHandleReg(OMD_table_Ptr);
    }

    // Sets the calibration handles to Activate/Disabled state
    Set_Calibration_Handles(OMD_table_Ptr); // Activates/Disables the OMD defined calibration handles

#ifndef ENDINIT_PROTECTION_DISABLED
    Enable_Interrupts();
#endif

    return 1;
}


/* Start page RPREQ specific function - Same as Process_OMD_MORQ but the Enable_Calibration_Handles function is executed after the Update_OvlHandleReg function !!
This function should only be called in the handshake procedure, because the tiles are not configured inside it.
This function will only set up the calibratoin registers if needed and then disable them.
Updates the RABR, OTAR, and OMASK registers in all the CPUs with the defined values of the OMD if required.
The RABR and OMASK registers are set up at the first execution of this function after a restart.
The tiles don't need to be set up and configured for calibration access because this step has already been executed during the previous step of the handshake when checking for the RAM_Valid bit.
Returns 1 upon success, or 0 if it fails. */
uint8 Process_OMD_RPREQ_Start_Page(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
    // Initial configuration of the RABR and OMASK registers.

    if (firstModifyRequest == 0)
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_2("OMD Process: First Activation - Initializing the Calibration handles !\r\n");
#endif

#ifdef ENDINIT_PROTECTION_DISABLED
        // Configures the initial value of the RABR, OTAR and OMASK registers used for the calibration configuration, and sets the OVC_ENABLE value for the required CPU cores
        Initialize_Calib_Registers();
#else
        Disable_Interrupts();
        // Configures the initial value of the RABR, OTAR and OMASK registers used for the calibration configuration, and sets the OVC_ENABLE value for the required CPU cores
        Initialize_Calib_Registers(OMD_table_Ptr);

        Enable_Interrupts();
#endif

        firstModifyRequest = 1; // first step of the first WP request in the start page processed
    }


#ifndef ENDINIT_PROTECTION_DISABLED
    Disable_Interrupts();
#endif

    if (1 == firstModifyRequest ) // first Modifiy request currently processed - initializing all the OTAR registers
    {
        // Configures ALL the OTAR registers with the OMD target addresses for the emulation target addresses
        Update_All_OvlHandleReg(OMD_table_Ptr);

        firstModifyRequest = 2; // first WP request in the start page completely processed
    }

    // Disables the calibration handles
    Disable_Calibration_Handles();

#ifndef ENDINIT_PROTECTION_DISABLED
    Enable_Interrupts();
#endif

    return 1;
}

