/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "ETK_Integration_Cfg.h"
#include "ETK_SER_Page_Ctrl_Fct.h"

#define IsOMD_BitSet(src, bitnumber) ((src[bitnumber/32])&(1<<(bitnumber/32)))

enum UpdateType
{
    UpdateModified = 0,
    UpdateAll = 1
};

/** struct _omd_emu_header is used to help simplify the code by making the decison ahead of time which OMD2 table is being used and populating with the
 * offsets needed.  This helps to not have to make a decision each time you access the OMD contents
 */
struct _omd_emu_header {
	volatile uint32 *Available_EMU_Handles; // Available calibration handles defined in the A2L file
	volatile uint32 *Allocate_EMU_Handles;  // Allocate the calibration handles (set the corresponding tile to calibration mode)
	volatile uint32 *Activate_EMU_Handles;  // Enable/Disable the corresponding calibration handle
	volatile uint32 *Modify_EMU_Handles;    // Modify the Target Address of the corresponding calibration handle
	volatile struct Handle_Entries *Handle; // Target Address of the corresponding calibration handle
};



/** Disables interrupts.
This can be replaced by a code raising the task priority level. */
void Disable_Interrupts(void)
{
    DISABLE_INTERRUPT();
}

/** Enables interrupts.
This can be replaced by a code raising the task priority level. */
void Enable_Interrupts(void)
{
    ENABLE_INTERRUPT();
}

/* Updates registers if a modify bit is given in the OMD.
This will update the emulation target addresses if it is requested by the corresponding modify bit in the OMD table. */
// Function left to be compatible with ETK_SER_Page_Ctrl_Fct.c
void Update_OvlHandleReg(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
    Common_Update_OvlHandleReg(OMD_table_Ptr, UpdateModified); // 0 means it will only update modified handles
}


/* Updates the all registers for all the CPUs without checking the modify bit in the OMD.
This will initialize the emulation target addresses with the target addresses found in the OMD. */
// Function left to be compatible with ETK_SER_Page_Ctrl_Fct.c
void Update_All_OvlHandleReg(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
    Common_Update_OvlHandleReg(OMD_table_Ptr, UpdateAll);
}


/* Configures the initial value of all handles in order to avoid inconsistencies. OMDV1 Flash and Size values are set for the handles used for OMD V1 */
void Initialize_Calib_Registers(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{

    if (OMD_table_Ptr->CID == OMD_CID_VERSION_1) // CID version 1 detected - static calibration handles
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_4("CID 1 detected: Initializing calibration registers !\r\n");
#endif
    }

#ifdef OMD_CID_VERSION_2
    else if (OMD_table_Ptr->CID == OMD_CID_VERSION_2) // CID version 2 detected - LERTv3 dynamic calibration handles mode
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_4("CID 2 detected: Initializing calibration registers !\r\n");
#endif
    }

#endif


}


/* Disables all the calibration handles. */
void Disable_Calibration_Handles(void)
{

#if defined(OVL_HW_SUPPORTED)
        /* Turn both off */
        RTU0__OMU.OER.R=0;
        RTU1__OMU.OER.R=0;
#elif defined(OVL_POINTER_SUPPORTED)
    gPage_off_group0 = gPage_off_group1 = gPage_off_group2 =0;  // Set gPage_off to reference page offset (0)
#endif
}


/** Convert_OMD_Size_to_OMU()
 *  This function will convert a size passed in from INCA to a corresponding value used in the OMU register to cover
 *  that size.  It can be larger but not smaller.
 */
uint32 Convert_OMD_Size_to_OMU(uint32 lOMD_Size)
{
	uint32 rtnOMU_Size=0;

	if(      lOMD_Size <=  0x000400)//0000b - Region size is 1 KB. Low-order 1 bit of LSA and PSA must be zero.
			rtnOMU_Size=0;
	else if( lOMD_Size <=  0x000800)//0001b - Region size is 2 KB. Low-order 1 bit of LSA and PSA must be zero.
			rtnOMU_Size=1;
	else if( lOMD_Size <=  0x001000) //0010b - Region size is 4 KB. Low-order 2 bits of LSA and PSA must be zero.
			rtnOMU_Size=2;
	else if( lOMD_Size <=  0x002000) //0011b - Region size is 8 KB. Low-order 3 bits of LSA and PSA must be zero.
			rtnOMU_Size=3;
	else if( lOMD_Size <=  0x004000) //0100b - Region size is 16 KB. Low-order 4 bits of LSA and PSA must be zero.
			rtnOMU_Size=4;
	else if( lOMD_Size <=  0x008000) //0101b - Region size is 32 KB. Low-order 5 bits of LSA and PSA must be zero.
			rtnOMU_Size=5;
	else if( lOMD_Size <=  0x010000) //0110b - Region size is 64 KB. Low-order 6 bits of LSA and PSA must be zero.
			rtnOMU_Size=6;
	else if( lOMD_Size <=  0x020000) //0111b - Region size is 128 KB. Low-order 7 bits of LSA and PSA must be zero.
			rtnOMU_Size=7;
	else if( lOMD_Size <=  0x040000) //1000b - Region size is 256 KB. Low-order 8 bits of LSA and PSA must be zero.
			rtnOMU_Size=8;
	else if( lOMD_Size <=  0x080000) //1001b - Region size is 512 KB. Low-order 9 bits of LSA and PSA must be zero.
			rtnOMU_Size=9;
	else if( lOMD_Size <=  0x100000) //1010b - Region size is 1024 KB. Low-order 10 bits of LSA and PSA must be zero.
			rtnOMU_Size=10;
	else if( lOMD_Size <=  0x200000) //1011b - Region size is 2048 KB. Low-order 11 bits of LSA and PSA must be zero.
			rtnOMU_Size=11;
	else if( lOMD_Size <=  0x400000) //1100b - Region size is 4096 KB. Low-order 12 bits of LSA and PSA must be zero.
			rtnOMU_Size=12;
	else if( lOMD_Size <=  0x800000) //1101b - Region size is 8192 KB. Low-order 13 bits of LSA and PSA must be zero.
			rtnOMU_Size=13;

	return rtnOMU_Size;
}


/** SetOMD2_HeaderStruct() Sets all the calibration handles activation value to the defined value in the OMD table. */
static struct _omd_emu_header SetOMD2_HeaderStruct(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
	struct _omd_emu_header omd_emu_header;

	union OMD_TABLE_V1_V2 *union_omd=(union OMD_TABLE_V1_V2 *)(&OMD_table_Ptr->CID);

	if( OMD_table_Ptr->EMU_Handles_Number <= 32)
	{
	  omd_emu_header.Available_EMU_Handles=&union_omd->OMD_V2_32.Available_EMU_Handles[0];
	  omd_emu_header.Allocate_EMU_Handles=&union_omd->OMD_V2_32.Allocate_EMU_Handles[0];
	  omd_emu_header.Activate_EMU_Handles=&union_omd->OMD_V2_32.Activate_EMU_Handles[0];
	  omd_emu_header.Modify_EMU_Handles=&union_omd->OMD_V2_32.Modify_EMU_Handles[0];
	  omd_emu_header.Handle=&union_omd->OMD_V2_32.Handle[0];
	}
#if 64<=OMDV2_MAX_CALIB_HANDLES_NUMBER
	else if(OMD_table_Ptr->EMU_Handles_Number <= 64)
	{
	  omd_emu_header.Available_EMU_Handles=&union_omd->OMD_V2_64.Available_EMU_Handles[0];
	  omd_emu_header.Allocate_EMU_Handles=&union_omd->OMD_V2_64.Allocate_EMU_Handles[0];
	  omd_emu_header.Activate_EMU_Handles=&union_omd->OMD_V2_64.Activate_EMU_Handles[0];
	  omd_emu_header.Modify_EMU_Handles=&union_omd->OMD_V2_64.Modify_EMU_Handles[0];
	  omd_emu_header.Handle=&union_omd->OMD_V2_64.Handle[0];
	}
#endif
#if 96<=OMDV2_MAX_CALIB_HANDLES_NUMBER
	else if(OMD_table_Ptr->EMU_Handles_Number <= 96)
	{
	  omd_emu_header.Available_EMU_Handles=&union_omd->OMD_V2_96.Available_EMU_Handles[0];
	  omd_emu_header.Allocate_EMU_Handles=&union_omd->OMD_V2_96.Allocate_EMU_Handles[0];
	  omd_emu_header.Activate_EMU_Handles=&union_omd->OMD_V2_96.Activate_EMU_Handles[0];
	  omd_emu_header.Modify_EMU_Handles=&union_omd->OMD_V2_96.Modify_EMU_Handles[0];
	  omd_emu_header.Handle=&union_omd->OMD_V2_96.Handle[0];
	}
#endif
#if 128<=OMDV2_MAX_CALIB_HANDLES_NUMBER
	else if(OMD_table_Ptr->EMU_Handles_Number <= 128)
	{
	  omd_emu_header.Available_EMU_Handles=&union_omd->OMD_V2_128.Available_EMU_Handles[0];
	  omd_emu_header.Allocate_EMU_Handles=&union_omd->OMD_V2_128.Allocate_EMU_Handles[0];
	  omd_emu_header.Activate_EMU_Handles=&union_omd->OMD_V2_128.Activate_EMU_Handles[0];
	  omd_emu_header.Modify_EMU_Handles=&union_omd->OMD_V2_128.Modify_EMU_Handles[0];
	  omd_emu_header.Handle=&union_omd->OMD_V2_128.Handle[0];
	}
#endif
	else
	{
		   //Not a valid handle so use default 32
		  omd_emu_header.Available_EMU_Handles=&union_omd->OMD_V2_32.Available_EMU_Handles[0];
		  omd_emu_header.Allocate_EMU_Handles=&union_omd->OMD_V2_32.Allocate_EMU_Handles[0];
		  omd_emu_header.Activate_EMU_Handles=&union_omd->OMD_V2_32.Activate_EMU_Handles[0];
		  omd_emu_header.Modify_EMU_Handles=&union_omd->OMD_V2_32.Modify_EMU_Handles[0];
		  omd_emu_header.Handle=&union_omd->OMD_V2_32.Handle[0];
	}
 return omd_emu_header;

}


/* Sets all the calibration handles activation value to the defined value in the OMD table. */
void Set_Calibration_Handles(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
{
	struct _omd_emu_header omd_emu_header=SetOMD2_HeaderStruct(OMD_table_Ptr);
#ifdef OMD_CID_VERSION_1
    if (OMD_CID_VERSION_1 == OMD_table_Ptr->CID ) // CID version 1 detected - static calibration handles
    {
        //This is intended to support "FixedSizeMoveableRAM"
        if( omd_emu_header.Activate_EMU_Handles[0])
		{
			if( (uint32 )(&__cal_wp2_start)<=omd_emu_header.Handle[0].physical  && omd_emu_header.Handle[0].physical < (uint32 )(&__cal_wp2_end))
			{
#ifdef OVL_HW_SUPPORTED
				RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDLSA.R =  omd_emu_header.Handle[0].logical;   //Logical Address  (RP)
				RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDPSA.R =  omd_emu_header.Handle[0].physical;  //Physical address (WP)
				RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDRS.R  = Convert_OMD_Size_to_OMU(omd_emu_header.Handle[0].size);  //Size
				RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDRZA.R = 7;  //Active not tied to a Zone
                RTU0__OMU.OER.R= 1;
#elif defined(OVL_POINTER_SUPPORTED)
            gPage_off_group0 = omd_emu_header.Handle[0].physical - omd_emu_header.Handle[0].logical;    // Set gPage_off to working page offset
#endif

			}
			if( (uint32 )(&__cal_wp2_start)<=omd_emu_header.Handle[1].physical  && omd_emu_header.Handle[1].physical < (uint32 )(&__cal_wp2_end))
			{
#ifdef OVL_HW_SUPPORTED
				RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDLSA.R =  omd_emu_header.Handle[1].logical;   //Logical Address  (RP)
				RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDPSA.R =  omd_emu_header.Handle[1].physical;  //Physical address (WP)
				RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDRS.R  = Convert_OMD_Size_to_OMU(omd_emu_header.Handle[0].size);  //Size
			    RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDRZA.R = 7;  //Active not tied to a Zone
			    RTU1__OMU.OER.R= 1;
#elif defined(OVL_POINTER_SUPPORTED)
            gPage_off_group1 = omd_emu_header.Handle[1].physical - omd_emu_header.Handle[1].logical;    // Set gPage_off to working page offset
#endif
			}
			if( (uint32 )(&__cal_wp2_start)<=omd_emu_header.Handle[2].physical  && omd_emu_header.Handle[2].physical < (uint32 )(&__cal_wp2_end))
			{
				//M33 only supports Offset pointer
#if defined(OVL_POINTER_SUPPORTED)
            gPage_off_group2 = omd_emu_header.Handle[2].physical - omd_emu_header.Handle[2].logical;    // Set gPage_off to working page offset
#endif
			}

        }
    }
#endif
#if defined(OMD_CID_VERSION_1)&&defined(OMD_CID_VERSION_2)
    else
#endif
#ifdef OMD_CID_VERSION_2
    if (OMD_CID_VERSION_2 == OMD_table_Ptr->CID ) // CID version 2 detected - 1x GERAM + 3x CERAM
    {
       //This mode only supports FlashRangeSpecificEmuRAM method
		uint32 idx;
		uint8 active_handles_present0=0,  active_handles_present1=0;
    	uint32 cidx0=0, cidx1=0;

		for(idx=0; idx<OMD_table_Ptr->EMU_Handles_Number; idx++)
		{
			if( 0<omd_emu_header.Handle[idx].size)
			{

				if( (uint32 )(&__cal_wp_start)<=omd_emu_header.Handle[idx].physical  && omd_emu_header.Handle[idx].physical < (uint32 )(&__cal_wp_end))
				{
# ifdef OVL_HW_SUPPORTED
					RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDLSA.R =  omd_emu_header.Handle[idx].logical;   //Logical Address  (RP)
					RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDPSA.R =  omd_emu_header.Handle[idx].physical;  //Physical address (WP)
					RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDRS.R  = Convert_OMD_Size_to_OMU(omd_emu_header.Handle[idx].size);  //Size

					 if( IsOMD_BitSet(omd_emu_header.Activate_EMU_Handles, idx) )
					 {
						 RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDRZA.R = 7;  //Active not tied to a Zone
						 active_handles_present0=1;
					 }
					 else
					 {
						 RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDRZA.R = 0;  //Active not tied to a Zone
					 }
					cidx0++;
# else
    #ifdef OVL_POINTER_SUPPORTED
                    //Only one handle per group is used
                    gPage_off_group0 = omd_emu_header.Handle[idx].physical - omd_emu_header.Handle[idx].logical;    // Set gPage_off to working page offset
    #endif

# endif
				}
				else if( (uint32 )(&__cal_wp2_start)<=omd_emu_header.Handle[idx].physical  && omd_emu_header.Handle[idx].physical < (uint32 )(&__cal_wp2_end))
				{
# ifdef OVL_HW_SUPPORTED
					RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDLSA.R =  omd_emu_header.Handle[idx].logical;   //Logical Address  (RP)
					RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDPSA.R =  omd_emu_header.Handle[idx].physical;  //Physical address (WP)
					RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDRS.R  = Convert_OMD_Size_to_OMU(omd_emu_header.Handle[idx].size);  //Size

					 if( IsOMD_BitSet(omd_emu_header.Activate_EMU_Handles, idx) )

					 {
						 RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDRZA.R = 7;  //Active not tied to a Zone
						 active_handles_present1=1;
					 }
					 else
					 {
						 RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDRZA.R = 0;  //Active not tied to a Zone
					 }
					 cidx1++;
# else
    #ifdef OVL_POINTER_SUPPORTED
                    //Only one handle per group is used
                    gPage_off_group1 = omd_emu_header.Handle[idx].physical - omd_emu_header.Handle[idx].logical;    // Set gPage_off to working page offset
    #endif
# endif
				}
			}
		}
    	/* Need to look to see which should be enabled, At least one handle has to be active */
		RTU0__OMU.OER.R= active_handles_present0;
		RTU1__OMU.OER.R= active_handles_present1;
# endif
    }

}


/* Returns 1 if no calibration handles is active. This means the ECU is in RP mode.*/
uint8 Check_Calibration_Handles_in_RP_mode(void)
{
    uint8 rtn_value=1;  //In RP unless we have an active way of changing pages
#if defined(OVL_HW_SUPPORTED)
        rtn_value = (RTU0__OMU.OER.B.OE==1 || RTU1__OMU.OER.B.OE==1 );
#elif defined(OVL_POINTER_SUPPORTED)
    {
        rtn_value = ((gPage_off_group0 == 0)&&(gPage_off_group1 == 0)&&(gPage_off_group2 == 0));
    }
#else
  //No calibration supported or single page mode RP==WP
#endif

  return rtn_value;
}

/*
@function: Common_Update_OvlHandleReg()
@purpose: it sets uC registers for modified handles or all of them depending on function arguments
@input:
    @OMD_table_Ptr: pointer for OMD Table
    @updateAll:
        0: update only modified handles
        1: update all handles
@return: none
*/
void Common_Update_OvlHandleReg(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr, uint8 updateAll)
{
	//struct _omd_emu_header omd_emu_header;

	//union OMD_TABLE_V1_V2 *union_omd=(union OMD_TABLE_V1_V2 *)(&OMD_table_Ptr->CID);
	struct _omd_emu_header omd_emu_header=SetOMD2_HeaderStruct(OMD_table_Ptr);

#ifdef OMD_CID_VERSION_1
    if (OMD_CID_VERSION_1 == OMD_table_Ptr->CID ) // CID version 1 detected - static calibration handles
    {
        if( omd_emu_header.Activate_EMU_Handles[0])
		{
# ifdef OVL_HW_SUPPORTED
			RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDLSA.R =  omd_emu_header.Handle[0].logical;   //Logical Address  (RP)
			RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDPSA.R =  omd_emu_header.Handle[0].physical;  //Physical address (WP)
			RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDRS.R  = Convert_OMD_Size_to_OMU(omd_emu_header.Handle[0].size);  //Size
			RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[0].ORDRZA.R = 7;  //Active not tied to a Zone
# elif defined(OVL_POINTER_SUPPORTED)
            //Only one handle is used no calibration mechanism is supported yet
            gPage_off_group0 = omd_emu_header.Handle[0].physical - omd_emu_header.Handle[0].logical;    // Set gPage_off to working page offset
# else
    //No calibration page switching supported "Single calibration page" e.g RP==WP

# endif
        }
    }
#if defined(OMD_CID_VERSION_1)&&defined(OMD_CID_VERSION_2)
    else
#endif
#ifdef OMD_CID_VERSION_2
    if (OMD_CID_VERSION_2 == OMD_table_Ptr->CID ) // CID version 2 detected - 1x GERAM + 3x CERAM
    {

		uint32 idx;
		uint8 active_handles_present0=0,  active_handles_present1=0;
# ifdef OVL_HW_SUPPORTED
    	uint32 cidx0=0, cidx1=0;
#endif

		for(idx=0; idx<OMD_table_Ptr->EMU_Handles_Number; idx++)
		{
			if( 0<omd_emu_header.Handle[idx].size)
			{

	            uint32 FlagModifyEMUHandle = IsOMD_BitSet(omd_emu_header.Modify_EMU_Handles, idx); // For Modify bits, th

                if(FlagModifyEMUHandle || (updateAll == UpdateAll))
				{
					if( (uint32 )(&__cal_wp_start)<=omd_emu_header.Handle[idx].physical  && omd_emu_header.Handle[idx].physical < (uint32 )(&__cal_wp_end))
					{
# ifdef OVL_HW_SUPPORTED
						RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDLSA.R =  omd_emu_header.Handle[idx].logical;   //Logical Address  (RP)
						RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDPSA.R =  omd_emu_header.Handle[idx].physical;  //Physical address (WP)
						RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDRS.R  = Convert_OMD_Size_to_OMU(omd_emu_header.Handle[idx].size);  //Size

						 if( IsOMD_BitSet(omd_emu_header.Activate_EMU_Handles, idx) )
						 {
							 RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDRZA.R = 7;  //Active not tied to a Zone
							 active_handles_present0=1;
						 }
						 else
						 {
							 RTU0__OMU.OVERLAY_REGION_DESCRIPTOR[cidx0].ORDRZA.R = 0;  //Active not tied to a Zone
						 }
						cidx0++;
# else
    #ifdef OVL_POINTER_SUPPORTED
                        //Only one handle per group is used
                        gPage_off_group0 = omd_emu_header.Handle[idx].physical - omd_emu_header.Handle[idx].logical;    // Set gPage_off to working page offset
    #endif
# endif
					}
					else if( (uint32 )(&__cal_wp2_start)<=omd_emu_header.Handle[idx].physical  && omd_emu_header.Handle[idx].physical < (uint32 )(&__cal_wp2_end))
					{
# ifdef OVL_HW_SUPPORTED
						RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDLSA.R =  omd_emu_header.Handle[idx].logical;   //Logical Address  (RP)
						RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDPSA.R =  omd_emu_header.Handle[idx].physical;  //Physical address (WP)
						RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDRS.R  = Convert_OMD_Size_to_OMU(omd_emu_header.Handle[idx].size);  //Size

						 if( IsOMD_BitSet(omd_emu_header.Activate_EMU_Handles, idx) )

						 {
							 RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDRZA.R = 7;  //Active not tied to a Zone
							 active_handles_present1=1;
						 }
						 else
						 {
							 RTU1__OMU.OVERLAY_REGION_DESCRIPTOR[cidx1].ORDRZA.R = 0;  //Active not tied to a Zone
						 }
						 cidx1++;
# else
    #ifdef OVL_POINTER_SUPPORTED
                        //Only one handle per group is used
                        gPage_off_group1 = omd_emu_header.Handle[idx].physical - omd_emu_header.Handle[idx].logical;    // Set gPage_off to working page offset
    #endif
# endif
					}
                }
			}
		}
    	/* Need to look to see which should be enabled, At least one handle has to be active */
		RTU0__OMU.OER.R= active_handles_present0;
		RTU1__OMU.OER.R= active_handles_present1;
# elif defined(OVL_POINTER_SUPPORTED)

        //Only one handle is used no calibration mechanism is supported yet
        gPage_off_group0 = omd_emu_header.Handle[0].physical - omd_emu_header.Handle[0].logical;    // Set gPage_off to working page offset
# else
    //No calibration page switching supported "Single calibration page" e.g RP==WP
# endif
    }
#endif //OMD_CID_VERSION_2

}

#ifdef CHECK_EXPECTED_HANDLE
#ifdef USE_VOLATILE_DEF
 uint8 Check_IsExpectedHandle(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr)
#else
 uint8 Check_IsExpectedHandle( struct OMD_TABLE* OMD_table_Ptr)
#endif
{
#if OMDV2_MAX_CALIB_HANDLES_NUMBER<=32
    volatile struct OMD_TABLE_V2_32* OMD = (struct OMD_TABLE_V2_32*) OMD_table_Ptr;
#else
#error Invalid OMDV2_MAX_CALIB_HANDLES_NUMBER definition
#endif

    //Can have more than one handle so add them up


    if ((OMD->Handle[0].physical == (WP_ADDR)) && (OMD->Handle[0].logical == (RP_ADDR)) && ( CAL_PAGE_SIZE == OMD->Handle[0].size))
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_4("Handles on OMD are the expected ones !\r\n");
#endif
        return 1;
    }
    else
    {
        Page_Switch_Mailbox.Error_Code = OMD_ERR_EXPHANDLE; // "Handles on OMD table are not the expected ones by code/build"

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ERROR: Handles on OMD table are not the expected ones by code/build !\r\n");
        RS232_TxString("Physical = ");
        RS232_TxHexLong(OMD->Handle[0].physical);
        RS232_TxString(" \r\n");
        RS232_TxString("Logical = ");
        RS232_TxHexLong(OMD->Handle[0].logical);
        RS232_TxString(" \r\n");
        RS232_TxString("Size = ");
        RS232_TxHexLong(OMD->Handle[0].size);
        RS232_TxString(" \r\n");
#endif
    }
    return 0;
}
#endif //#ifdef CHECK_EXPECTED_HANDLE
