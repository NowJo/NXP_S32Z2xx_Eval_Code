/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */


#include "global.h"
#include "ETK_Integration_cfg.h"
#ifdef D13_SUPPORT
#include "Distab13_Fct.h"
#endif
#ifdef BYPASS_SUPPORT

#include "Distab17_Processes.h"
#include "ETK_Bypass_Fkt.h"


#ifdef ASCET_PROJ
#include "base.h"
#else
#include "../target_specific.h"
#include "../base.h"
#endif

#if (defined CPUTYPE_rh850_E1x_FCC1) || (defined CPUCLASS_RH850_E2X) || (defined CPUCLASS_RH850_U2X) || (defined CPUCLASS_RH850_P1x)

    // Bits for all Raster only one class with diferent implementations
#if ( NUMBER_BYPASS_RASTER >= 1)
uint8  getBPVal_bit_B01(uint8 eben, uint8 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = BYPASS_B01.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B01.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
    {
        return 0x01;
    }
    else
    {
        return 0x00;
    }
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 1)

#if ( NUMBER_BYPASS_RASTER >= 2)
uint8  getBPVal_bit_B02(uint8 eben, uint8 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = BYPASS_B02.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B02.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
    {
        return 0x01;
    }
    else
    {
        return 0x00;
    }
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 2)

#if ( NUMBER_BYPASS_RASTER >= 3)
uint8  getBPVal_bit_B03(uint8 eben, uint8 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = BYPASS_B03.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B03.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
    {
        return 0x01;
    }
    else
    {
        return 0x00;
    }
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 3)

#if ( NUMBER_BYPASS_RASTER >= 4)
uint8  getBPVal_bit_B04(uint8 eben, uint8 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = BYPASS_B04.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B04.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
    {
        return 0x01;
    }
    else
    {
        return 0x00;
    }
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 4)


// -----------------------------------------------------------------------------
// extern Funktion Definitions and defines for Bypass Raster B01
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 1)

uint8 getBypDstbActive_B01(void)
{
    return (DISTAB_B01.Header.activ);
}

uint8 getBypCounter_B01(void)
{
    return (BYPASS_B01.Header.counter);
}

uint8 getBPVal_uint8_B01(uint8 eben, uint8 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = BYPASS_B01.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B01.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B01(uint8 eben, uint8 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B01(uint8 eben, uint8 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

sint8  getBPVal_sint8_B01(uint8 eben, uint8 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B01(uint8 eben, uint8 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B01(uint8 eben, uint8 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B01(uint8 eben, uint8 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B01(uint8 eben, uint8 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 1)

// extern Funktion Definitions and defines for Bypass Raster B02
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 2)

uint8 getBypDstbActive_B02(void)
{
    return (DISTAB_B02.Header.activ);
}

uint8 getBypCounter_B02(void)
{
    return (BYPASS_B02.Header.counter);
}

uint8 getBPVal_uint8_B02(uint8 eben, uint8 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = BYPASS_B02.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B02.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B02(uint8 eben, uint8 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B02(uint8 eben, uint8 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

sint8  getBPVal_sint8_B02(uint8 eben, uint8 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B02(uint8 eben, uint8 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B02(uint8 eben, uint8 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B02(uint8 eben, uint8 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B02(uint8 eben, uint8 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 2)

// extern Funktion Definitions and defines for Bypass Raster B03
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 3)

uint8 getBypDstbActive_B03(void)
{
    return (DISTAB_B03.Header.activ);
}

uint8 getBypCounter_B03(void)
{
    return (BYPASS_B03.Header.counter);
}

uint8 getBPVal_uint8_B03(uint8 eben, uint8 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = BYPASS_B03.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B03.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B03(uint8 eben, uint8 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B03(uint8 eben, uint8 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}
sint8  getBPVal_sint8_B03(uint8 eben, uint8 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B03(uint8 eben, uint8 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B03(uint8 eben, uint8 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B03(uint8 eben, uint8 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B03(uint8 eben, uint8 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 3)

// extern Funktion Definitions and defines for Bypass Raster B04
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 4)

uint8 getBypDstbActive_B04(void)
{
    return (DISTAB_B04.Header.activ);
}

uint8 getBypCounter_B04(void)
{
    return (BYPASS_B04.Header.counter);
}

uint8 getBPVal_uint8_B04(uint8 eben, uint8 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = BYPASS_B04.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B04.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B04(uint8 eben, uint8 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B04(uint8 eben, uint8 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}
sint8  getBPVal_sint8_B04(uint8 eben, uint8 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B04(uint8 eben, uint8 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B04(uint8 eben, uint8 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B04(uint8 eben, uint8 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B04(uint8 eben, uint8 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 4)


#else /* For BGA 2nd CUT */


    // Bits for all Raster only one class with different implementations
#if ( NUMBER_BYPASS_RASTER >= 1)
uint8 getBPVal_bit_B01(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_Bit(111, eben, eboff, ECU_Val, Bitoffset);
    }
    else
    {
        getBPVal_bit_B01_alt(eben, eboff, ECU_Val, Bitoffset);
    }
}

uint8  getBPVal_bit_B01_alt(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = BYPASS_B01.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B01.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
        return 0x01;
    else
        return 0x00;
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 1)

#if ( NUMBER_BYPASS_RASTER >= 2)
uint8 getBPVal_bit_B02(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_Bit(112, eben, eboff, ECU_Val, Bitoffset);
    }
    else
    {
        getBPVal_bit_B02_alt(eben, eboff, ECU_Val, Bitoffset);
    }
}

uint8  getBPVal_bit_B02_alt(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = BYPASS_B02.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B02.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
        return 0x01;
    else
        return 0x00;
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 2)

#if ( NUMBER_BYPASS_RASTER >= 3)
uint8 getBPVal_bit_B03(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_Bit(113, eben, eboff, ECU_Val, Bitoffset);
    }
    else
    {
        getBPVal_bit_B03_alt(eben, eboff, ECU_Val, Bitoffset);
    }
}

uint8  getBPVal_bit_B03_alt(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = BYPASS_B03.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B03.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
        return 0x01;
    else
        return 0x00;
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 3)

#if ( NUMBER_BYPASS_RASTER >= 4)
uint8 getBPVal_bit_B04(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_Bit(114, eben, eboff, ECU_Val, Bitoffset);
    }
    else
    {
        getBPVal_bit_B04_alt(eben, eboff, ECU_Val, Bitoffset);
    }
}

uint8  getBPVal_bit_B04_alt(uint8 eben, uint16 eboff, uint8 ECU_Val, uint8 Bitoffset)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8) || Bitoffset > 7)
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = BYPASS_B04.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B04.receive_tabelle2[eboff];
    }
    if (result & (0x01 << Bitoffset))
        return 0x01;
    else
        return 0x00;
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 4)


// -----------------------------------------------------------------------------
// extern Funktion Definitions and defines for Bypass Raster B01
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 1)

  /** Returns 0 if no bypass is currently running.
  Returns 1 if detects bypass using Distab 13 mode.
  Returns 2 if detects bypass using Distab 17 mode.*/
uint8 getBypDstbActive_B01(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(111);

    if (datTab)
    {
        return 0x2; // D17 Bypass is active if the pointer to DatTabToECUPre is set and the SP is activated
    }
    else
    {
        return (DISTAB_B01.Header.activ);
    }
}

uint8 getBypCounter_B01(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(111);

    if (datTab)
    {
        return datTab->BypCtr;
    }
    else
    {
        return (BYPASS_B01.Header.counter);
    }
}

uint8 getBPVal_uint8_B01(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_uint8(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint8_B01_alt(eben, eboff, ECU_Val);
    }
}

uint8 getBPVal_uint8_B01_alt(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = BYPASS_B01.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B01.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B01(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_uint16(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint16_B01_alt(eben, eboff, ECU_Val);
    }
}

uint16 getBPVal_uint16_B01_alt(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B01(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_uint32(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint32_B01_alt(eben, eboff, ECU_Val);
    }
}

uint32 getBPVal_uint32_B01_alt(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

sint8 getBPVal_sint8_B01(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_sint8(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint8_B01_alt(eben, eboff, ECU_Val);
    }
}

sint8  getBPVal_sint8_B01_alt(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B01(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_sint16(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint16_B01_alt(eben, eboff, ECU_Val);
    }
}

sint16 getBPVal_sint16_B01_alt(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B01(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_sint32(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint32_B01_alt(eben, eboff, ECU_Val);
    }
}

sint32 getBPVal_sint32_B01_alt(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B01(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_real32(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real32_B01_alt(eben, eboff, ECU_Val);
    }
}

real32 getBPVal_real32_B01_alt(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B01(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(111))
    {
        Distab17_Get_Bypass_Value_real64(111, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real64_B01_alt(eben, eboff, ECU_Val);
    }
}

real64 getBPVal_real64_B01_alt(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B01 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B01.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B01.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B01.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 1)

// extern Funktion Definitions and defines for Bypass Raster B02
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 2)

  /** Returns 0 if no bypass is currently running.
  Returns 1 if detects bypass using Distab 13 mode.
  Returns 2 if detects bypass using Distab 17 mode.*/
uint8 getBypDstbActive_B02(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(112);

    if (datTab)
    {
        return 0x2; // D17 Bypass is active if the pointer to DatTabToECUPre is set and the SP is activated
    }
    else
    {
        return (DISTAB_B02.Header.activ);
    }
}

uint8 getBypCounter_B02(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(112);

    if (datTab)
    {
        return datTab->BypCtr;
    }
    else
    {
        return (BYPASS_B02.Header.counter);
    }
}

uint8 getBPVal_uint8_B02(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_uint8(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint8_B02_alt(eben, eboff, ECU_Val);
    }
}

uint8 getBPVal_uint8_B02_alt(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = BYPASS_B02.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B02.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B02(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_uint16(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint16_B02_alt(eben, eboff, ECU_Val);
    }
}

uint16 getBPVal_uint16_B02_alt(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B02(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_uint32(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint32_B02_alt(eben, eboff, ECU_Val);
    }
}

uint32 getBPVal_uint32_B02_alt(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

sint8 getBPVal_sint8_B02(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_sint8(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint8_B02_alt(eben, eboff, ECU_Val);
    }
}

sint8  getBPVal_sint8_B02_alt(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B02(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_sint16(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint16_B02_alt(eben, eboff, ECU_Val);
    }
}

sint16 getBPVal_sint16_B02_alt(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B02(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_sint32(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint32_B02_alt(eben, eboff, ECU_Val);
    }
}

sint32 getBPVal_sint32_B02_alt(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B02(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_real32(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real32_B02_alt(eben, eboff, ECU_Val);
    }
}

real32 getBPVal_real32_B02_alt(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B02(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(112))
    {
        Distab17_Get_Bypass_Value_real64(112, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real64_B02_alt(eben, eboff, ECU_Val);
    }
}

real64 getBPVal_real64_B02_alt(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B02 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B02.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B02.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B02.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 2)

// extern Funktion Definitions and defines for Bypass Raster B03
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 3)

  /** Returns 0 if no bypass is currently running.
  Returns 1 if detects bypass using Distab 13 mode.
  Returns 2 if detects bypass using Distab 17 mode.*/
uint8 getBypDstbActive_B03(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(113);

    if (datTab)
    {
        return 0x2; // D17 Bypass is active if the pointer to DatTabToECUPre is set and the SP is activated
    }
    else
    {
        return (DISTAB_B03.Header.activ);
    }
}

uint8 getBypCounter_B03(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(113);

    if (datTab)
    {
        return datTab->BypCtr;
    }
    else
    {
        return (BYPASS_B03.Header.counter);
    }
}

uint8 getBPVal_uint8_B03(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_uint8(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint8_B03_alt(eben, eboff, ECU_Val);
    }
}

uint8 getBPVal_uint8_B03_alt(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = BYPASS_B03.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B03.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B03(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_uint16(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint16_B03_alt(eben, eboff, ECU_Val);
    }
}

uint16 getBPVal_uint16_B03_alt(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B03(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_uint32(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint32_B03_alt(eben, eboff, ECU_Val);
    }
}

uint32 getBPVal_uint32_B03_alt(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

sint8 getBPVal_sint8_B03(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_sint8(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint8_B03_alt(eben, eboff, ECU_Val);
    }
}

sint8  getBPVal_sint8_B03_alt(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B03(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_sint16(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint16_B03_alt(eben, eboff, ECU_Val);
    }
}

sint16 getBPVal_sint16_B03_alt(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B03(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_sint32(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint32_B03_alt(eben, eboff, ECU_Val);
    }
}

sint32 getBPVal_sint32_B03_alt(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B03(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_real32(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real32_B03_alt(eben, eboff, ECU_Val);
    }
}

real32 getBPVal_real32_B03_alt(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B03(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(113))
    {
        Distab17_Get_Bypass_Value_real64(113, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real64_B03_alt(eben, eboff, ECU_Val);
    }
}

real64 getBPVal_real64_B03_alt(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B03 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B03.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B03.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B03.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 3)

// extern Funktion Definitions and defines for Bypass Raster B04
// All Values without bits !

#if ( NUMBER_BYPASS_RASTER >= 4)

  /** Returns 0 if no bypass is currently running.
  Returns 1 if detects bypass using Distab 13 mode.
  Returns 2 if detects bypass using Distab 17 mode.*/
uint8 getBypDstbActive_B04(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(114);

    if (datTab)
    {
        return 0x2; // D17 Bypass is active if the pointer to DatTabToECUPre is set and the SP is activated
    }
    else
    {
        return (DISTAB_B04.Header.activ);
    }
}

uint8 getBypCounter_B04(void)
{
    tD17BypassReverseData* datTab = Distab17_IsServicePointActiveAndConfiguredForHBB(114);

    if (datTab)
    {
        return datTab->BypCtr;
    }
    else
    {
        return (BYPASS_B04.Header.counter);
    }
}

uint8 getBPVal_uint8_B04(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_uint8(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint8_B04_alt(eben, eboff, ECU_Val);
    }
}

uint8 getBPVal_uint8_B04_alt(uint8 eben, uint16 eboff, uint8 ECU_Val)
{
    uint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = BYPASS_B04.receive_tabelle1[eboff];
    }
    else
    {
        result = BYPASS_B04.receive_tabelle2[eboff];
    }
    return(result);
}

uint16 getBPVal_uint16_B04(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_uint16(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint16_B04_alt(eben, eboff, ECU_Val);
    }
}

uint16 getBPVal_uint16_B04_alt(uint8 eben, uint16 eboff, uint16 ECU_Val)
{
    uint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((uint16*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint16*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

uint32 getBPVal_uint32_B04(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_uint32(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_uint32_B04_alt(eben, eboff, ECU_Val);
    }
}

uint32 getBPVal_uint32_B04_alt(uint8 eben, uint16 eboff, uint32 ECU_Val)
{
    uint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((uint32*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((uint32*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

sint8 getBPVal_sint8_B04(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_sint8(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint8_B04_alt(eben, eboff, ECU_Val);
    }
}

sint8  getBPVal_sint8_B04_alt(uint8 eben, uint16 eboff, sint8 ECU_Val)
{
    sint8 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((sint8*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint8*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

sint16 getBPVal_sint16_B04(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_sint16(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint16_B04_alt(eben, eboff, ECU_Val);
    }
}

sint16 getBPVal_sint16_B04_alt(uint8 eben, uint16 eboff, sint16 ECU_Val)
{
    sint16 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((sint16*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint16*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

sint32 getBPVal_sint32_B04(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_sint32(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_sint32_B04_alt(eben, eboff, ECU_Val);
    }
}

sint32 getBPVal_sint32_B04_alt(uint8 eben, uint16 eboff, sint32 ECU_Val)
{
    sint32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((sint32*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((sint32*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

real32 getBPVal_real32_B04(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_real32(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real32_B04_alt(eben, eboff, ECU_Val);
    }
}

real32 getBPVal_real32_B04_alt(uint8 eben, uint16 eboff, real32 ECU_Val)
{
    real32 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((real32*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real32*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}

real64 getBPVal_real64_B04(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    if (NULL != Distab17_IsServicePointActiveAndConfiguredForHBB(114))
    {
        Distab17_Get_Bypass_Value_real64(114, eben, eboff, ECU_Val);
    }
    else
    {
        getBPVal_real64_B04_alt(eben, eboff, ECU_Val);
    }
}

real64 getBPVal_real64_B04_alt(uint8 eben, uint16 eboff, real64 ECU_Val)
{
    real64 result;
    if (eben == 0 || (eboff < 8) || (eboff >= BYPASS_OUT_MAX_B04 + 8))
    {
        return(ECU_Val);
    }
    eboff -= 8;
    if (BYPASS_B04.Header.counter & 0x01)
    {
        result = *((real64*)&BYPASS_B04.receive_tabelle1[eboff]);
    }
    else
    {
        result = *((real64*)&BYPASS_B04.receive_tabelle2[eboff]);
    }
    return(result);
}
#endif // #if ( NUMBER_BYPASS_RASTER >= 4)

#endif /* End FCC1_BGA2ndCut definition */

#endif // #ifndef _ETK_BYPASS_FKT_C
