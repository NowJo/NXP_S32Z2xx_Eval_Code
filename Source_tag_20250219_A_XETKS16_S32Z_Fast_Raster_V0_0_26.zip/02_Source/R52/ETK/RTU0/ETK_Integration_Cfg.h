/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
/*
################################################################################
#                                                                              #
#    RH850 / (X)ETKS22                           |   ETAS GmbH                 #
#    Generic Version                             |   Stuttgart Feuerbach       #
#    For Demonstration Purpose Only              |   All rights reserved       #
#                                                |   Alle Rechte vorbehalten   #
#                                                                              #
#    File: ETK_Integration_Cfg.h                                               #
#                                                                              #
#                                                                              #
################################################################################
*/

#ifndef _ETK_INTEGRATION_CFG_H
#define _ETK_INTEGRATION_CFG_H

#include "global.h"
#include "base.h"


#ifdef ASCET_PROJ
#include "target_specific.h"
#else
//#include "a_etas_type.h"
#include "target_specific.h"
#endif

#include "ETK_Common.h"

extern void Disable_Interrupts(void);
extern void Enable_Interrupts(void);

/* ---------------------------------------------------------------------------- */
/* Use USE_VOLATILE_DEF if compiler can handle volatile const declarations!     */
/* Use VOLATILE_DEF to define the volatile keyword                              */
/* ---------------------------------------------------------------------------- */
//#define USE_VOLATILE_DEF  would be declared in a target specific file
    // Enable when FAR_DEF define shall be used
    // -> Disable if not needed or compiler does not support
    // empty define declaration
#ifndef VOLATILE_DEF
#define VOLATILE_DEF  volatile
#endif
#ifndef CONST_DEF
#define CONST_DEF const
#endif
#ifndef CAL_DEF
#define CAL_DEF CONST_DEF VOLATILE_DEF
#endif

/* ---------------------------------------------------------------------------- */
/* Use USE_DISTAB_CONST_DEF if Distab is in ETK Data Area and not in RAM        */
/* (Serial ETK / Parallel ETK with RAM extension)                               */
/* ---------------------------------------------------------------------------- */
// #define USE_DISTAB_CONST_DEF // Enable when DISTAB_CONST_DEF define shall be used
// -> Disable if not needed or compiler does not support
// empty define declaration
#ifndef DISTAB_CONST_DEF
#define DISTAB_CONST_DEF  CONST_DEF
#endif
/* -------------------------------------------------------------------------- */
/* Project Debug specific Settings                                            */
/* -------------------------------------------------------------------------- */
#define USE_IO

#ifdef USE_IO
/** It is possible to remove all the RS232 messages from the project by commenting this define.
If the RS232 Debug message define is set different informations will be displayed during the program runtime through the ASCLIN0 output.
The RS232 baud rate is set to 115200 bps 8 bit, no parity, 1 stop bit by default.
The Debug Level can then be set with a terminal by writing the desired debug level value.
The standard debug level is 1 by default, but it can be set between 0 and 4.
At the level 4 the page switching function may produce an error with INCA as it slows greatly down the function execution speed.
This can be prevented by increasing the timeout time defined in the A2L for the PAGE_SWITCH_METHOD. */
#define RS232_DEBUG_LOGGING

/** It is possible to set the Debug Level between 1 and 4. 1 is the default setting displaying the minimum amount of debugging information through the RS232 port.
The value can be set to 3 to display more debug messages during the debugging phase or to 4 to force the display of all available debug information.
Setting the display level to a higher value will cause more latency and slow down the program. */
#define RS232_DEBUG_LEVEL 4
#endif

/** This will increase the handshake wait time to 1 second during the ECU startup for debugging purposes
and will delay the initial activation of the tasks.*/
//#define ETK_HANDSHAKE_DEBUG_WAIT_SECOND

#ifdef ETK_HANDSHAKE_DEBUG_WAIT_SECOND
#define HANDSHAKE_WAIT_TIME_ms 1000 // 1 second with 40MHz timer
#else
#define HANDSHAKE_WAIT_TIME_ms 50
#endif

/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* Compiler specific Settings                                                   */
/* ---------------------------------------------------------------------------- */
/* Distab 17 table linking specific pragmas defined the Green Hills compiler. (Needed for the event list, config area, output area) */
//#define GHS_COMPILER

/* Distab 17 table linking specific pragmas defined the WindRiver compiler. (Needed for the event list, config area, output area) */
//#define WINDRIVER_COMPILER

#ifdef GHS_COMPILER
  /* Optimizes the Distab 17 code for the Green Hills compiler a bit.*/
#define DISTAB_LONGWORD_OPTIMIZATION
#endif

/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* CPU specific Settings                                                        */
/* ---------------------------------------------------------------------------- */
// Distinguish between Motorola / Intel Type Memory Usage
//#define PROCESSOR_MEM_TYPE_BIG_ENDIAN  // Motorola Type Memory Usage
#define PROCESSOR_MEM_TYPE_LITTLE_ENDIAN     // Intel Type Memory Usage



//#define AUD_Test
#ifdef AUD_Test
#define AUDMBR *(volatile unsigned long   *) (0xF9015004L) /* Debug Trigger Register 1 for RH850 E2x */
#endif
#if (defined CPUCLASS_RH850_U2X)
#define SW_RESETOUT
#define PULLUP_RESETOUT_PIN() {\
                                  P0_PKCPROT = 0xA5A5A501;\
                                  P0_PWE |= (1 << 7);\
                                  P0_P6 |= (1 << 10);\
                                  P0_PKCPROT = 0xA5A5A500;\
                              }
#endif

/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* Coldstart Settings                                                           */
/* ---------------------------------------------------------------------------- */
/** Adds more variables in order to measure the coldstart execution times.
This is a debug feature which is not needed for the core coldstart functionality.*/
#define COLDSTART_EXECUTION_TIME

/** Saves the initial coldstart pattern before the coldstart execution and after for debugging purposes. */
#define COLDSTART_DEBUG_PATTERN

/** \def CODECHECK_SUPPORT
To enable a code check so that the A2L and the running
software to make sure they are compatable.
*/
#define CODECHECK_SUPPORT

/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* Calibration Wake Up Settings                                                 */
/* ---------------------------------------------------------------------------- */
#ifdef ASCET_PROJ
#define HW_CALWAKEUP_USE
#define SLEEP_PIN 0
#define KL15_PIN 1
#define CALWAKEUP_PIN 2
#define RESET_MODE_PIN 9
#endif

/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* Handshake Settings                                                           */
/* ---------------------------------------------------------------------------- */
#define HANDSHAKE_EXECUTION_TIME

#ifdef ASCET_PROJ
#define HS_DISABLE_SWITCH
#define HS_DISABLE_PIN 8
#endif

/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* Calibration Settings                                                         */
/* ---------------------------------------------------------------------------- */
/** Define Used Overlay Memory Layout Descriptor - OMD
By removing this define it is possible to compile the project without any page switching support. */
#define OMD_SUPPORT // OMD table based page switching for the RH850 ÂµC family

#ifdef OMD_SUPPORT
/* If this define is set the code will check if the advanced code check pattern for WP in the EMU ram was written by the ETK before doing a page switch.
  When set the following PAGESWITCH_DEPENDING_ON_CODECHECK macro value will be used to define if this verification can block or not a page switching. */
#define CODECHECK_WP_BEFORE_PAGESWITCH

  /* The implemented version of the OMD table. - Compatible extensions for an existing CID. */
#define IMPLEMENTED_OMD_VERSION 0

//#define OVL_POINTER_SUPPORTED //Pointer overlay approach is used which means no real ECU registers present for overlay memory
#define OVL_HW_SUPPORTED      //Registers are used to enable RAM overlay approach

#if defined(OVL_POINTER_SUPPORTED)&&defined(OVL_HW_SUPPORTED)
#error Only one calibration page switch supported
#endif

#if (defined CPUCLASS_RH850_E2X || defined CPUCLASS_RH850_U2X)
 /* Configuration for OMDv1 mode */
#define NUMBER_CERAM_CALIB_SUBBLOCKS 32 //Not actually used for OMDv1
#define NUMBER_GERAM_CALIB_HANDLES 32
//32 GERAM handles for OMDv1 mode
#define NUMBER_OMD_MAX_CALIB_HANDLES 32
// The size of a calibration handle is 32kB (0x8000) for OMDv1 mode
#define CALIB_HANDLE_SIZE 0x8000

#if (defined CPUTYPE_RH850_E2x_FCC1)
   /* Configuration for OMDv2 dynamic mode for E2xFCC1 */
#define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 32
#define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 64
#endif // !#idef CPUTYPE_RH850_E2x_FCC1

#if (defined CPUTYPE_RH850_E2x_FCC2)
    /* Configuration for OMDv2 dynamic mode for E2xFCC2 */
#define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 96
#define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 128
#endif // !#ifdef CPUTYPE_RH850_E2x_FCC2

#if (defined CPUTYPE_RH850_U2A_EVA)
#define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 64
#define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 96
#endif // !#idef CPUTYPE_RH850_E2x_FCC2

#if (defined CPUTYPE_RH850_U2B_EVA)
#define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 96
#define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 128  //3 clusters (32 each) + 1 global (32) = 128
#endif // !#idef CPUTYPE_RH850_U2B_EVA


#if (defined CPUTYPE_RH850_E2x_PD)
   /* Configuration for OMDv2 dynamic mode for E2xFCC1 */
#define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 32
#define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 32
#endif // !#idef CPUTYPE_RH850_E2x_PD

#elif (defined CPUCLASS_RH850_P1x)
/* Configuration for OMDv1 mode */
#define NUMBER_CERAM_CALIB_SUBBLOCKS 32 //Not actually used for OMDv1
#define NUMBER_GERAM_CALIB_HANDLES 0
//32 GERAM handles for OMDv1 mode
#define NUMBER_OMD_MAX_CALIB_HANDLES 32
// The size of a calibration handle is 32kB (0x8000) for OMDv1 mode
#define CALIB_HANDLE_SIZE 0x8000
    #define CALIB_HANDLE_OFFSET 0X20000
    #define CALIB_HANDLE_BASE_ADDR 0xF9800000

/* Configuration for OMDv2 dynamic mode for P1xC */
#define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 64
#define OMDV2_NUMBER_GERAM_CALIB_HANDLES 0
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 64

#elif (defined CPUCLASS_RH850_P1M)
//ToDo: DSM how to properly handle the 8kb emulation RAM case where there is only one handle!
    /* Configuration for OMDv1 mode */
    #define NUMBER_CERAM_CALIB_SUBBLOCKS 4 //Not actually used for OMDv1
    #define NUMBER_GERAM_CALIB_HANDLES 0
    //32 GERAM handles for OMDv1 mode
    #define NUMBER_OMD_MAX_CALIB_HANDLES 4
    // The size of a calibration handle is 8kB (0x2000) for OMDv1 mode
    #define CALIB_HANDLE_SIZE 0x2000
    #define CALIB_HANDLE_OFFSET 0x20000
    #define CALIB_HANDLE_BASE_ADDR 0xF9800000

    /* Configuration for OMDv2 dynamic mode for P1M */
    #define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 4
    #define OMDV2_NUMBER_GERAM_CALIB_HANDLES 0
    #define OMDV2_MAX_CALIB_HANDLES_NUMBER 4

#elif (defined CPUCLASS_RH850_F1K)
    #define NUMBER_OMD_MAX_CALIB_HANDLES 32   /* OMDV1 should not be used with this chip, this values is here to make the code happy */
    #define OMDV2_MAX_CALIB_HANDLES_NUMBER 32 /* It's actually None, but we have to make the code happy */

#elif defined CPUCLASS_ARM
#if (defined CPUTYPE_ARM_S32Z)||(defined CPUTYPE_ARM_S32E)
#define NUMBER_OMD_MAX_CALIB_HANDLES 1
#define CHECK_EXPECTED_HANDLE
#ifdef OVL_POINTER_SUPPORTED
#define OMDV2_NUMBER_CALIB_HANDLES 1
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 32
#else
#define OMDV2_NUMBER_CALIB_HANDLES 128
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 128
#undef CHECK_EXPECTED_HANDLE
#endif

#elif (defined CPUTYPE_ARM_S32S)
#define NUMBER_OMD_MAX_CALIB_HANDLES 1
#define OMDV2_NUMBER_CALIB_HANDLES 1
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 1
#define CHECK_EXPECTED_HANDLE

#elif (defined CPUTYPE_ARM_S32G)
#define NUMBER_OMD_MAX_CALIB_HANDLES 1
#define OMDV2_NUMBER_CALIB_HANDLES 1
#define OMDV2_MAX_CALIB_HANDLES_NUMBER 1
//#define CHECK_EXPECTED_HANDLE    //    If defined this will perform a check on the OMD table for calibration page
#endif



 //The RP and WP are defined in the linker file
 extern char __cal_rp_start;
 extern char __cal_wp_start;
 extern char __cal_wp_end;
 #define RP_ADDR ((uint32)(&__cal_rp_start)) /* Only used if CHECK_EXPECTED_HANDLE is enabled */
 #define WP_ADDR ((uint32)(&__cal_wp_start)) /* Only used if CHECK_EXPECTED_HANDLE is enabled */

#if !((defined CPUTYPE_ARM_S32Z)||(defined CPUTYPE_ARM_S32E))
 #define CAL_PAGE_SIZE ((uint32)(&__cal_wp_end)-(uint32)(&__cal_wp_start))  /* Only used if CHECK_EXPECTED_HANDLE is enabled */
#else
 //Only S32Z has 2 pages available currently
 extern char __cal_rp2_start;
 extern char __cal_wp2_start;
 extern char __cal_wp2_end;
 #define RP2_ADDR ((uint32)(&__cal_rp2_start)) /* Only used if CHECK_EXPECTED_HANDLE is enabled */
 #define WP2_ADDR ((uint32)(&__cal_wp2_start)) /* Only used if CHECK_EXPECTED_HANDLE is enabled */
 //Add both pages
 #define CAL_PAGE_SIZE ((uint32)(&__cal_wp_end)-(uint32)(&__cal_wp_start)+(uint32)(&__cal_wp2_end)-(uint32)(&__cal_wp2_start)+1)  /* Only used if CHECK_EXPECTED_HANDLE is enabled */
 #endif //!(defined CPUTYPE_ARM_S32Z)
#endif //CHECK_EXPECTED_HANDLE



#if (defined CPUTYPE_RH850_E2x_FCC1)
   /* Configuration for OMDv2 dynamic mode for E2xFCC1 */
    #define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 32
    #define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
    #define OMDV2_MAX_CALIB_HANDLES_NUMBER 64
#elif (defined CPUTYPE_RH850_E2x_FCC2)
    /* Configuration for OMDv2 dynamic mode for E2xFCC2 */
    #define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 96
    #define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
    #define OMDV2_MAX_CALIB_HANDLES_NUMBER 128
#elif (defined CPUTYPE_RH850_U2A_EVA)
    /* Configuration for OMDv2 dynamic mode for U2A_EVA */
    #define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 64
    #define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
    #define OMDV2_MAX_CALIB_HANDLES_NUMBER 96
#elif (defined CPUTYPE_RH850_U2B_EVA)
    #define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 96
    #define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
    #define OMDV2_MAX_CALIB_HANDLES_NUMBER 128  //3 clusters (32 each) + 1 global (32) = 128
#elif (defined CPUTYPE_RH850_E2x_PD)
    /* Configuration for OMDv2 dynamic mode for E2xFCC1 */
    #define OMDV2_NUMBER_CERAM_CALIB_SUBBLOCKS 32
    #define OMDV2_NUMBER_GERAM_CALIB_HANDLES 32
    #define OMDV2_MAX_CALIB_HANDLES_NUMBER 32
#endif // #idef CPUTYPE

#endif // #ifdef OMD_PAGE_SWITCH




/* ---------------------------------------------------------------------------- */

/* ---------------------------------------------------------------------------- */
/* Distab Settings                                                              */
/* ---------------------------------------------------------------------------- */
/* Distab triggering uses a register trigger for a serial (X)ETK. */
#define TRG_SERIAL_ETK

/** Handshake and Trigger on RAM and/or registers
 * NOTE: if both RAM and REG are supported then it will first look for a register
 * HS and if found then the triggers for registers will be enabled
 * ADV_HS_SUPPORTED for RAM based handshake do we use advanced mode
 * ADV_HW_HS_SUPPORTED register based handshake is supported
 * LEGACY_HS_SUPPORTED not used on this program
 * HS_ON_RAM do we want to support the RAM handshake
 * TRG_ON_RAM use ram based triggering
 * TRG_ON_REG use registers to trigger. Has precedence over HS_ON_RAM
 * */
#define ADV_HS_SUPPORTED
#define ADV_HW_HS_SUPPORTED
//#define LEGACY_HS_SUPPORTED
#define HS_ON_RAM
#define TRG_ON_RAM
#define HS_ON_REG
#define TRG_ON_REG

//#define OVERRIDE_HS 0 // Just used during development phase to timeout handshake -> only supported by advanced HS for now

#if ((defined CPUCLASS_RH850_E1X || defined CPUCLASS_RH850_P1x))&&defined(TRG_ON_REG)
#define DBG_STUP *(volatile unsigned long   *) 0xFA002078L  /* Debug Startup Register */
#define DBG_TRG  *(volatile unsigned long   *) 0xFA00207CL  /* Debug Trigger Register for RH850 E1x FCC1 */
#define DBG_MBOUT *(volatile unsigned long  *) 0xFA00206CL  /* Debug Mailbox (CPU->Tool) */
#define DBG_MBIN *(volatile unsigned long   *) 0xFA002070L  /* Debug Mailbox (Tool->CPU) */
#endif

#if ((defined CPUCLASS_RH850_E2X || defined CPUCLASS_RH850_U2X))&&defined(TRG_ON_REG)
#define DBG_Base (0xF9010000L)
#define DBG_STUP  *(volatile unsigned long   *) (DBG_Base+0x00002078L)  /* Debug Startup Register */
#define DBG_MBOUT *(volatile unsigned long   *) (DBG_Base+0x0000206CL) /* Debug Mailbox (CPU->Tool) */
#define DBG_MBIN  *(volatile unsigned long   *) (DBG_Base+0x00002070L) /* Debug Mailbox (Tool->CPU) */

/* DBG_TRGn uses the absolute base address 0xF9010000 (not the self address) because all cores will write to the DBG_TRGn of the core 0 (PE0) */
/* E2x allows all cores to access PE0's registers and write to them. So, XETK only reads up to 8 DBG_TRG's and not 16 (for E2xFCC1) or 48 (for E2xFCC2) */

#define DBG_TRG   *(volatile unsigned long   *) (DBG_Base+0x000022C0L) /* Debug Trigger Register 0 for RH850 E2x - Name is still DBG_TRG for legacy reasons*/
#define DBG_TRG1  *(volatile unsigned long   *) (DBG_Base+0x000022C4L) /* Debug Trigger Register 1 for RH850 E2x */
#define DBG_TRG2  *(volatile unsigned long   *) (DBG_Base+0x000022C8L) /* Debug Trigger Register 2 for RH850 E2x */
#define DBG_TRG3  *(volatile unsigned long   *) (DBG_Base+0x000022CCL) /* Debug Trigger Register 3 for RH850 E2x */
#define DBG_TRG4  *(volatile unsigned long   *) (DBG_Base+0x000022D0L) /* Debug Trigger Register 4 for RH850 E2x */
#define DBG_TRG5  *(volatile unsigned long   *) (DBG_Base+0x000022D4L) /* Debug Trigger Register 5 for RH850 E2x */
#define DBG_TRG6  *(volatile unsigned long   *) (DBG_Base+0x000022D8L) /* Debug Trigger Register 6 for RH850 E2x */
#define DBG_TRG7  *(volatile unsigned long   *) (DBG_Base+0x000022DCL) /* Debug Trigger Register 7 for RH850 E2x */

#elif ((defined CPUCLASS_RH850_F1K || defined CPUCLASS_RH850_P1M))&&defined(TRG_ON_REG)
#define DBG_Base 0xFA000000L
#define DBG_TRG   *(volatile unsigned long   *) (DBG_Base+0x0000207CL) /* Debug Trigger Register 0 for RH850 E2x - Name is still DBG_TRG for legacy reasons*/
#define DBG_STUP  *(volatile unsigned long   *) (DBG_Base+0x00002078L)  /* Debug Startup Register */
#define DBG_MBOUT *(volatile unsigned long   *) (DBG_Base+0x0000206CL) /* Debug Mailbox (CPU->Tool) */
#define DBG_MBIN  *(volatile unsigned long   *) (DBG_Base+0x00002070L) /* Debug Mailbox (Tool->CPU) */

#elif defined(CPUTYPE_ARM_S32Z)||(defined CPUTYPE_ARM_S32E)
 #if defined(TRG_ON_REG)
  #if  defined(ADV_HW_HS_SUPPORTED)
   #define DBG_TRG(a) *(uint32 *)((uint32)(&MDM_XETK_AP.DTS_SEMAPHORE.R)+(a*0x10))     /* Debug Trigger Register */
   #define DBG_TRG_MAX 3                       /* 3 * 32 = 96 Triggers max*/
  #else
   #error Trigger on Register is not possible if handshake is not also active
  #endif
 #endif
 #if defined(ADV_HW_HS_SUPPORTED)
  #define DBG_STUP   MDM_XETK_AP.DTS_STARTUP_D.R     /*This register is used for the startup handshake*/
  #define DBG_MBOUT  MDM_XETK_AP.DTS_SEMAPHORE_D.R   /* Debug Mailbox (CPU->Tool) */
  #define DBG_MBIN   MDM_XETK_AP.DTS_STARTUP_D.R     /* Debug Mailbox (Tool->CPU) */
 #endif
#endif


#ifdef OVL_POINTER_SUPPORTED
// Calibration Macros for pointer approach
#define NUMBER_CAL_GROUP 3
#define SIZE_CAL_GROUP 0x100000
#define CAL_GROUP0_ADDRESS (__cal_rp_start)     /*R52 Cluster0*/
#define CAL_GROUP1_ADDRESS (__cal_rp2_start)    /*R52 Cluster1*/
#define CAL_GROUP2_ADDRESS (__cal_rp3_start)    /*M33*/

/* External variables */

//gPage_off_group# Declared in ETK_SER_Page_Ctrl_Fct.c
extern uint32 gPage_off_group0;
extern uint32 gPage_off_group1;
extern uint32 gPage_off_group2;


static inline uint32 GET_ACTIVE_GROUP_FOR_ADDR(uint32 cal_addr)
{
	uint32 rtn=0;
	if   ((CAL_GROUP0_ADDRESS<=(cal_addr))&&(CAL_GROUP0_ADDRESS+SIZE_CAL_GROUP>=(cal_addr)))
			rtn=gPage_off_group0;
	else if ((CAL_GROUP1_ADDRESS<=(cal_addr))&&(CAL_GROUP1_ADDRESS+SIZE_CAL_GROUP>=(cal_addr)))
			rtn=gPage_off_group1;
	else if ((CAL_GROUP2_ADDRESS<=(cal_addr))&&(CAL_GROUP2_ADDRESS+SIZE_CAL_GROUP>=(cal_addr)))
			rtn=gPage_off_group2;

return rtn;
}
/*The "ACTIVE_PAGE_" is generic and takes a little more processing, use "ACTIVE_PAGE_GRP_"
 *when the group is known ahead of time
 */
#define ACTIVE_PAGE_SINT32(X) *(sint32*) ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))
#define ACTIVE_PAGE_SINT16(X) *(sint16*) ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))
#define ACTIVE_PAGE_SINT8(X)  *(sint8*)  ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))
#define ACTIVE_PAGE_UINT32(X) *(uint32*) ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))
#define ACTIVE_PAGE_UINT16(X) *(uint16*) ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))
#define ACTIVE_PAGE_UINT8(X)  *(uint8*)  ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))
#define ACTIVE_PAGE_FL32(X)   *(real32*) ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))
#define ACTIVE_PAGE_FL64(X)   *(real64*) ( (uint32) &X + GET_ACTIVE_GROUP_FOR_ADDR((uint32)(&(X))))

//This GRP macro has minimal size and logic and should be used where appropriate
#define ACTIVE_PAGE_GRP_SINT32(grp,cal_name) *(sint32*) ( (uint32) &cal_name + gPage_off_group##grp)
#define ACTIVE_PAGE_GRP_SINT16(grp,cal_name) *(sint16*) ( (uint32) &cal_name + gPage_off_group##grp)
#define ACTIVE_PAGE_GRP_SINT8(grp,cal_name)  *(sint8*)  ( (uint32) &cal_name + gPage_off_group##grp)
#define ACTIVE_PAGE_GRP_UINT32(grp,cal_name) *(uint32*) ( (uint32) &cal_name + gPage_off_group##grp)
#define ACTIVE_PAGE_GRP_UINT16(grp,cal_name) *(uint16*) ( (uint32) &cal_name + gPage_off_group##grp)
#define ACTIVE_PAGE_GRP_UINT8(grp,cal_name)  *(uint8*)  ( (uint32) &cal_name + gPage_off_group##grp)
#define ACTIVE_PAGE_GRP_FL32(grp,cal_name)   *(real32*) ( (uint32) &cal_name + gPage_off_group##grp)
#define ACTIVE_PAGE_GRP_FL64(grp,cal_name)   *(real64*) ( (uint32) &cal_name + gPage_off_group##grp)


#else
#define ACTIVE_PAGE_SINT32(cal_name) (cal_name)
#define ACTIVE_PAGE_SINT16(cal_name) (cal_name)
#define ACTIVE_PAGE_SINT8(cal_name)  (cal_name)
#define ACTIVE_PAGE_UINT32(cal_name) (cal_name)
#define ACTIVE_PAGE_UINT16(cal_name) (cal_name)
#define ACTIVE_PAGE_UINT8(cal_name)  (cal_name)
#define ACTIVE_PAGE_FL32(cal_name)   (cal_name)
#define ACTIVE_PAGE_FL64(cal_name)   (cal_name)

#define ACTIVE_PAGE_GRP_SINT32(grp,cal_name) (cal_name)
#define ACTIVE_PAGE_GRP_SINT16(grp,cal_name) (cal_name)
#define ACTIVE_PAGE_GRP_SINT8(grp,cal_name)  (cal_name)
#define ACTIVE_PAGE_GRP_UINT32(grp,cal_name) (cal_name)
#define ACTIVE_PAGE_GRP_UINT16(grp,cal_name) (cal_name)
#define ACTIVE_PAGE_GRP_UINT8(grp,cal_name)  (cal_name)
#define ACTIVE_PAGE_GRP_FL32(grp,cal_name)   (cal_name)
#define ACTIVE_PAGE_GRP_FL64(grp,cal_name)   (cal_name)

#endif //OVL_POINTER_SUPPORTED


//#define OVERRIDE_HS  // Just used during development phase to timeout handshake -> only supported by advanced HS for now
/* Distab 17 support enabled. Mainly needed for the handshake functions. */
#define D17_SUPPORT

#if defined(CPUTYPE_RH850_E2x_FCC1) || defined(CPUTYPE_RH850_E2x_FCC2) || defined(CPUCLASS_RH850_U2X) || defined(CPUTYPE_ARM_S32G) || defined(CPUTYPE_ARM_S32S) || defined(CPUTYPE_ARM_S32Z)|| defined(CPUTYPE_ARM_S32E)
#define TRACE_SUPPORT
#endif

// Supplementary D17
#ifdef TRACE_SUPPORT
#define SUD17_ID_OFFSET 1024
#define SUD17_MAX_TRG 255
#define SUD17_32BIT
#endif


/* Distab 13 support enabled. Mainly needed for the handshake functions. */
//#define D13_SUPPORT

// Number of Distab 13 measurement rasters supported by the project
#ifdef D13_SUPPORT
#define NUMBER_MEASUREMENT_RASTER 3
#else
#define NUMBER_MEASUREMENT_RASTER 0
#endif

#ifdef ASCET_PROJ
#define BYPASS_SUPPORT
#endif

//#define BYPASS_SUPPORT

#ifdef BYPASS_SUPPORT
#define NUMBER_BYPASS_RASTER 4 // Used by D13 Bypass only

#define Bypass_Wait     1000000/125         // ECU waits max 1 ms for the bypass new counter

#define RTT_TEST //RTT variables and calculation will be performed
#define D17_ENABLE_BYPASS_NB_OF_BYTES_STATUS

#define SBB_ED_RAM_INIT_LOC 0xFE048000
#define SBB_ED_RAM_INIT_SIZE 0x8000

#ifdef SBB_ED_RAM_INIT_SIZE
#if (SBB_ED_RAM_INIT_SIZE % 32 != 0)
#error "SBB_ED_RAM_INIT_SIZE must be a multiple of 32 due to a code optimization !"
#endif
#endif
#ifndef ASCET_PROJ
#define NULL ((void *)0)
#endif
#else
#define NUMBER_BYPASS_RASTER 0
#endif


/* ---------------------------------------------------------------------------- */
/* Raster Definition: BYPASS Raster B01                                         */
/* ---------------------------------------------------------------------------- */
#if ( NUMBER_BYPASS_RASTER >= 1)
#define         MAXPTR_B01           0x80
#define         MAXNUM_B01           0x100
#define         BYPASS_OUT_MAX_B01   0x21C

#ifndef TRG_SERIAL_ETK
#define         TRIGGER_B01          TRIGGER_17

#else

#ifdef ETK_HW_HANDSHAKE_DAI
#define         TRIGGER_B01         TRIGGER_DAI_01
#endif

#ifdef ETK_HW_HANDSHAKE_AUD_REG
#define         TRIGGER_B01         TRIGGER_17
#endif
#endif

#define         TRIGGER_ID_B01       35
#define         TRIGGER_TYPE_B01     TRIGGER_TYPE_DIRECT
#ifdef  TRG_16_Bit
#define         TRIGGER_ID_VAL_B01   0x2424
#endif
#ifdef  TRG_32_Bit
#define         TRIGGER_ID_VAL_B01   0x24242424
#endif
#endif

/* ---------------------------------------------------------------------------- */
/* Raster Definition: BYPASS Raster B02                                         */
/* ---------------------------------------------------------------------------- */
#if ( NUMBER_BYPASS_RASTER >= 2)
#define         MAXPTR_B02           0x80
#define         MAXNUM_B02           0x100
#define         BYPASS_OUT_MAX_B02   0x21C

#ifndef TRG_SERIAL_ETK
#define         TRIGGER_B02          TRIGGER_18

#else

#ifdef ETK_HW_HANDSHAKE_DAI
#define         TRIGGER_B02         TRIGGER_DAI_02
#endif

#ifdef ETK_HW_HANDSHAKE_AUD_REG
#define         TRIGGER_B02         TRIGGER_18
#endif
#endif

#define         TRIGGER_ID_B02       36
#define         TRIGGER_TYPE_B02     TRIGGER_TYPE_DIRECT
#ifdef  TRG_16_Bit
#define         TRIGGER_ID_VAL_B02   0x2525
#endif
#ifdef  TRG_32_Bit
#define         TRIGGER_ID_VAL_B02   0x25252525
#endif
#endif

/* ---------------------------------------------------------------------------- */
/* Raster Definition: BYPASS Raster B03                                         */
/* ---------------------------------------------------------------------------- */
#if ( NUMBER_BYPASS_RASTER >= 3)
#define         MAXPTR_B03           0x80
#define         MAXNUM_B03           0x100
#define         BYPASS_OUT_MAX_B03   0x21C

#ifndef TRG_SERIAL_ETK
#define         TRIGGER_B03          TRIGGER_19

#else

#ifdef ETK_HW_HANDSHAKE_DAI
#define         TRIGGER_B03         TRIGGER_DAI_01
#endif

#ifdef ETK_HW_HANDSHAKE_AUD_REG
#define         TRIGGER_B03         TRIGGER_19
#endif
#endif

#define         TRIGGER_ID_B03       37
#define         TRIGGER_TYPE_B03     TRIGGER_TYPE_DIRECT
#ifdef  TRG_16_Bit
#define         TRIGGER_ID_VAL_B03   0x2626
#endif
#ifdef  TRG_32_Bit
#define         TRIGGER_ID_VAL_B03   0x26262626
#endif
#endif

/* ---------------------------------------------------------------------------- */
/* Raster Definition: BYPASS Raster B04                                         */
/* ---------------------------------------------------------------------------- */
#if ( NUMBER_BYPASS_RASTER >= 4)
#define         MAXPTR_B04           0x80
#define         MAXNUM_B04           0x100
#define         BYPASS_OUT_MAX_B04   0x21C

#ifndef TRG_SERIAL_ETK
#define         TRIGGER_B04          TRIGGER_20

#else

#ifdef ETK_HW_HANDSHAKE_DAI
#define         TRIGGER_B04         TRIGGER_DAI_02
#endif

#ifdef ETK_HW_HANDSHAKE_AUD_REG
#define         TRIGGER_B04         TRIGGER_20
#endif
#endif

#define         TRIGGER_ID_B04       38
#define         TRIGGER_TYPE_B04     TRIGGER_TYPE_DIRECT
#ifdef  TRG_16_Bit
#define         TRIGGER_ID_VAL_B04   0x2727
#endif
#ifdef  TRG_32_Bit
#define         TRIGGER_ID_VAL_B04   0x27272727
#endif
#endif
#endif // #ifndef _ETK_INTEGRATION_CFG_H
