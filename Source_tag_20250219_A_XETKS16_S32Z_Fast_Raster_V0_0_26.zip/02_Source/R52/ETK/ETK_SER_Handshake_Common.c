/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "ETK_SER_Handshake.h"
#include "Serial/stdio_func.h"

PRE_SECTION_BSS(ECU_ETK_Status, ".IRAM_measure_variables")
VOLATILE_DEF struct ECU_ETK_Protocol_Status ECU_ETK_Status = { 0, 0, 0 };
POST_SECTION_BSS()

PRE_SECTION_BSS(ECU_ETK_ADV_Status, ".IRAM_measure_variables")
VOLATILE_DEF struct ECU_ETK_ADV_Protocol_Status ECU_ETK_ADV_Status = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
POST_SECTION_BSS()

PRE_SECTION_BSS(HS_start, ".IRAM_measure_variables")
VOLATILE_DEF uint8 HS_start = 0;
POST_SECTION_BSS()

#ifdef HANDSHAKE_EXECUTION_TIME
PRE_SECTION_DATA(ETK_Handshake_Start_Timing_Start, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Handshake_Start_Timing_Start = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Handshake_Start_Timing_End, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Handshake_Start_Timing_End = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Handshake_Timeout, ".IRAM_DATA")
VOLATILE_DEF uint8 ETK_Handshake_Timeout = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Detection_Protocol_Timing_Start, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Detection_Protocol_Timing_Start = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Detection_Protocol_Timing_End, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Detection_Protocol_Timing_End = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Protocol_Handshake_End_Timing_Start, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Protocol_Handshake_End_Timing_Start = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Protocol_Handshake_End_Timing_End, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Protocol_Handshake_End_Timing_End = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Handshake_MBOUT_ACC_Write_Timing, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Handshake_MBOUT_ACC_Write_Timing = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Handshake_MBIN_Clear_Timing, ".IRAM_DATA")
VOLATILE_DEF uint32 ETK_Handshake_MBIN_Clear_Timing = 0;
POST_SECTION_DATA()
#endif

PRE_SECTION_BSS(ETK_Available_ASD_BSW, ".IRAM_measure_variables")
VOLATILE_DEF uint8 ETK_Available_ASD_BSW = 0;
POST_SECTION_BSS()

/* Execute the Initial Handshake (1st Handshake) */
void SER_Initial_Handshake_Execute(void)
{
#ifdef HW_CALWAKEUP_USE
    if (ECU_Mode == HW_CALWAKEUP_MODE && CalWakeUp_Pin_Detection_State == 2 && IsCWUOn()) CalWakeUp_Pin_Detection_State = 3;
#endif
    ETK_Available_ASD_BSW = SER_ETK_Detect();

    if ((ECU_ETK_Status.ETK_Available == 1) || (ECU_ETK_ADV_Status.ETK_Available == 1)) // (X)ETK detected
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("ETK detected! (SER_Initial_Handshake_Execute)\r\n");
#endif
#ifdef HW_CALWAKEUP_USE
        if (ECU_Mode == HW_CALWAKEUP_MODE && CalWakeUp_Pin_Detection_State == 3 && IsCWUOn()) CalWakeUp_Pin_Detection_State = 4;
#endif

        // Enable access to Instrumentation RAM segment as well as EMU RAM
        Enable_EMEM_Access();

        SER_ETK_Handshake_End();

#ifdef HW_CALWAKEUP_USE
        if (ECU_Mode == HW_CALWAKEUP_MODE && CalWakeUp_Pin_Detection_State == 4 && IsCWUOn()) CalWakeUp_Pin_Detection_State = 5;
#endif

        // Coldstart is taken care inside of this function
        SER_ETK_AfterHandshake(handshakeType);

    }
    else
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("No ETK detected! (SER_Initial_Handshake_Execute)\r\n");
#endif
#ifdef LED_HSTYPE
            GPIO_Led_AdvHandshake(LED_OFF);  
#endif
    }
}

/* Detection of the ETK at the startup and execution of the initial handshake. If no ETK protocol is found until the timeout the ECU will initialize without the ETK given settings. */
uint8 SER_ETK_Detect(void)
{
    uint16 protocolSuccess;

    protocolSuccess = SER_ETK_Detection_Protocol_Handshake(); // Detects which handshake is used and evaluate the respective ECU_ETK_Status

    if (0 == protocolSuccess && !ECU_ETK_ADV_Status.ETK_Data_Valid) // No ETK Detection Pattern Protocol (ETK not detected) - Neither Legacy nor Advanced
    {
        // Disable Distab since Distab RAM Areas may not be initialized and the Distab tables may be inconsistent after a power failure
        SER_ETK_Disable_Distabs();

        /* Enable ERAM calibration memory access and initialize the EMEM/ERAM calibration memory reserved for the ECU
        (page switch mailbox and OMD table) with 0 initial values. */
        EMEM_RAM_Initialize();
    }

    return ECU_ETK_Status.ETK_Available | ECU_ETK_ADV_Status.ETK_Available;
}

void SER_Cyclic_Handshake_Check_And_Execute(void)
{
    // Cyclic checks the MBIN Register if there is a new handshake
    if ((eNone == handshakeType) || (eAdvanced == handshakeType && 0 == ECU_ETK_ADV_Status.ETK_ES_Master_Present))
    {
        if (SER_ETK_Check_Protocol_Handshake())
        {
            #ifdef RS232_DEBUG_LOGGING_SUPPORT
                        RS232_TxString("(F/X)ETK detected and available !\r\n");
                        RS232_TxString("Cyclic Handshake !\r\n");
            #endif

            SER_ETK_Handshake_End();

            //SER_ETK_AfterHandshake is not called because Coldstart, RP_Wait and Flash Request is already missed
        }
    }
}


/** SER_ETK_Disable_Distabs() 
 * Disable all Distab Functions (e.g. in case off power fail)
 * it has to be called when the content of the RAM Area
 * where the distab is located might not be correct anymore
 * Return values: none (void)
 */
void SER_ETK_Disable_Distabs(void)
{
    // Disable all DISTAB 17 events - Clearing the D17 event list
#ifdef D17_MAX_EVENT_NO
    uint32 eventNum;

    for (eventNum = 0; eventNum < D17_MAX_EVENT_NO; eventNum++)
    {
        Distab17EventList.Config[eventNum] = 0; // The last bit of the event is the event active bit.
	}
    Distab17EventList.Version = 0;
    Distab17EventList.Change = 0;
    Distab17EventList.First = 0;
    Distab17EventList.Number = 0;
#endif // D17_MAX_EVENT_NO

#ifdef D13_SUPPORT
    Distab13_Disable();
#endif

}

