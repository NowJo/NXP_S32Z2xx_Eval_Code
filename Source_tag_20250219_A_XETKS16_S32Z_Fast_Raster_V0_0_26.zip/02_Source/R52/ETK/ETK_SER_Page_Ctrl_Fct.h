/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

#ifndef _ETK_SER_PAGE_CTRL_FCT_H
#define _ETK_SER_PAGE_CTRL_FCT_H

/* ---------------------------------------------------------------------------*/
/* This file is used for Page Control header Info                             */
/*                                                                            */
/*                                                                            */
/* ---------------------------------------------------------------------------*/

#include "ETK_Integration_Cfg.h"
#include "ETK_SER_Handshake.h"
#include "ETK_CodeCheck.h"
#include "global.h"


#include "base.h"
#include "target_specific.h"
#include "gpio.h"
#ifdef RS232_DEBUG_LOGGING
#include "rs232.h"
#endif

/** Some definitions for page switching:
RPREQ -> Reference Page REQuest
RPACK -> Reference Page configuration ACKnowledge
RPERR -> Reference Page configuration ERRor
WPREQ -> Working Page REQuest
WPACK -> Working Page configuration ACKnowledge
WPERR -> Working Page configuration ERRor
MOREQ -> Modify Overlay REQuest
MOACK -> Modify Overlay memory layout ACKnowledge (Page switch)
MOERR -> Modify Overlay configuration ERRor
*/

/* For the OMD mailbox the value by the ETK is given as an uint32 as opposed to the OCT were it was with uint8s.
Therefore the value to be compared will always be the BIG ENDIAN value.  */

#if defined PROCESSOR_MEM_TYPE_LITTLE_ENDIAN
#define RPACK_PATTERN  0x5250414B    // RPAK
#define WPACK_PATTERN  0x5750414B    // WPAK
#define RPREQ_PATTERN  0x52505251    // RPRQ
#define WPREQ_PATTERN  0x57505251    // WPRQ
#define WPERR_PATTERN  0x57504552    // WPER
#define RPERR_PATTERN  0x52504552    // RPER
#define MOREQ_PATTERN  0x4D4F5251    // MORQ
#define MOACK_PATTERN  0x4D4F414B    // MOAK
#define MOERR_PATTERN  0x4D4F4552    // MOER

#elif defined PROCESSOR_MEM_TYPE_BIG_ENDIAN
#define RPACK_PATTERN  0x4B415052    // RPAK
#define WPACK_PATTERN  0x4B415057    // WPAK
#define RPREQ_PATTERN  0x51525052    // RPRQ
#define WPREQ_PATTERN  0x51525057    // WPRQ
#define WPERR_PATTERN  0x52455057    // WPER
#define RPERR_PATTERN  0x52455052    // RPER
#define MOREQ_PATTERN  0x51524F4D    // MORQ
#define MOACK_PATTERN  0x4B414F4D    // MOAK
#define MOERR_PATTERN  0x52454F4D    // MOER
#else
#error Endian type not defined!
#endif

#define SIZE_PMB (sizeof(Page_Switch_Mailbox))
#define SIZE_OMDV2 (16 + 4 + 4*(((OMDV2_MAX_CALIB_HANDLES_NUMBER - 1)/32) + 1)*4 + 12*OMDV2_MAX_CALIB_HANDLES_NUMBER)

enum ePage_Values
{
    _Undefined = 0,
    WP_AS = 1,
    RP_RS = 2,
    no_page_req = 3
};

#define OMD_ERR_CID         0xC0000001 /* "Incorrect CID of the OMD !" */
#define OMD_ERR_VER         0xC0000002 /* "Incorrect version of the OMD !" */
#define OMD_ERR_NROHANDLES  0xC0000003 /* "Exceeded the maximum number of calibration handles value !" */
#define OMD_ERR_SIZE        0xC0000004 /* "Incorrect OMD table size defined !" */
#define OMD_ERR_CHECKSUM    0xC0000005 /* "Checksum of OMD is invalid !" */
#define OMD_ERR_ACTHANDLES  0xC0000006 /* "Not available EMU-Handle activated in OMD !" */
#define OMD_ERR_TILE        0xC0000007 /* "Tile activation to calibration mode failed: tile already reserved for another application !" */
#define OMD_ERR_INVSTART    0xC0000008 /* "Unknown or unexpected pattern found in the page switch mailbox start page - Forced to RP state !" */
#define OMD_ERR_DATARAM     0xC0000009 /* "DATA_valid when RAM_Fail -> The mailbox start page was read after having been cleared by the RAM invalidation. - Forced to RP state !" */
#define OMD_ERR_CODECHCK    0xC000000A /* "CodeCheck pattern WP failed !" */
#define OMD_ERR_RPRQFAIL    0xC000000B /* "RPREQ failure requested by the user !" */
#define OMD_ERR_WPRQFAIL    0xC000000C /* "WPREQ failure requested by the user !" */
#define OMD_ERR_MORQFAIL    0xC000000D /* "MOREQ failure requested by the user !" */
#define OMD_ERR_STARTPAGE   0xC000000E /* "Start Page RP request - Incorrect OMD - Forced to RP state" */
#define OMD_ERR_EXPHANDLE   0xC000000F /* "Handles on OMD table are not the expected ones by code/build" */
#define OMD_ERR_EMPTY       0xC0000010 /* "Handles on OMD table header is invalid" */

#define HS_ERR_NOANS        0xA0000001; // Handshake timeout from the ECU side - No answer request from the ETK - No coldstart performed
#define HS_ERR_MBIN         0xA0000002; // Handshake timeout from the ECU side - MBIN not cleared by the ETK - No coldstart performed

#if (defined CPUTYPE_RH850_E2x_FCC1)
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x003FFFFF)
#define BNK_B_START (0x00400000)
#define BNK_B_END   (0x007FFFFF)
#endif

#if (defined CPUTYPE_RH850_E2x_FCC2)
/* Start and End Address of Banks*/
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x002FFFFF)
#define BNK_B_START (0x00300000)
#define BNK_B_END   (0x005FFFFF)
#define BNK_C_START (0x00600000)
#define BNK_C_END   (0x008FFFFF)
#define BNK_D_START (0x00900000)
#define BNK_D_END   (0x00BFFFFF)
#define BNK_E_START (0x00C00000)
#define BNK_E_END   (0x00DFFFFF)
#define BNK_F_START (0x00E00000)
#define BNK_F_END   (0x00FFFFFF)
#endif

#if (defined CPUTYPE_RH850_U2A_EVA)
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x003FFFFF)
#define BNK_B_START (0x00400000)
#define BNK_B_END   (0x007FFFFF)
#define BNK_C_START (0x00800000)
#define BNK_C_END   (0x00BFFFFF)
#define BNK_D_START (0x00C00000)
#define BNK_D_END   (0x00FFFFFF)
#endif

#if (defined CPUTYPE_RH850_U2B_EVA)
#if defined CPUSUBTYPE_RH850_U2B_24
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x003FFFFF)
#define BNK_B_START (0x00400000)
#define BNK_B_END   (0x007FFFFF)
#define BNK_C_START (0x00800000)
#define BNK_C_END   (0x00BFFFFF)
#define BNK_D_START (0x00C00000)
#define BNK_D_END   (0x00FFFFFF)
#define BNK_E_START (0x01000000)
#define BNK_E_END   (0x013FFFFF)
#define BNK_F_START (0x01400000)
#define BNK_F_END   (0x017FFFFF)

#elif defined  CPUSUBTYPE_RH850_U2B_20
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x003FFFFF)
#define BNK_B_START (0x00400000)
#define BNK_B_END   (0x007FFFFF)
#define BNK_C_START (0x00800000)
#define BNK_C_END   (0x00BFFFFF)
#define BNK_D_START (0x00C00000)
#define BNK_D_END   (0x00FFFFFF)
#define BNK_E_START (0x01000000)
#define BNK_E_END   (0x011FFFFF)
#define BNK_F_START (0x01200000)
#define BNK_F_END   (0x013FFFFF)

#elif defined  CPUSUBTYPE_RH850_U2B_10
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x002FFFFF)
#define BNK_B_START (0x00300000)
#define BNK_B_END   (0x005FFFFF)
#define BNK_C_START (0x00600000)
#define BNK_C_END   (0x007FFFFF)
#define BNK_D_START (0x00800000)
#define BNK_D_END   (0x008FFFFF)

#elif defined CPUSUBTYPE_RH850_U2B_6
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x002FFFFF)
#define BNK_B_START (0x00300000)
#define BNK_B_END   (0x005FFFFF)
#else
#error *** Undefined or invalid CPUSUBTYPE_RH850 ***
#endif
#endif //(defined CPUTYPE_RH850_U2B_EVA)



#if (defined CPUTYPE_RH850_E2x_PD)
/* This Banks are not actually used since PD does not have CFU */
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x001FFFFF)
#define BNK_B_START (0x00200000)
#define BNK_B_END   (0x003FFFFF)
#endif

#if (defined CPUTYPE_RH850_P1xC)
/* This Banks are not actually used since PD does not have CFU */
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x005FFFFF)
#define BNK_B_START (0x00800000)
#define BNK_B_END   (0x00BFFFFF)
#endif

#if (defined CPUTYPE_RH850_P1M)
/* This Banks are not actually used since PD does not have CFU */
#define BNK_A_START (0x00000000)
#define BNK_A_END   (0x001FFFFF)
#define BNK_B_START (0x00200000)
#define BNK_B_END   (0x003FFFFF)
#endif
/* The CID version implemented for the OMD. - Indicates incompatible layout changes. */
#define OMD_CID_VERSION_1 1
/** OMD version 2 is used for dynamic emulation. */
#define OMD_CID_VERSION_2 2

#ifdef OMD_SUPPORT
// The size for a structure to hold all the bit values for the maximum number of calibration handles. Has to round up the value. For example 33 calib handles require 2 4bytes values.
#define NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION ((NUMBER_OMD_MAX_CALIB_HANDLES+31)/32)

// Structure size with OMDv2 to hold all the bit values.
#define OMDV2_NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION ((OMD_table.OMD_V2_32.EMU_Handles_Number + 31)/32)

#endif

/* OMD specific structures with a specific mailbox containing an error code amd an OMD table instead of the OCT table. */
struct Page_Switching_Mailbox_Struct
{
    uint32  Page_Switching_Pattern_REQ_ACK;  // Page Switch Mailbox for the patterns MORQ, MOAK, MOER, WPRQ, WPAK, WPER, RPRQ, RPAK, RPER
    uint32  Error_Code;                      // Error Code defined in the A2L file
    uint32  Start_Page;                      // Defined Start Page ("WP" enforces the preceding configuration of the Overlay Mechanism)
};


#ifdef OMD_CID_VERSION_2
struct Handle_Entries
{
    uint32 physical;
    uint32 logical;
    uint32 size;
};
#ifdef OMD_SUPPORT
struct OMD_TABLE
{
    // OMD HEADER
    uint32  CID;            // CID of the OMD  (Initial ID 1)
    uint32  Version;        // Version of the OMD table (defined with the MBX_Version value in the A2L file) -> Version 1 does not support MORQ/MOAK/MOER and Version 2 supports it
    uint32  Checksum;       // Checksum of the OMD body without most of the header structure but with the OMD_Size
    uint32  OMD_Size;       // Size of the OMD body without the header
    // OMD BODY
    uint32 EMU_Handles_Number;  // Number of EMU-Handles specified by the structure
    uint32 Available_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION]; // Available calibration handles defined in the A2L file
    uint32 Allocate_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION];  // Allocate the calibration handles (set the corresponding tile to calibration mode)
    uint32 Activate_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION];  // Enable/Disable the corresponding calibration handle
    uint32 Modify_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION];    // Modify the Target Address of the corresponding calibration handle
    struct Handle_Entries Handle[NUMBER_OMD_MAX_CALIB_HANDLES];                    // Target Address of the corresponding calibration handle
};


struct OMD_TABLE_V2_32
{
    // OMD HEADER
    uint32  CID;        // CID of the OMD  (Initial ID 1)
    uint32  Version;    // Version of the OMD table (defined with the MBX_Version value in the A2L file) -> Version 1 does not support MORQ/MOAK/MOER and Version 2 supports it
    uint32  Checksum;   // Checksum of the OMD body without most of the header structure but with the OMD_Size
    uint32  OMD_Size;   // Size of the OMD body without the header
    // OMD BODY
    uint32 EMU_Handles_Number;          // Number of EMU-Handles specified by the structure
    uint32 Available_EMU_Handles[1];    // Available calibration handles defined in the A2L file
    uint32 Allocate_EMU_Handles[1];     // Allocate the calibration handles (set the corresponding tile to calibration mode)
    uint32 Activate_EMU_Handles[1];     // Enable/Disable the corresponding calibration handle
    uint32 Modify_EMU_Handles[1];       // Modify the Target Address of the corresponding calibration handle
    struct Handle_Entries Handle[32];   // Handle Entries: physical address, logical address and size
};

struct OMD_TABLE_V2_64
{
    // OMD HEADER
    uint32  CID;        // CID of the OMD  (Initial ID 1)
    uint32  Version;    // Version of the OMD table (defined with the MBX_Version value in the A2L file) -> Version 1 does not support MORQ/MOAK/MOER and Version 2 supports it
    uint32  Checksum;   // Checksum of the OMD body without most of the header structure but with the OMD_Size
    uint32  OMD_Size;   // Size of the OMD body without the header
    // OMD BODY
    uint32 EMU_Handles_Number;          // Number of EMU-Handles specified by the structure
    uint32 Available_EMU_Handles[2];    // Available calibration handles defined in the A2L file
    uint32 Allocate_EMU_Handles[2];     // Allocate the calibration handles (set the corresponding tile to calibration mode)
    uint32 Activate_EMU_Handles[2];     // Enable/Disable the corresponding calibration handle
    uint32 Modify_EMU_Handles[2];       // Modify the Target Address of the corresponding calibration handle
    struct Handle_Entries Handle[64];   // Handle Entries: physical address, logical address and size
};

struct OMD_TABLE_V2_96
{
    // OMD HEADER
    uint32  CID;        // CID of the OMD  (Initial ID 1)
    uint32  Version;    // Version of the OMD table (defined with the MBX_Version value in the A2L file) -> Version 1 does not support MORQ/MOAK/MOER and Version 2 supports it
    uint32  Checksum;   // Checksum of the OMD body without most of the header structure but with the OMD_Size
    uint32  OMD_Size;   // Size of the OMD body without the header
    // OMD BODY
    uint32 EMU_Handles_Number;          // Number of EMU-Handles specified by the structure
    uint32 Available_EMU_Handles[3];    // Available calibration handles defined in the A2L file
    uint32 Allocate_EMU_Handles[3];     // Allocate the calibration handles (set the corresponding tile to calibration mode)
    uint32 Activate_EMU_Handles[3];     // Enable/Disable the corresponding calibration handle
    uint32 Modify_EMU_Handles[3];       // Modify the Target Address of the corresponding calibration handle
    struct Handle_Entries Handle[96];   // Handle Entries: physical address, logical address and size
};

struct OMD_TABLE_V2_128
{
    // OMD HEADER
    uint32  CID;        // CID of the OMD  (Initial ID 1)
    uint32  Version;    // Version of the OMD table (defined with the MBX_Version value in the A2L file) -> Version 1 does not support MORQ/MOAK/MOER and Version 2 supports it
    uint32  Checksum;   // Checksum of the OMD body without most of the header structure but with the OMD_Size
    uint32  OMD_Size;   // Size of the OMD body without the header
    // OMD BODY
    uint32 EMU_Handles_Number;          // Number of EMU-Handles specified by the structure
    uint32 Available_EMU_Handles[4];    // Available calibration handles defined in the A2L file
    uint32 Allocate_EMU_Handles[4];     // Allocate the calibration handles (set the corresponding tile to calibration mode)
    uint32 Activate_EMU_Handles[4];     // Enable/Disable the corresponding calibration handle
    uint32 Modify_EMU_Handles[4];       // Modify the Target Address of the corresponding calibration handle
    struct Handle_Entries Handle[128];   // Handle Entries: physical address, logical address and size
};

union OMD_TABLE_V1_V2
{
    struct OMD_TABLE OMD_V1;
    struct OMD_TABLE_V2_32 OMD_V2_32;
#if 32<OMDV2_MAX_CALIB_HANDLES_NUMBER
    struct OMD_TABLE_V2_64 OMD_V2_64;
#endif
#if 64<OMDV2_MAX_CALIB_HANDLES_NUMBER
    struct OMD_TABLE_V2_96 OMD_V2_96;
#endif
#if 96<OMDV2_MAX_CALIB_HANDLES_NUMBER
    struct OMD_TABLE_V2_128 OMD_V2_128;
#endif
};

#endif

#else //not OMD_CID_VERSION_2
struct OMD_TABLE
{
    // OMD HEADER
    uint32  CID;        // CID of the OMD  (Initial ID 1)
    uint32  Version;    // Version of the OMD table (defined with the MBX_Version value in the A2L file) -> Version 1 does not support MORQ/MOAK/MOER and Version 2 supports it
    uint32  Checksum;   // Checksum of the OMD body without most of the header structure but with the OMD_Size
    uint32  OMD_Size;   // Size of the OMD body without the header
    // OMD BODY
    uint32 EMU_Handles_Number;  // Number of EMU-Handles specified by the structure
    uint32 Available_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION]; // Available calibration handles defined in the A2L file
    uint32 Allocate_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION];  // Allocate the calibration handles (set the corresponding tile to calibration mode)
    uint32 Activate_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION];  // Enable/Disable the corresponding calibration handle
    uint32 Modify_EMU_Handles[NUMBER_4BYTE_VALUES_PER_CALIB_DEFINITION];    // Modify the Target Address of the corresponding calibration handle
    uint32 Target_Address[NUMBER_OMD_MAX_CALIB_HANDLES];             // Target Address of the corresponding calibration handle
};

#endif

/* Extern structure instance defines for OMD - Used by ETK_SER_User_Spec_Fkts.c */
extern VOLATILE_DEF struct Page_Switching_Mailbox_Struct Page_Switch_Mailbox;
#ifdef OMD_CID_VERSION_2
extern VOLATILE_DEF union OMD_TABLE_V1_V2  OMD_table;
#else
extern VOLATILE_DEF struct OMD_TABLE  OMD_table;
#endif

/* Not Target specific function defines for OMD. */
void SER_ETK_Page_Init_and_Check_WP(uint8 P_ProtocolBasedPageSwitch);
void SER_ETK_PowerFail_Page_Init(uint8 P_ProtocolBasedPageSwitch);
uint8 SER_ETK_Page_Switch_Check_By_ECU(void);
void SER_ETK_Page_Switch_By_ECU(void);
uint8 Check_OMD_Checksum(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
uint8 Check_OMD(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
uint8 Check_availableHandles(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
uint32 Get_Activated_EMU_Handles_Accum(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
uint8 Process_OMD_MORQ(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
uint8 Process_OMD_WPREQ_Start_Page(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
uint8 Process_OMD_RPREQ_Start_Page(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);

/* Target Specific - Target specific function defines for OMD. */
#ifdef OMD_SUPPORT
    /* RH850 E2x CPU Specific functions */
void Update_OvlHandleReg(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
void Update_All_OvlHandleReg(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
void Initialize_Calib_Registers(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
void Disable_Calibration_Handles(void);
void Set_Calibration_Handles (VOLATILE_DEF struct OMD_TABLE * OMD_table_Ptr);
uint8 Check_Calibration_Handles_in_RP_mode(void);

// 'updateAll' input -> 0: update only modified handles; 1: update all handles
void Common_Update_OvlHandleReg(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr, uint8 updateAll);

#ifdef CHECK_EXPECTED_HANDLE
uint8 Check_IsExpectedHandle(VOLATILE_DEF struct OMD_TABLE* OMD_table_Ptr);
#endif

#endif // #ifdef OMD_SUPPORT

#endif // #ifndef _ETK_SER_PAGE_CTRL_FCT_H




