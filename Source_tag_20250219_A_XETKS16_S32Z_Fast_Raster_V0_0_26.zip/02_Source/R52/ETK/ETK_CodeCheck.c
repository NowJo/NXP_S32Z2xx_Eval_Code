/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "ETK_CodeCheck.h"
#include "CompileTime.h"

//******************************************************************************
//ETK Code check pattern in RAM section
#ifdef CODECHECK_SUPPORT
PRE_SECTION_BSS(CODE_CHECK_PATTERN_RAM_DATE, ".code_checkMemClassRam")
VOLATILE_DEF uint32 CODE_CHECK_PATTERN_RAM_DATE;
POST_SECTION_BSS()
PRE_SECTION_BSS(CODE_CHECK_PATTERN_RAM_TIME, ".code_checkMemClassRam")
VOLATILE_DEF uint32 CODE_CHECK_PATTERN_RAM_TIME;
POST_SECTION_BSS()

//ETK Code check pattern in EMURAM section
PRE_SECTION_BSS(CODE_CHECK_PATTERN_EMURAM_DATE, ".code_checkMemClassEMURam")
VOLATILE_DEF uint32 CODE_CHECK_PATTERN_EMURAM_DATE;
POST_SECTION_BSS()
PRE_SECTION_BSS(CODE_CHECK_PATTERN_EMURAM_TIME, ".code_checkMemClassEMURam")
VOLATILE_DEF uint32 CODE_CHECK_PATTERN_EMURAM_TIME;
POST_SECTION_BSS()
#endif
extern uint8 RS232DebugLevel;

uint8 CodeCheck_WP_passed = 0;


VOLATILE_DEF uint8 PageSwitch_depending_on_CodeCheck = 0;
VOLATILE_DEF uint8 RPREQ_Force_Fail = 0;
VOLATILE_DEF uint8 WPREQ_Force_Fail = 0;
VOLATILE_DEF uint8 MOREQ_Force_Fail = 0;


//copy CodeCheck Pattern cyclic in ECU RAM - Used for ACC - Advanced Code Check
void CopyCodeCheckPattern_cyclic(uint8 Error_Pattern)
{
#ifdef CODECHECK_SUPPORT
    if (Error_Pattern == write_wrong_RAM_Pattern)
    {
        //write error pattern in ECU RAM
        CODE_CHECK_PATTERN_RAM_DATE = ERROR_PATTERN_DATE;
        CODE_CHECK_PATTERN_RAM_TIME = ERROR_PATTERN_TIME;
    }

    else
    {

        //write ECU CodeCheck pattern from ECU code section to ECU RAM section
        CODE_CHECK_PATTERN_RAM_DATE = CODE_CHECK_CODE.Date;
        CODE_CHECK_PATTERN_RAM_TIME = CODE_CHECK_CODE.Time;

    }
#endif
}

void initRAMCheckPattern(void)
{
#ifdef CODECHECK_SUPPORT
    //write ECU CodeCheck pattern from ECU code section to ECU RAM section
    CODE_CHECK_PATTERN_RAM_DATE = CODE_CHECK_CODE.Date;
    CODE_CHECK_PATTERN_RAM_TIME = CODE_CHECK_CODE.Time;
#endif
}

//do a code check after reset
uint8 CodeCheck_RP(void)
{
    //local variables
    uint8 passed = 1;
#ifdef CODECHECK_SUPPORT
    uint32 CodeCheckPattern_Date;
    uint32 CodeCheckPattern_Time;

    // now read the code check pattern, which is located in the ECU Data region and compare with the pattern in the ECU code section
    CodeCheckPattern_Date = CODE_CHECK_DATA.Date;
    CodeCheckPattern_Time = CODE_CHECK_DATA.Time;
#ifndef CPUTYPE_rh850_C1H_FCC1_AUDR
#ifdef RS232_DEBUG_LOGGING
    RS232_TxString("Read code check pattern from ECU Data region: \r\ncompile date:     ");
    RS232_TxHexLong(CodeCheckPattern_Date);
    RS232_TxString("\r\ncompile time:     ");
    RS232_TxHexLong(CodeCheckPattern_Time);
    RS232_TxString("\r\n");
#endif
#endif

    //check for Code Check pattern
    if ((CodeCheckPattern_Date == CODE_CHECK_CODE.Date) && (CodeCheckPattern_Time == CODE_CHECK_CODE.Time))
    {
        passed = 1;
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("Code Check for serial ETK after reset passed ! \r\n\r\n");
#endif
    }
    else
    {
        passed = 0;
#ifndef CPUTYPE_rh850_C1H_FCC1_AUDR
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("Code Check for serial ETK after reset failed !\r\nCode check pattern must be : \r\ncompile date:     ");
        RS232_TxHexLong(CODE_CHECK_CODE.Date);
        RS232_TxString("\r\ncompile time:     ");
        RS232_TxHexLong(CODE_CHECK_CODE.Time);
        RS232_TxString("\r\n\r\n");
#endif
#endif
    }
#endif
    return (passed);
}

//do a code check before page switch RP -> WP
uint8 CodeCheck_WP(void)
{
    //local variables
    uint8 passed = 1;
#ifdef CODECHECK_SUPPORT
    uint32 CodeCheckPattern_Date;
    uint32 CodeCheckPattern_Time;

    // now read the code check pattern, which is located in the ECU EmuRAM region and compare with the pattern in the ECU code section
    CodeCheckPattern_Date = CODE_CHECK_PATTERN_EMURAM_DATE;
    CodeCheckPattern_Time = CODE_CHECK_PATTERN_EMURAM_TIME;

    if (RS232DebugLevel > 3)
    {
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("Doing Code Check for serial ETK before page switch RP -> WP ...\r\n");
        RS232_TxString("Read code check pattern from ECU EmuRAM region, pattern is : \r\ncompile date:     ");
        RS232_TxHexLong(CodeCheckPattern_Date);
        RS232_TxString("\r\ncompile time:     ");
        RS232_TxHexLong(CodeCheckPattern_Time);
        RS232_TxString("\r\n");
#endif
    }

    //check for Code Check pattern
    if ((CodeCheckPattern_Date == CODE_CHECK_CODE.Date) && (CodeCheckPattern_Time == CODE_CHECK_CODE.Time))
    {
        passed = 1;
        CodeCheck_WP_passed = 1;
#ifdef RS232_DEBUG_LOGGING

        if (RS232DebugLevel > 1)
        {
            RS232_TxString("Code Check for serial ETK before page switch RP -> WP passed ! \r\n\r\n");
        }

#endif

    }
    else
    {
        passed = 0;
        CodeCheck_WP_passed = 0;
#ifdef RS232_DEBUG_LOGGING

        if (RS232DebugLevel > 1)
        {
            RS232_TxString("Code Check for serial ETK before page switch RP -> WP failed ! \r\n");
        }

        if (RS232DebugLevel > 3)
        {
            RS232_TxString("\r\ncode check pattern must be : \r\ncompile date:     ");
            RS232_TxHexLong(CODE_CHECK_CODE.Date);
            RS232_TxString("\r\ncompile time:     ");
            RS232_TxHexLong(CODE_CHECK_CODE.Time);
            RS232_TxString("\r\n\r\n");
        }

#endif

    }
#endif
    return (passed);
}


/* Updates the adaptive parameter for the OMD force fail variables. It is possible to force the page switching to fail with these values defined in ASCET as adaptive parameters. */
void OMD_Adaptive_Force_Fail_Parameters_Update(uint8 RPREQ_Fail, uint8 WPREQ_Fail, uint8 MOREQ_Fail)
{
    RPREQ_Force_Fail = RPREQ_Fail;
    WPREQ_Force_Fail = WPREQ_Fail;
    MOREQ_Force_Fail = MOREQ_Fail;
}



void Check_PageSwitch_after_CodeCheck(uint8 state_ASD)
{
    PageSwitch_depending_on_CodeCheck = state_ASD;
}

