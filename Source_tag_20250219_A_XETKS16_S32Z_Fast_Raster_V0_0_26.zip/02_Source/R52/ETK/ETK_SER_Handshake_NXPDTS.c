/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "ETK_SER_Handshake.h"
#include "ETK_CodeCheck.h"
#include "S32Z27.h"
#include "Serial/stdio_func.h"

PRE_SECTION_BSS(MBIN_Value, ".common_core_share")
VOLATILE_DEF union ETK_Detection_Pattern_Protocol MBIN_Value;
POST_SECTION_BSS()
PRE_SECTION_BSS(handshakeType, ".common_core_share")
VOLATILE_DEF uint8 handshakeType = eNone;
POST_SECTION_BSS()
PRE_SECTION_BSS(DBG_STUP_Value, ".common_core_share")
VOLATILE_DEF uint32 DBG_STUP_Value;
POST_SECTION_BSS()
PRE_SECTION_BSS(handshakeStored, ".common_core_share")
VOLATILE_DEF uint32 handshakeStored[10] = { 0 };
POST_SECTION_BSS()
PRE_SECTION_BSS(handshakeIndex, ".common_core_share")
VOLATILE_DEF uint32 handshakeIndex = 0;
POST_SECTION_BSS()
PRE_SECTION_BSS(ETK_Handshake_Start_Time, ".common_core_share")
VOLATILE_DEF uint32 ETK_Handshake_Start_Time = 0;
PRE_SECTION_BSS(pMBIN, ".common_core_share")
VOLATILE_DEF uint32 *pMBIN;
POST_SECTION_BSS()
PRE_SECTION_BSS(pMBOUT, ".common_core_share")
VOLATILE_DEF uint32 *pMBOUT;
POST_SECTION_BSS()

extern VOLATILE_DEF uint8 bRegTrigger_Active;

static uint32 GetHandshake(void)
{
	uint32 hs_status=0;
	pMBIN=NULL;
	pMBOUT=NULL;

	//Either handshake could be supported we do not know which is being used at this point so test both
#if (defined(AUD_Test) || defined(OVERRIDE_HS))
	hs_status = 0x01010027;
#else
# if !(defined(ADV_HW_HS_SUPPORTED)||defined(HS_ON_RAM))
   //There is no handshake defined
    hs_status = 0;
# else
#  if defined(ADV_HW_HS_SUPPORTED)&&defined(DBG_MBIN)
    if (0 != DBG_MBIN)
    {
        //If both are defined and set then the HW handshake wins
        pMBIN = (uint32 *)(&DBG_MBIN);
        pMBOUT = (uint32 *)(&DBG_MBOUT);
        hs_status = DBG_MBIN;
#ifdef TRG_ON_REG
        bRegTrigger_Active=1;
#endif
    }
#  endif
#  ifdef HS_ON_RAM
   	if(0==hs_status && RAM_INTERFACE.HS_IN != 0)
   	{
#   ifdef ADV_HS_SUPPORTED
        pMBIN = &RAM_INTERFACE.HS_IN;
        pMBOUT = &RAM_INTERFACE.HS_OUT;
#   endif
        hs_status = RAM_INTERFACE.HS_IN;
#ifdef TRG_ON_REG
        bRegTrigger_Active=0;
#endif
   	}
#  endif
# endif //No Handshake support
#endif //OVERRIDE_HS


    return hs_status;
}

/* Saves the initial start time when the ECU waits for the ETK Detection Protocol. */
static void Start_Time_ETK_Detection_Protocol(void)
{

    ETK_Handshake_Start_Time = BASE_GetSystemTime();

}

/* Compares the current time with the maximum timeout wait time for the ETK Detection Protocol. */
static uint8 IsTimeout_ETK_Detection_Protocol(void)
{
    if (( BASE_GetSystemTime()-ETK_Handshake_Start_Time ) < MSEC_TO_TICKS(HANDSHAKE_WAIT_TIME_ms))
    {
        return 0;
    }
    else
    {
        return 1;
    }

}


/* Reads the communication Data Register to detect the different bit settings given by the ETK during the handshake. Checks until the timeout.
Returns 1 if the Protocol is read from the COMDATA successfully.
Returns 0 if no ETK Detection Pattern Protocol is found until the timeout. */
uint16 SER_ETK_Detection_Protocol_Handshake(void)
{
    ECU_ETK_Status.ETK_Available = 0;
    ECU_ETK_Status.ETK_Power_Failure = 1; // if no (X)ETK is found the power failure bit is set to disable calibration and measurements
    ECU_ETK_Status.ETK_Flash_Request = 0;

    ECU_ETK_ADV_Status.Protocol_Success = 0; // ETK Detection Protocol not found
    ECU_ETK_ADV_Status.Handshake_End_State = 0xFF; // No timeout detected during the handshake end phase

    ECU_ETK_ADV_Status.ETK_Available = 0;       // ETK detected during the handshake  ->  set to false
    ECU_ETK_ADV_Status.Debugger_Available = 0;  // Debugger detected during the handshake  ->  set to false
    ECU_ETK_ADV_Status.ETK_Data_Valid = 0;      // Data powerfail detected. Invalidate the calibration data, and switch to the RP  -> validity set to false
    ECU_ETK_ADV_Status.ETK_RAM_Valid = 0;       // RAM powerfail detected. Invalidate the Distab and bypass functions  ->  validity set to false
    ECU_ETK_ADV_Status.ETK_MC_Wait = 0;         // Wait for MC configuration in the coldstart. Coldstart measurement wil be configured after the handshake.  ->  set to false
    ECU_ETK_ADV_Status.ETK_RP_Wait = 0;         // Wait for RP configuration in the coldstart. Bypass will be configured after the handshake.  ->  set to false
    ECU_ETK_ADV_Status.ETK_ES_Master_Present = 0;  // ES device present to control the ETK  ->  set to false
    ECU_ETK_ADV_Status.ETK_CalWakeUp = 0;       // CalWakeUp activated  ->  set to false
    ECU_ETK_ADV_Status.ETK_Flash_Request = 0;   // Flash programming was requested by the tool  ->  set to false

    /* Gets the system time at the start of the ETK protocol detection */
    Start_Time_ETK_Detection_Protocol();
#ifdef HANDSHAKE_EXECUTION_TIME
    // Saves the initial start time when the ECU waits for ETK Handshake
    ETK_Handshake_Start_Timing_Start = BASE_GetSystemTime();
#endif

    // TOCHECK: DBG_TRG can be checked to see if XETK is present before reading the value in DBG_STUP ???

    //poll DBG_STUP and DBG_MBIN registers
    do
    {
#if (defined LEGACY_HS_SUPPORTED)
        // Gets values of the registers
        DBG_STUP_Value = DBG_STUP;

        // Checks if Legacy Register is used
        if (DBG_STUP_Value != 0)
        {
#ifdef HANDSHAKE_EXECUTION_TIME
            // Saves time when the handshake is detected
            ETK_Detection_Protocol_Timing_Start = BASE_GetSystemTime();
#endif

            handshakeType = eLegacy;
#ifdef LED_HSTYPE
            GPIO_Led_AdvHandshake(LED_OFF);  
#endif
            //(X)ETK available - Power failure detected
            if ( 0x9 == DBG_STUP_Value )
            {
                ECU_ETK_Status.ETK_Available = 1;
                ECU_ETK_Status.ETK_Power_Failure = 1;
                ECU_ETK_Status.ETK_Flash_Request = 0;
            }
            //(X)ETK available - NO power failure detected
            else if ( 0xA == DBG_STUP_Value )
            {
                ECU_ETK_Status.ETK_Available = 1;
                ECU_ETK_Status.ETK_Power_Failure = 0;
                ECU_ETK_Status.ETK_Flash_Request = 0;
            }
            //Flashing mode detected - Power failure detected
            else if ( 0x5 == DBG_STUP_Value )
            {
                ECU_ETK_Status.ETK_Available = 0;
                ECU_ETK_Status.ETK_Power_Failure = 1;
                ECU_ETK_Status.ETK_Flash_Request = 1;
            }
            //Flashing mode detected - NO power failure detected
            else if ( 0x6 == DBG_STUP_Value )
            {
                ECU_ETK_Status.ETK_Available = 0;
                ECU_ETK_Status.ETK_Power_Failure = 0;
                ECU_ETK_Status.ETK_Flash_Request = 1;
            }

        }

        // Checks if Advanced Register is used
        else
#endif //!(defined LEGACY_HS_SUPPORTED)
        {
        #if (defined ADV_HS_SUPPORTED)
            SER_ETK_Check_Protocol_Handshake(); // Reading of all bit of the Advanced Handshake Protocol
        #endif //#if (defined ADV_HS_SUPPORTED)
        }

#ifdef ETK_HANDSHAKE_DEBUG_WAIT_SECOND
    } while (ECU_ETK_Status.ETK_Available == 0 && IsTimeout_ETK_Detection_Protocol() == 0);
#else
    } while ((IsTimeout_ETK_Detection_Protocol() == 0) && !(ECU_ETK_Status.ETK_Available) && !(ECU_ETK_ADV_Status.ETK_Available));
#endif

#ifdef HANDSHAKE_EXECUTION_TIME
    // Saves time when the handshake check is done (either timeout or executed)
    ETK_Handshake_Start_Timing_End = BASE_GetSystemTime();

    if (!(ECU_ETK_Status.ETK_Available) && !(ECU_ETK_ADV_Status.ETK_Available)) // Means Handshake timeout
    {
        ETK_Handshake_Timeout = 1;
    }
    else
    {
        ETK_Detection_Protocol_Timing_End = ETK_Handshake_Start_Timing_End;
    }
#endif

    return (ECU_ETK_Status.ETK_Available | ECU_ETK_Status.ETK_Flash_Request | ECU_ETK_ADV_Status.ETK_Available | ECU_ETK_ADV_Status.ETK_Flash_Request);
}


/* Evaluates all bits of Advanced Handshake Protocol*/
uint16 SER_ETK_Check_Protocol_Handshake(void)
{

	MBIN_Value.U=GetHandshake();


    if (MBIN_Value.U != 0)
    {
#ifdef HANDSHAKE_EXECUTION_TIME
        // Saves time when the 1st handshake (only the 1st one) is detected
        if (eNone == handshakeType)
        {
            ETK_Detection_Protocol_Timing_Start = BASE_GetSystemTime();
        }
#endif

        handshakeType = eAdvanced;
#ifdef LED_HSTYPE
        GPIO_Led_AdvHandshake(LED_ON);  
#endif
        if (handshakeIndex > 9)
        {
            handshakeStored[9] = MBIN_Value.U; // handshakeStored is just size 10 (0..9), so if more is necessary, the last item will be overwritten by last pattern
        }
        else
        {
            handshakeStored[handshakeIndex] = MBIN_Value.U;
        }

        handshakeIndex++; // Adding for the next handshake

        /* Protocol type: bits 24-31*/
        if (MBIN_Value.B.ProtocolType == 0x01) // ETK Detection Pattern Protocol detected
        {
            ECU_ETK_ADV_Status.Protocol_Success = 1; // ETK Detection Pattern Protocol successfully read

            /* Tool type: bits 16-23 */
            ECU_ETK_ADV_Status.ETK_Available = MBIN_Value.B.ETKPresent;
            ECU_ETK_ADV_Status.Debugger_Available = MBIN_Value.B.DebuggerPresent;

            /* Protocol specific parameters: bits 0-15 */
            ECU_ETK_ADV_Status.ETK_Data_Valid = MBIN_Value.B.DataValid;
            ECU_ETK_ADV_Status.ETK_RAM_Valid = MBIN_Value.B.RAMValid;
            ECU_ETK_ADV_Status.ETK_MC_Wait = MBIN_Value.B.MCWait;
            ECU_ETK_ADV_Status.ETK_RP_Wait = MBIN_Value.B.RPWait;
            ECU_ETK_ADV_Status.ETK_ES_Master_Present = MBIN_Value.B.ESMasterPresent;
            ECU_ETK_ADV_Status.ETK_CalWakeUp = MBIN_Value.B.CalWakeUp;
            ECU_ETK_ADV_Status.ETK_Flash_Request = MBIN_Value.B.FlashProgRequest;
#ifdef RS232_DEBUG_LOGGING
                    RS232_TxString("ETK detected\r\n");
#endif
            
            return 1; // Successful ETK Protocol read
        }
    }


    return 0; // No ETK Detection Protocol or Wrong Protocol Type
}

uint8 SER_ETK_Handshake_End(void)
{
#ifdef HANDSHAKE_EXECUTION_TIME
    // Saves time when the "handshake end" start
    ETK_Protocol_Handshake_End_Timing_Start = BASE_GetSystemTime();
#endif

    if (eLegacy == handshakeType)
    {
        SER_ETK_Legacy_Handshake();
    }

    else if (eAdvanced == handshakeType)
    {
        SER_ETK_Advanced_1stHandshake();
    }

#ifdef HANDSHAKE_EXECUTION_TIME
    // Saves time when the "handshake end" ends to see the elapsed time since
    ETK_Protocol_Handshake_End_Timing_End = BASE_GetSystemTime();
#endif

    return ECU_ETK_ADV_Status.Handshake_End_State; // If it's legacy, the return doesn't matter

}

void SER_ETK_Legacy_Handshake(void)
{
#ifdef LEGACY_HS_SUPPORTED
    if (ECU_ETK_Status.ETK_Power_Failure)
    {
        // Disable Handles and switch to RP
        SER_ETK_PowerFail_Page_Init(1);

        // Disable Distab since Distab RAM Areas may not be initialized and the Distab tables may be inconsistent after a power failure
        SER_ETK_Disable_Distabs();

        /* Enable ERAM calibration memory access and initialize the EMEM/ERAM calibration memory reserved for the ECU
        (page switch mailbox and OMD table) with 0 initial values. */
        EMEM_RAM_Initialize();
    }
    else
    {
        SER_ETK_Page_Init_and_Check_WP(1);  // 1-> PBA, 0-> DRA
    }

    DBG_TRG = 0x55555555; // Signalizes to the XETK that the ECU acknowledged the handshake (ECU -> XETK)
#endif
/* ----------------- END OF LEGACY HANDSHAKE -----------------*/
}

//TOCHECK: this workflow can be brought to Handshake_Common ?
void SER_ETK_Advanced_1stHandshake(void)
{
#ifdef ADV_HS_SUPPORTED
    uint32 handshakeAdvanced_tm = 0;

    GetHandshake();


    ECU_ETK_ADV_Status.Handshake_End_State = 1; // Activate wait state - Not clear/written by ECU

    /* Master is not present (no ES device or Master is not connected to ETK. If the ES/Master is not present at the time of
    the 1st Handshake, it will execute a 2nd handshake when ES/Master is detected */
    if (!ECU_ETK_ADV_Status.ETK_ES_Master_Present)
    {

    }

    // If RAM is not Valid -> Clear all the RAM used for calibration
    if (ECU_ETK_ADV_Status.ETK_RAM_Valid)
    {
        Page_Switch_Mailbox.Error_Code = 0; // Clear the error code for the page switching
    }
    else
    {
        EMEM_RAM_Initialize();
    }

    if( !ECU_ETK_ADV_Status.Protocol_Success)
    {
    // Disable DISTAB
    SER_ETK_Disable_Distabs();
    // MC_Ready Pattern
    SER_ETK_Clear_Coldstart_Value(); // Clears the coldstart value
    }

    // If Data is Valid -> Execute OMD
    if (ECU_ETK_ADV_Status.ETK_Data_Valid)
    {
        // Execute OMD
        SER_ETK_Page_Init_and_Check_WP(1);  // 1-> PBA, 0-> DRA
    }
    else
    {
        // Disable Handles and switch to RP
        SER_ETK_PowerFail_Page_Init(1); // 1-> PBA, 0-> DRA
    }

    if( NULL == pMBOUT)
    {
    	//No handshake is defined
    	return;
    }
#ifdef CODECHECK_SUPPORT
    *pMBOUT = (uint32)&CODE_CHECK_DATA.Date;
#endif

#ifdef HANDSHAKE_EXECUTION_TIME
    // Saves time when ECU writes ACC to MBOUT
    ETK_Handshake_MBOUT_ACC_Write_Timing = BASE_GetSystemTime();
#endif
    ECU_ETK_ADV_Status.Handshake_End_State = 2; // Active wait state - DBG_MBOUT written by ECU -> waiting for the ETK to clear the MB and end the handshake

    while ((*pMBIN != 0) && (handshakeAdvanced_tm < 0x30000))
    {
        handshakeAdvanced_tm++; // just a very big number to avoid getting stuck into this while
    }
#ifdef HANDSHAKE_EXECUTION_TIME
    // Saves time when ETK clears MBIN
    ETK_Handshake_MBIN_Clear_Timing = BASE_GetSystemTime();
#endif

    if (*pMBIN == 0) // It means that the Zero value was written in MBIN by the ETK
    {
        ECU_ETK_ADV_Status.Handshake_End_State = 0; // The handshake ended correctly
    }

    switch (ECU_ETK_ADV_Status.Handshake_End_State)
    {
    case 0:  // 0 -> The handshake ended correctly
        /* !!!!!!!!!!! The ECU has to write 0x0 to the MBOUT register  !!!!!!!!!!!  */
        *pMBOUT = 0; // The ECU also writes 0 to the MBOUT register.
        break;

    case 1:  // 1 -> ECU response not written in MBOUT - No answer request from the ETK
        *pMBOUT = 0; // The ECU clears the MBOUT register.

        Page_Switch_Mailbox.Error_Code = HS_ERR_NOANS; // Handshake timeout from the ECU side - No answer request from the ETK - No coldstart performed

        break;

    case 2:  // 2 -> ECU timeout after the ECU writes in the MBOUT - MBIN not cleared by the ETK
        *pMBOUT = 0; // The ECU clears the MBOUT register.

        Page_Switch_Mailbox.Error_Code = HS_ERR_MBIN; // Handshake timeout from the ECU side - MBIN not cleared by the ETK - No coldstart performed

        break;

    default:  // Default -> This should never be hit.
        break;
    }
    /* ----------------- END OF 1st HANDSHAKE -----------------*/

#endif //ADV_HS_SUPPORTED
}

uint8 SER_ETK_PowerFailure_Check(void)
{
    if ((eLegacy == handshakeType) && (ECU_ETK_Status.ETK_Power_Failure == 1))
    {
        return 1;
    }

    if ((eAdvanced == handshakeType ) && !(ECU_ETK_ADV_Status.ETK_Data_Valid))
    {
        return 1;
    }

    return 0;
}

void EMEM_RAM_Initialize(void)
{
    //This is generic, so that if the 'type cast' size of the pointer is changed the clears will adjust to that type sise
    #define update_size uint32
    //typedef uint32 update_size
    VOLATILE_DEF update_size* dst_ptr;
    uint32 no_of_val;

    Enable_EMEM_Access();

    dst_ptr = (update_size*)&Page_Switch_Mailbox;  // Start address of RAM used for Page Switch Mailbox
    no_of_val = (SIZE_PMB / sizeof(dst_ptr));

    // Clearing memory areas related to Page Switch Mailbox
    while (no_of_val > 0)
    {
        *dst_ptr++ = 0x0;
        no_of_val--;
    }

    dst_ptr = (update_size*)&OMD_table;  // Start address of RAM used for OMD V2 (Worst Case)
    no_of_val = (SIZE_OMDV2 / sizeof(dst_ptr));

    // Clearing memory areas related to Page Switch Mailbox
    while (no_of_val > 0)
    {
        *dst_ptr++ = 0x0;
        no_of_val--;
    }

    dst_ptr = (update_size*)&Distab17EventList;  // Start address of RAM used for D17
    no_of_val = (SIZE_D17 / sizeof(dst_ptr));

    // Clearing memory areas related to D17 and D13
    while (no_of_val > 0)
    {
        *dst_ptr++ = 0x0;
        no_of_val--;
    }
}

void Enable_EMEM_Access(void)
{
#if (defined CPUTYPE_RH850_E2x_FCC1) || (defined CPUTYPE_RH850_E2x_FCC2)
    AURORA_CDLSC = 0x00000001; //Enable ED RAM (ERAM) access - Aurora Core Domain Level Shifter control Register -> LSEN_VPD set to not clinch
#elif (defined CPUTYPE_RH850_P1xC)
    SELSECLOCK = 1; /* OCDID Authentication for AUDR, CIU and CFU is activated */
    for (uint8 i = 0; i < 8; i++)
    {
        *((uint32*)(&SELFIDn + i)) = 0xFFFFFFFF; /* OCDID Authentication (Self Programming ID) */
    }
#endif

}

void SER_ETK_AfterHandshake(uint8 typeHS)
{
    if (eLegacy == typeHS)
    {
        SER_ETK_Clear_Coldstart_Value(); // Clears the coldstart value
        Start_Timing_Coldstart();
        ColdStartStates_BSW = SER_ETK_Check_Coldstart(typeHS);
    }
    else if (eAdvanced == typeHS )
    {
        // Wait for MC Config. ("Coldstart measurement will be configured after handshake")
        if (ECU_ETK_ADV_Status.ETK_MC_Wait && ECU_ETK_ADV_Status.Handshake_End_State == 0)
        {
            // Clear Coldstart Value is already executed inside of SER_ETK_Advanced_1stHandshake()
            Start_Timing_Coldstart();
            ColdStartStates_BSW = SER_ETK_Check_Coldstart(typeHS);
        }

        // CalWakeUp feature is active
        if (ECU_ETK_ADV_Status.ETK_CalWakeUp)
        {
            //USER: User can insert specific function if needed
        }

        // FlashProgramming Request -> ETK is not Available and Flash Request
        if (ECU_ETK_ADV_Status.ETK_Flash_Request)
        {
            // USER: User can set the flash programming bit
        }
    }
}
