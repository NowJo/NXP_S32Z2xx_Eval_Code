/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#ifndef __DISTAB13_FCT_H__
#define __DISTAB13_FCT_H__


#include "ETK_Integration_Cfg.h"

#include "target_specific.h"
#ifdef RS232_DEBUG_LOGGING
#include "rs232.h"
#endif

#ifdef D13_SUPPORT

/* Distab triggering uses a register trigger for a serial (X)ETK. used with Distab13*/
#define TRG_SERIAL_ETK


// Number of Distab 13 measurement rasters supported by the project
#ifdef D13_SUPPORT
#define NUMBER_MEASUREMENT_RASTER 3
#else
#define NUMBER_MEASUREMENT_RASTER 0
#endif


//defines
#define         DIRECT                           0x01
#define         INDIRECT                         0x00
#define         MAXPTR_R01                       0x200
#define         MAXPTR_R02                       0x200
#define         MAXPTR_R03                       0x200
#define         MAXNUM_R01                       0x400
#define         MAXNUM_R02                       0x400
#define         MAXNUM_R03                       0x400

// ACTIVE Control Bit to signal valid DISTAB
#define         DISTAB_ACTIVE_BIT                0x01

// possible Return Values for distabProcess()
#define         D13_TABLE_NOT_ACTIVE             0x00
#define         D13_DATA_ACQUISITION_SUCCESS     0xFF
#define         D13_TABLE_MAX_NUM_DATA_ERROR     0x01

//typedefs

#ifndef TYPEDEF_ULONGULONG
#define TYPEDEF_ULONGULONG
typedef     struct ulonglong
{
    uint32      hWrd;
    uint32      lWrd;
} ustr64;
#endif // #ifndef TYPEDEF_ULONGULONG

typedef struct DistabHeader
{
    uint8     activ;
    uint8     dummy1;
    uint8     dummy2;
    uint8     dummy3;
    uint8     NoOfVal_8;
    uint8     NoOfVal_4;
    uint8     NoOfVal_2;
    uint8     NoOfVal_1;
} tDistabHeader;

//*** Distab discriptor ***/
typedef struct DistabDescriptor
{
    struct DistabHeader* Dstb_Header;
    uint32* DaqChnlPtr;
    uint16              NoOfPtr;
    uint16              NoOfDataBytes;
} tDistabDescriptor;

/* ---------------------------------------------------------------------------*/
/* Bypass Header-Descriptor                                                   */
/* ---------------------------------------------------------------------------*/
// Header of each Bypass  RP -> ECU Table
typedef struct BypassHeader
{
    uint8     counter;
    uint8     dummy1;
    uint8     dummy2;
    uint8     dummy3;
    uint8     dummy4;
    uint8     dummy5;
    uint8     dummy6;
    uint8     dummy7;
} tBypassHeader;

//functions
uint8 distab13fkt(tDistabDescriptor Distab);


void ETK_Distab13_Process_Rxx(uint8 Raster, uint8 Trigger_Direct, uint16 Trigger, uint8 Trigger_ID, uint32 Trigger_ID_Val);
void Set_ETKTrigger_Direct(uint16 Trigger);
void Set_ETKTrigger_Indirect(uint16 Trigger, uint8 Trigger_ID, uint32 Trigger_ID_Val);



/* ---------------------------------------------------------------------------*/
/* Instance of Measurement Distabs                                            */
/* ---------------------------------------------------------------------------*/

// Measurement Distab R01
#if ( NUMBER_MEASUREMENT_RASTER >= 1)
struct Distab_R01S
{
    tDistabHeader Header;
    uint32 display_tabelle[MAXPTR_R01];
};
extern VOLATILE_DEF struct Distab_R01S DISTAB_R01;

#endif

// Measurement Distab R02
#if ( NUMBER_MEASUREMENT_RASTER >= 2)
struct Distab_R02S
{
    tDistabHeader Header;
    uint32 display_tabelle[MAXPTR_R02];
};
extern VOLATILE_DEF struct Distab_R02S DISTAB_R02;

#endif // #if ( NUMBER_MEASUREMENT_RASTER >= 2)

// Measurement Distab R03
#if ( NUMBER_MEASUREMENT_RASTER >= 3)
struct Distab_R03S
{
    tDistabHeader Header;
    uint32 display_tabelle[MAXPTR_R03];
};
extern VOLATILE_DEF struct Distab_R03S DISTAB_R03;

#endif // #if ( NUMBER_MEASUREMENT_RASTER >= 3)

/* ---------------------------------------------------------------------------*/
/* Instance of Bypass Distab_Configuration Structs                            */
/* ---------------------------------------------------------------------------*/

// Bypass Distab CFG struct B01
#if ( NUMBER_BYPASS_RASTER >= 1)
struct Distab_B01S
{
    tDistabHeader Header;
    uint32 display_tabelle[MAXPTR_B01];
};
extern VOLATILE_DEF struct Distab_B01S DISTAB_B01;
#endif // #if ( NUMBER_BYPASS_RASTER >= 1)

// Bypass Distab CFG struct B02
#if ( NUMBER_BYPASS_RASTER >= 2)
struct Distab_B02S
{
    tDistabHeader Header;
    uint32 display_tabelle[MAXPTR_B02];
};
extern VOLATILE_DEF struct Distab_B02S DISTAB_B02;
#endif // #if ( NUMBER_BYPASS_RASTER >= 2)

// Bypass Distab CFG struct B03
#if ( NUMBER_BYPASS_RASTER >= 3)
struct Distab_B03S
{
    tDistabHeader Header;
    uint32 display_tabelle[MAXPTR_B03];
};
extern VOLATILE_DEF struct Distab_B03S DISTAB_B03;
#endif // #if ( NUMBER_BYPASS_RASTER >= 3)

// Bypass Distab CFG struct B04
#if ( NUMBER_BYPASS_RASTER >= 4)
struct Distab_B04S
{
    tDistabHeader Header;
    uint32 display_tabelle[MAXPTR_B04];
};
extern VOLATILE_DEF struct Distab_B04S DISTAB_B04;
#endif // #if ( NUMBER_BYPASS_RASTER >= 4)

// Bypass Output B01
#if ( NUMBER_BYPASS_RASTER >= 1)
extern
#ifdef USE_FAR_DEF
FAR_DEF
#endif // #ifdef USE_FAR_DEF
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif // #ifdef USE_DISTAB_CONST_DEF
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif // #ifdef USE_VOLATILE_DEF
struct BYPASS_B01S
{
    tBypassHeader Header;
    uint8 receive_tabelle1[BYPASS_OUT_MAX_B01];
    uint8 receive_tabelle2[BYPASS_OUT_MAX_B01];
} BYPASS_B01;
#endif // #if ( NUMBER_BYPASS_RASTER >= 1)

// Bypass Output B02
#if ( NUMBER_BYPASS_RASTER >= 2)
extern
#ifdef USE_FAR_DEF
FAR_DEF
#endif // #ifdef USE_FAR_DEF
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif // #ifdef USE_DISTAB_CONST_DEF
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif // #ifdef USE_VOLATILE_DEF
struct BYPASS_B02S
{
    tBypassHeader Header;
    uint8 receive_tabelle1[BYPASS_OUT_MAX_B02];
    uint8 receive_tabelle2[BYPASS_OUT_MAX_B02];
} BYPASS_B02;
#endif // #if ( NUMBER_BYPASS_RASTER >= 2)

// Bypass Output B03
#if ( NUMBER_BYPASS_RASTER >= 3)
extern
#ifdef USE_FAR_DEF
FAR_DEF
#endif // #ifdef USE_FAR_DEF
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif // #ifdef USE_DISTAB_CONST_DEF
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif // #ifdef USE_VOLATILE_DEF
struct BYPASS_B03S
{
    tBypassHeader Header;
    uint8 receive_tabelle1[BYPASS_OUT_MAX_B03];
    uint8 receive_tabelle2[BYPASS_OUT_MAX_B03];
} BYPASS_B03;
#endif // #if ( NUMBER_BYPASS_RASTER >= 3)

// Bypass Output B04
#if ( NUMBER_BYPASS_RASTER >= 4)
extern
#ifdef USE_FAR_DEF
FAR_DEF
#endif // #ifdef USE_FAR_DEF
#ifdef USE_DISTAB_CONST_DEF
DISTAB_CONST_DEF
#endif // #ifdef USE_DISTAB_CONST_DEF
#ifdef USE_VOLATILE_DEF
VOLATILE_DEF
#endif // #ifdef USE_VOLATILE_DEF
struct BYPASS_B04S
{
    tBypassHeader Header;
    uint8 receive_tabelle1[BYPASS_OUT_MAX_B04];
    uint8 receive_tabelle2[BYPASS_OUT_MAX_B04];
} BYPASS_B04;
#endif // #if ( NUMBER_BYPASS_RASTER >= 4)

void Distab13_Disable(void);
#endif /*ifdef D13_SUPPORT */

#endif
