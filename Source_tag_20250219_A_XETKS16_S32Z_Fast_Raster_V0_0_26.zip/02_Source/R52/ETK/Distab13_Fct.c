/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "Distab13_Fct.h"
#include "ETK_Integration_Cfg.h"

#ifdef D13_SUPPORT

//*** Display Table (pointer list) ***
PRE_SECTION_BSS(DISTAB_R01, ".ETK_DisTab_MemClass")
VOLATILE_DEF struct Distab_R01S DISTAB_R01;
POST_SECTION_BSS()
PRE_SECTION_BSS(DISTAB_R02, ".ETK_DisTab_MemClass")
VOLATILE_DEF struct Distab_R02S DISTAB_R02;
POST_SECTION_BSS()
PRE_SECTION_BSS(DISTAB_R03, ".ETK_DisTab_MemClass")
VOLATILE_DEF struct Distab_R03S DISTAB_R03;
POST_SECTION_BSS()

#ifdef BYPASS_SUPPORT
PRE_SECTION_BSS(DISTAB_B01, ".ETK_DisTab_MemClass")
VOLATILE_DEF struct Distab_B01S DISTAB_B01;
POST_SECTION_BSS()
PRE_SECTION_BSS(DISTAB_B02, ".ETK_DisTab_MemClass")
VOLATILE_DEF struct Distab_B02S DISTAB_B02;
POST_SECTION_BSS()
PRE_SECTION_BSS(DISTAB_B03, ".ETK_DisTab_MemClass")
VOLATILE_DEF struct Distab_B03S DISTAB_B03;
POST_SECTION_BSS()
PRE_SECTION_BSS(DISTAB_B04, ".ETK_DisTab_MemClass")
VOLATILE_DEF struct Distab_B04S DISTAB_B04;
POST_SECTION_BSS()
#endif

//*** Display Table (DAQ channels) ***
PRE_SECTION_BSS(CHNL_R01, ".ETK_DAQChnl_MemClass")
VOLATILE_DEF uint32 CHNL_R01[MAXNUM_R01];
POST_SECTION_BSS()
PRE_SECTION_BSS(CHNL_R02, ".ETK_DAQChnl_MemClass")
VOLATILE_DEF uint32 CHNL_R02[MAXNUM_R02];
POST_SECTION_BSS()
PRE_SECTION_BSS(CHNL_R03, ".ETK_DAQChnl_MemClass")
VOLATILE_DEF uint32 CHNL_R03[MAXNUM_R03];
POST_SECTION_BSS()

#ifdef BYPASS_SUPPORT
PRE_SECTION_BSS(CHNL_B01, ".ETK_DAQChnl_MemClass")
VOLATILE_DEF uint32 CHNL_B01[MAXNUM_B01];
POST_SECTION_BSS()
PRE_SECTION_BSS(CHNL_B02, ".ETK_DAQChnl_MemClass")
VOLATILE_DEF uint32 CHNL_B02[MAXNUM_B02];
POST_SECTION_BSS()
PRE_SECTION_BSS(CHNL_B03, ".ETK_DAQChnl_MemClass")
VOLATILE_DEF uint32 CHNL_B03[MAXNUM_B03];
POST_SECTION_BSS()
PRE_SECTION_BSS(CHNL_B04, ".ETK_DAQChnl_MemClass")
VOLATILE_DEF uint32 CHNL_B04[MAXNUM_B04];
POST_SECTION_BSS()
#endif

// Bypass Output B01
#if ( NUMBER_BYPASS_RASTER >= 1)
VOLATILE_DEF
struct BYPASS_B01S BYPASS_B01
#ifndef TRG_SERIAL_ETK
    = { { 0 },{ 0 },{ 0 } }
#endif // #ifndef TRG_SERIAL_ETK
;
#endif // #if ( NUMBER_BYPASS_RASTER >= 1)

// Bypass Output B02
#if ( NUMBER_BYPASS_RASTER >= 2)
VOLATILE_DEF
struct BYPASS_B02S BYPASS_B02
#ifndef TRG_SERIAL_ETK
    = { { 0 },{ 0 },{ 0 } }
#endif // #ifndef TRG_SERIAL_ETK
;
#endif // #if ( NUMBER_BYPASS_RASTER >= 2)

// Bypass Output B03
#if ( NUMBER_BYPASS_RASTER >= 3)
VOLATILE_DEF
struct BYPASS_B03S BYPASS_B03
#ifndef TRG_SERIAL_ETK
    = { { 0 },{ 0 },{ 0 } }
#endif // #ifndef TRG_SERIAL_ETK
;
#endif // #if ( NUMBER_BYPASS_RASTER >= 3)

// Bypass Output B04
#if ( NUMBER_BYPASS_RASTER >= 4)
VOLATILE_DEF
struct BYPASS_B04S BYPASS_B04
#ifndef TRG_SERIAL_ETK
    = { { 0 },{ 0 },{ 0 } }
#endif // #ifndef TRG_SERIAL_ETK
;
#endif // #if ( NUMBER_BYPASS_RASTER >= 4)

// instances of distab discriptor
CONST_DEF tDistabDescriptor Distab_Cfg_R01
= {
  (tDistabHeader*)&(DISTAB_R01.Header),
  (uint32*)&CHNL_R01[0],
  MAXPTR_R01,
  MAXNUM_R01
};

CONST_DEF tDistabDescriptor Distab_Cfg_R02
= {
  (tDistabHeader*)&(DISTAB_R02.Header),
  (uint32*)&CHNL_R02[0],
  MAXPTR_R02,
  MAXNUM_R02
};

CONST_DEF tDistabDescriptor Distab_Cfg_R03
= {
  (tDistabHeader*)&(DISTAB_R03.Header),
  (uint32*)&CHNL_R03[0],
  MAXPTR_R03,
  MAXNUM_R03
};

#ifdef BYPASS_SUPPORT
CONST_DEF tDistabDescriptor Distab_Cfg_B01
= {
    (tDistabHeader*)&(DISTAB_B01.Header),
    (uint32*)&CHNL_B01[0],
    MAXPTR_B01,
    MAXNUM_B01
};

CONST_DEF tDistabDescriptor Distab_Cfg_B02
= {
    (tDistabHeader*)&(DISTAB_B02.Header),
    (uint32*)&CHNL_B02[0],
    MAXPTR_B02,
    MAXNUM_B02
};

CONST_DEF tDistabDescriptor Distab_Cfg_B03
= {
    (tDistabHeader*)&(DISTAB_B03.Header),
    (uint32*)&CHNL_B03[0],
    MAXPTR_B03,
    MAXNUM_B03
};
#endif

uint8 distab13fkt(tDistabDescriptor Distab)
{
    /* Pointers to measurement Buffers */
    uint8* dst_ptr1;
    uint16* dst_ptr2;
    uint32* dst_ptr4;
    ustr64* dst_ptr8;

    /* common Pointer to measurement Display Table Contents    */
    uint32* adr_ptr;

    /* NoOf-Counter with loaded with Contents in Display Table */
    uint16         noOfTransfers;

    /* Counters to hinder Acquisition Channel Overrun */
    uint16         byte_count, table_index;

    /* ptr to Display Table Header definition in ETK Page */
    tDistabHeader* DisplayTablePtr = (tDistabHeader*)Distab.Dstb_Header;

    if (DisplayTablePtr->activ == DISTAB_ACTIVE_BIT)      /* Table activated ?   */
    {
        /* reset counters */
        byte_count = 0;
        table_index = 0;

        if ((DisplayTablePtr->NoOfVal_8 + DisplayTablePtr->NoOfVal_4 +
            DisplayTablePtr->NoOfVal_2 + DisplayTablePtr->NoOfVal_1)
          > Distab.NoOfPtr)
        {
            return D13_TABLE_MAX_NUM_DATA_ERROR;
        }

        /**********************     ustr64      ***********************************/
        /* No of required ustr64 Vals*/
        noOfTransfers = DisplayTablePtr->NoOfVal_8;

        /* Ptr to temporary storage Buffer */
        dst_ptr8 = (ustr64*)Distab.DaqChnlPtr;

        /* Ptr to first addr-Entry in Display Table */
        adr_ptr = (uint32*)((uint8*)DisplayTablePtr +
            sizeof(tDistabHeader) + /* 8 */
            4 * table_index);

        /* Data Acquisition loop */
        while ((Distab.NoOfDataBytes - byte_count) >= 8 && noOfTransfers != 0)
        {
            *dst_ptr8++ = *(ustr64*)(*adr_ptr++);      /* Sample     */
            table_index++;                                  /* next entry */
            byte_count += 8;
            noOfTransfers--;
        }

        /* Note: noOfTransfers is 0, if no pack problem occured */
        table_index += noOfTransfers;


        /**********************     uint32      ***********************************/
        /* No of required uint32 Vals*/
        noOfTransfers = DisplayTablePtr->NoOfVal_4;

        /* Ptr to temporary storage Buffer */
        dst_ptr4 = (uint32*)dst_ptr8;

        /* Ptr to next addr-Entry in Display Table */
        adr_ptr = (uint32*)((uint8*)DisplayTablePtr +
            sizeof(tDistabHeader) +  /* 8 */
            4 * table_index);

        /* Data Acquisition loop */
        while ((Distab.NoOfDataBytes - byte_count) >= 4 && noOfTransfers != 0)
        {
            *dst_ptr4++ = *(uint32*)(*adr_ptr++);      /* Sample     */
            table_index++;                                  /* next entry */
            byte_count += 4;
            noOfTransfers--;
        }

        /* Note: noOfTransfers is 0, if no pack problem occured */
        table_index += noOfTransfers;

        /**********************     uint16      ***********************************/
        /* No of required uint16 Vals*/
        noOfTransfers = DisplayTablePtr->NoOfVal_2;

        /* Ptr to temporary storage Buffer */
        dst_ptr2 = (uint16*)dst_ptr4;

        /* Ptr to first addr-Entry in Display Table */
        adr_ptr = (uint32*)((uint8*)DisplayTablePtr +
            sizeof(tDistabHeader) +  /* 8 */
            4 * table_index);

        /* Data Acquisition loop */
        while ((Distab.NoOfDataBytes - byte_count) >= 2 && noOfTransfers != 0)
        {
            *dst_ptr2++ = *(uint16*)(*adr_ptr++);     /* Sample     */
            table_index++;                                  /* next entry */
            byte_count += 2;
            noOfTransfers--;
        }

        /* Note: noOfTransfers is 0, if no pack problem occured */
        table_index += noOfTransfers;

        /**********************     uint8       ***********************************/
        /* No of required uint8 Vals*/
        noOfTransfers = DisplayTablePtr->NoOfVal_1;

        /* Ptr to temporary storage Buffer */
        dst_ptr1 = (uint8*)dst_ptr2;

        /* Ptr to first addr-Entry in Display Table */
        adr_ptr = (uint32*)((uint8*)DisplayTablePtr +
            sizeof(tDistabHeader) +   /* 8 */
            4 * table_index);

        /* Data Acquisition loop */
        while ((Distab.NoOfDataBytes - byte_count) >= 1 && noOfTransfers != 0)
        {
            *dst_ptr1++ = *(uint8*)(*adr_ptr++);       /* Sample     */
            byte_count += 1;
            noOfTransfers--;
        }

        return D13_DATA_ACQUISITION_SUCCESS;
    }

    else
    {
        return D13_TABLE_NOT_ACTIVE;
    }
}

//Distab 13 process function
void ETK_Distab13_Process_Rxx(uint8  Raster, uint8  Trigger_Direct, uint16 Trigger, uint8 Trigger_ID, uint32 Trigger_ID_Val)
{
    switch (Raster)
    {

        //*** raster 1 ***/
    case 1:

        //copy function successfull?
        if (distab13fkt(Distab_Cfg_R01) == D13_DATA_ACQUISITION_SUCCESS)
        {
            //Trigger direct ?
            if (Trigger_Direct != 0)
            {
                Set_ETKTrigger_Direct(Trigger);
            }
            else
            {
                Set_ETKTrigger_Indirect(Trigger, Trigger_ID, Trigger_ID_Val);
            }
        }
        break;

        //*** raster 2 ***/
    case 2:

        //copy function successfull?
        if (distab13fkt(Distab_Cfg_R02) == D13_DATA_ACQUISITION_SUCCESS)
        {
            //Trigger direct ?
            if (Trigger_Direct != 0)
            {
                Set_ETKTrigger_Direct(Trigger);
            }
            else
            {
                Set_ETKTrigger_Indirect(Trigger, Trigger_ID, Trigger_ID_Val);
            }
        }
        break;

        //*** raster 3 ***/
    case 3:

        //copy function successfull?
        if (distab13fkt(Distab_Cfg_R03) == D13_DATA_ACQUISITION_SUCCESS)
        {
            //Trigger direct ?
            if (Trigger_Direct == DIRECT)
            {
                Set_ETKTrigger_Direct(Trigger);
            }
            else
            {
                Set_ETKTrigger_Indirect(Trigger, Trigger_ID, Trigger_ID_Val);
            }
        }
        break;

    default:
#ifdef RS232_DEBUG_LOGGING
        RS232_TxString("Raster not valid !\n\r");
#endif
        break;
    }
}


//direct trigger function
void Set_ETKTrigger_Direct(uint16 myTrigger)
{
    DBG_TRG = (1 << myTrigger);
}

//indirect trigger function -- NOT IMPLEMENTED
void Set_ETKTrigger_Indirect(uint16 myTrigger, uint8 myTrigId, uint32 myTrigId_Val)
{

}

void Distab13_Disable(void)
{
        // Disable All DISTAB 13 Measurement Rasters
#if ( NUMBER_MEASUREMENT_RASTER >= 1)
    DISTAB_R01.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 2)
    DISTAB_R02.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 3)
    DISTAB_R03.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 4)
    DISTAB_R04.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 5)
    DISTAB_R05.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 6)
    DISTAB_R06.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 7)
    DISTAB_R07.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 8)
    DISTAB_R08.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 9)
    DISTAB_R09.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 10)
    DISTAB_R10.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 11)
    DISTAB_R11.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 12)
    DISTAB_R12.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 13)
    DISTAB_R13.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 14)
    DISTAB_R14.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 15)
    DISTAB_R15.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 16)
    DISTAB_R16.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 17)
    DISTAB_R17.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 18)
    DISTAB_R18.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 19)
    DISTAB_R19.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 20)
    DISTAB_R20.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 21)
    DISTAB_R21.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 22)
    DISTAB_R22.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 23)
    DISTAB_R23.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 24)
    DISTAB_R24.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 25)
    DISTAB_R25.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 26)
    DISTAB_R26.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 27)
    DISTAB_R27.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 28)
    DISTAB_R28.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 29)
    DISTAB_R29.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 30)
    DISTAB_R30.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 31)
    DISTAB_R31.Header.activ = 0;
#endif
#if ( NUMBER_MEASUREMENT_RASTER >= 32)
    DISTAB_R32.Header.activ = 0;
#endif

    // Disable All D13 Bypass Rasters
#if ( NUMBER_BYPASS_RASTER >= 1)
    DISTAB_B01.Header.activ = 0;
#endif
#if ( NUMBER_BYPASS_RASTER >= 2)
    DISTAB_B02.Header.activ = 0;
#endif
#if ( NUMBER_BYPASS_RASTER >= 3)
    DISTAB_B03.Header.activ = 0;
#endif
#if ( NUMBER_BYPASS_RASTER >= 4)
    DISTAB_B04.Header.activ = 0;
#endif

}

#endif

