
#include "main_cpu4.h"

int main(void)
{
    Start_Cpu4();
    
    return 0;
}