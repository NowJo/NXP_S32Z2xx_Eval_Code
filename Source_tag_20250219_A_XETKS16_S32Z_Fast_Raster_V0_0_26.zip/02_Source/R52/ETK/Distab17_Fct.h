/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
/***************************************************************************//**
* \file  Distab17_Fct.h
* \brief file containing the function declaration to process a Distab event
*
* This file contains the prototype of the function that processes an individual
* (and active) non-TDM Distab event
*******************************************************************************/

#ifndef DISTAB17_FKT_H
#define DISTAB17_FKT_H

#include "ETK_Integration_Cfg.h"
#include "Distab17_Def.h"
#include "global.h"

#ifdef D17_USE_OPTIMIZE_2_LEVEL
enum D17_Result Distab17_CopyValuesFromECU(CONST_DEF tD17EventConfig* config) __attribute__((optimize("2")));
#else
enum D17_Result Distab17_CopyValuesFromECU(CONST_DEF tD17EventConfig* config);
#endif

#ifdef D17_ENABLE_BYPASS_SUPPORT
enum D17_Result Distab17_CopyValuesToECU(CONST_DEF tD17BypassReverseConfig* adrTabToECU);

#ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT
enum D17_Result Distab17_CopyValuesFromECULegacy(
    CONST_DEF tD17LegacyDistab* adrTabFromECU,
    void* datTabFromECU);
enum D17_Result Distab17_CopyValuesToECULegacy(
    CONST_DEF tD17LegacyReverseDistab* adrTabToECU,
    tD17LegacyBypassReverseData* datTabToECU);

#endif /* #ifdef D17_ENABLE_BYPASS_SBB_LEGACY_SUPPORT */

#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK
extern void D17_SBB_Error_Callback(uint8 servicePointIndex,
    enum D17_SBB_SP_Type servicePointType);
#endif /*#ifdef D17_ENABLE_BYPASS_ERROR_CALLBACK*/
#endif /* #ifdef D17_ENABLE_BYPASS_SUPPORT */

void Set_ETKTrigger_D17(uint8 myTrigger, uint32* myTrigAdr, uint32 myTrigId_Val);

#ifdef TRG_ON_RAM
extern volatile tInterfaceOnRAM RAM_INTERFACE;
#endif

#endif /* DISTAB17_FKT_H */
