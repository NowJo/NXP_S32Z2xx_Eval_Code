/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "ETK_SER_Coldstart.h"
#include "wdt.h"

static uint32 CheckTimeoutReady(uint32 waitTime);
static uint32 CheckTimeoutWait(uint32 waitTime);

PRE_SECTION_DATA(ColdStart_pattern, ".IRAM_DATA")
VOLATILE_DEF uint32 ColdStart_pattern = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(Handshake_Coldstart_M, ".IRAM_DATA")
struct Handshake_Coldstart_M Handshake_Coldstart_M = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(ColdStartStates_BSW, ".IRAM_DATA")
uint32 ColdStartStates_BSW = 0;
POST_SECTION_DATA()

#ifdef ASCET_PROJ
 // 500 ms wait time for the READY pattern after the ETK handshake - big number in order to get the exact time it took to setup everything
#define COLDSTART_READY_TIMEOUT  500000
#else
// 50 ms wait time for the READY pattern after the ETK handshake
#define COLDSTART_READY_TIMEOUT   50000 
#endif

PRE_SECTION_DATA(Coldstart_Wait_Timeout, ".IRAM_DATA")
CONST_DEF VOLATILE_DEF uint32 Coldstart_Wait_Timeout = 10000; // 10 ms (expected <10ms) wait time for the Wait pattern after the ETK handshake
POST_SECTION_DATA()

#ifdef COLDSTART_DEBUG_PATTERN
PRE_SECTION_DATA(Wait_Detected, ".IRAM_DATA")
uint8 Wait_Detected = FALSE;
POST_SECTION_DATA()
PRE_SECTION_DATA(Ready_Detected, ".IRAM_DATA")
uint8 Ready_Detected = FALSE;
POST_SECTION_DATA()
PRE_SECTION_DATA(Initial_Ready_Detected, ".IRAM_DATA")
uint8 Initial_Ready_Detected = FALSE;
POST_SECTION_DATA()
PRE_SECTION_DATA(Checking_Wait_But_Ready_Detected, ".IRAM_DATA")
uint8 Checking_Wait_But_Ready_Detected = FALSE;
POST_SECTION_DATA()
PRE_SECTION_DATA(ColdStartTimeOut, ".IRAM_DATA")
uint8 ColdStartTimeOut = TRUE;        // set ColdStartTimeOut to TRUE
POST_SECTION_DATA()
#endif

#ifdef COLDSTART_EXECUTION_TIME
PRE_SECTION_DATA(Coldstart_Start, ".IRAM_DATA")
uint32 Coldstart_Start = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(Coldstart_Counter_END_Wait, ".IRAM_DATA")
uint32 Coldstart_Counter_END_Wait = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(Coldstart_Counter_END_Ready, ".IRAM_DATA")
uint32 Coldstart_Counter_END_Ready = 0;

POST_SECTION_DATA()
PRE_SECTION_DATA(Coldstart_Pattern_at_Start_Routine, ".IRAM_DATA")
uint32 Coldstart_Pattern_at_Start_Routine;
POST_SECTION_DATA()
PRE_SECTION_DATA(Coldstart_Pattern_at_End_Routine, ".IRAM_DATA")
uint32 Coldstart_Pattern_at_End_Routine;
POST_SECTION_DATA()
#endif

/* Saves the time after the ECU triggers the end phase of the handshake, in order to calculate the timestamps for the coldstart functionality.
  Will only execute if the MC_Wait bit is set to 1 and the coldstart is requested during the handshake.*/
void Start_Timing_Coldstart(void)
{
    Handshake_Coldstart_M.StartTime = BASE_GetSystemTime();
    Coldstart_Start = Handshake_Coldstart_M.StartTime;
}

/* Clears the coldstart value.  */
void SER_ETK_Clear_Coldstart_Value(void)
{
#ifdef COLDSTART_DEBUG_PATTERN
    /* save the previous coldstart pattern value */
    Handshake_Coldstart_M.PatternAtStartRoutine = ColdStart_pattern;
#endif
    /* coldstart pattern reset value defined in the A2L */
    ColdStart_pattern = COLDSTART_RESET_PATTERN; // 0x12345678 by default
}

uint32 coldstart_check_spinner=0;
static uint32 CheckTimeoutReady(uint32 waitTime_us)
{
#ifdef ETK_EMULATION
    while (!BASE_Check_Timeout(Handshake_Coldstart_M.StartTime, waitTime_us))
    {
        //WDT_Service(); Watchdog should not enabled at this point
    }
    ColdStart_pattern=COLDSTART_READY_PATTERN;
#else
	
    while ((COLDSTART_READY_PATTERN != ColdStart_pattern) &&
           (!BASE_Check_Timeout(Handshake_Coldstart_M.StartTime, waitTime_us)))
    {
        coldstart_check_spinner++;
        //WDT_Service(); Watchdog should not enabled at this point
        /* Do nothing */
    }
#endif
    return ColdStart_pattern;
}

static uint32 CheckTimeoutWait(uint32 waitTime_us)
{
#ifdef ETK_EMULATION
    while (!BASE_Check_Timeout(Handshake_Coldstart_M.StartTime, waitTime_us))
        {
            WDT_Service();
        }
    ColdStart_pattern=COLDSTART_WAIT_PATTERN;
#else
         while (((COLDSTART_WAIT_PATTERN != ColdStart_pattern) &&
                (COLDSTART_READY_PATTERN != ColdStart_pattern) &&
                (!BASE_Check_Timeout(Handshake_Coldstart_M.StartTime, waitTime_us))))
    {
            WDT_Service();
        /* Do nothing */
    }
#endif
    return ColdStart_pattern;
}


/* Coldstart function, waits for the READY pattern
Delays the start of the user code until either the READY pattern is detected  in the coldstart mailbox or a timeout occurs.
This function will only be executed if the MC_Wait bit has been set during the handshake.
Return values:
                0x00 = if no Coldstart due to ETK not detected
                0x01 = Timeout Wait
                0x02 = Timeout Ready
                0x03 = Initial Ready Detected
                0x04 = Wait_Loop Ready Detected
                0x05 = Ready_Loop Ready Detected
*/

uint8 SER_ETK_Check_Coldstart(uint8 typeHS)
{
    uint32 pattern;
    uint32 tempTime;

    pattern = ColdStart_pattern;

#ifdef RS232_DEBUG_LOGGING
    RS232_TxString_Debug_Level_3("Start time measurement for Coldstart !\r\n");
#endif

#ifdef COLDSTART_EXECUTION_TIME
    Coldstart_Pattern_at_Start_Routine = pattern;
#endif

    // Get the Coldstart Pattern content
    if (COLDSTART_READY_PATTERN == pattern) // Initial READY pattern detected
    {
#ifdef COLDSTART_DEBUG_PATTERN
        Initial_Ready_Detected = TRUE;
        ColdStartTimeOut = FALSE;            // set ColdStartTimeOut to FALSE
#endif

#ifdef COLDSTART_EXECUTION_TIME
        Handshake_Coldstart_M.CounterEndReady = BASE_GetSystemTime();
        Coldstart_Counter_END_Wait = Handshake_Coldstart_M.CounterEndReady;
        Coldstart_Counter_END_Ready = Coldstart_Counter_END_Wait;
        Coldstart_Pattern_at_End_Routine = pattern;
#endif

        Handshake_Coldstart_M.ReturnValue = COLDSTART_RETURN_INITIAL_READY_DETECTED;

#ifdef RS232_DEBUG_LOGGING
        RS232_TxString_Debug_Level_3("Initial Ready Detected !\r\n");
#endif
    }
    else
    {
        if (eLegacy == typeHS )
        {
            pattern = CheckTimeoutWait(Coldstart_Wait_Timeout);
            tempTime = BASE_GetSystemTime();

            if (pattern == COLDSTART_READY_PATTERN)
            {
#ifdef COLDSTART_DEBUG_PATTERN
                ColdStartTimeOut = FALSE;        // set ColdStartTimeOut to FALSE
                Checking_Wait_But_Ready_Detected = TRUE;
#endif

#ifdef COLDSTART_EXECUTION_TIME
                Coldstart_Pattern_at_End_Routine = pattern;
                Coldstart_Counter_END_Wait = tempTime;
                Coldstart_Counter_END_Ready = tempTime;

                Handshake_Coldstart_M.ReturnValue = COLDSTART_RETURN_WAIT_LOOP_READY_DETECTED;

#endif

#ifdef RS232_DEBUG_LOGGING
                RS232_TxString_Debug_Level_3("Coldstart: WAIT Pattern Expected -> READY Pattern Detected !\r\n");
#endif

#ifdef COLDSTART_DEBUG_PATTERN
                Handshake_Coldstart_M.PatternAtEndRoutine = ColdStart_pattern;
#endif

                return Handshake_Coldstart_M.ReturnValue;
            }
            else if (pattern != COLDSTART_WAIT_PATTERN)
            {
#ifdef COLDSTART_EXECUTION_TIME
                Coldstart_Pattern_at_End_Routine = pattern;
                Coldstart_Counter_END_Wait = tempTime;

                Handshake_Coldstart_M.ReturnValue = COLDSTART_RETURN_TIMOUT_WAIT;
#endif

#ifdef RS232_DEBUG_LOGGING
                RS232_TxString_Debug_Level_3("Coldstart: Timeout WAIT Pattern !\r\n");
#endif

#ifdef COLDSTART_DEBUG_PATTERN
                Handshake_Coldstart_M.PatternAtEndRoutine = ColdStart_pattern;
#endif

                return Handshake_Coldstart_M.ReturnValue;
            }
            else
            {
#ifdef COLDSTART_DEBUG_PATTERN
                Wait_Detected = TRUE;
#endif

#ifdef COLDSTART_EXECUTION_TIME
                Coldstart_Counter_END_Wait = tempTime;
#endif
            }
        }
        else // Advanced HS
        {
            // Advanced HS doesn't not have th WAIT pattern, once the MC_Wait bit is passed through the HS
#ifdef COLDSTART_EXECUTION_TIME
            Coldstart_Counter_END_Wait = Coldstart_Start;
#endif
        }

        pattern = CheckTimeoutReady(COLDSTART_READY_TIMEOUT);
        tempTime = BASE_GetSystemTime();
#ifdef COLDSTART_EXECUTION_TIME
        Handshake_Coldstart_M.CounterEndReady = tempTime;
#endif

        if (COLDSTART_READY_PATTERN == pattern)
        {
#ifdef COLDSTART_DEBUG_PATTERN
            ColdStartTimeOut = FALSE;
            Ready_Detected = TRUE;
#endif

#ifdef COLDSTART_EXECUTION_TIME
            Coldstart_Counter_END_Ready = tempTime;
            Coldstart_Pattern_at_End_Routine = pattern;
#endif

#ifdef RS232_DEBUG_LOGGING
            if (Wait_Detected == TRUE)
            {
                RS232_TxString_Debug_Level_3("Coldstart: WAIT Pattern Detected !\r\n");
            }

            RS232_TxString_Debug_Level_3("Coldstart: READY Pattern Detected !\r\n");
#endif

            Handshake_Coldstart_M.ReturnValue = COLDSTART_RETURN_READY_LOOP_READY_DETECTED;

        }

        else
        {
            // Timeout is already TRUE

#ifdef COLDSTART_EXECUTION_TIME
            Coldstart_Counter_END_Ready = tempTime;
            Coldstart_Pattern_at_End_Routine = pattern;
#endif

#ifdef RS232_DEBUG_LOGGING

            if (Wait_Detected == TRUE)
            {
                RS232_TxString_Debug_Level_3("Coldstart: WAIT Pattern Detected !\r\n");
            }

            RS232_TxString_Debug_Level_3("Coldstart: Timeout READY Pattern !\r\n");
#endif

            Handshake_Coldstart_M.ReturnValue = COLDSTART_RETURN_TIMEOUT_READY;
        }

    }

#ifdef COLDSTART_DEBUG_PATTERN
    Handshake_Coldstart_M.PatternAtEndRoutine = ColdStart_pattern;
#endif

    return Handshake_Coldstart_M.ReturnValue;
}
