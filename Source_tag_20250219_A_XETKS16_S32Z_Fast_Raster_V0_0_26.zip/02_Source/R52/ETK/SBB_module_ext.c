/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "ETK_Integration_cfg.h"
#include "Distab17_Inst.h"

#ifdef BYPASS_SUPPORT

#ifdef RTT_TEST
PRE_SECTION_DATA(".SBB_IRAM")
real32 D17_BypRTT_Sum[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_BypassRoundTripTime[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_BypRTT_Min[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_BypRTT_Max[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_BypRTT_CountNumber[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_BypRTT_Avg[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
#else
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_BypassRoundTripTime[15] = { 0 };
POST_SECTION_DATA()
#endif
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_LockMissCount[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_ProcessCount[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 D17_TriggerCount[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()

#ifdef INIT_DEPRECATED_SBB_STRUCTURES
PRE_SECTION_DATA(".SBB_IRAM")
uint32 TimeOutPost[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint32 TimeOutPre[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
#endif

#ifdef RTT_TEST
PRE_SECTION_DATA(".SBB_IRAM")
uint16 D17_BypassFromEcuBytes[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint16 D17_BypassToEcuBytes[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
#else
PRE_SECTION_DATA(".SBB_IRAM")
uint16 D17_BypassFromEcuBytes[15] = { 0 }, D17_BypassToEcuBytes[15] = { 0 };
POST_SECTION_DATA()
#endif

/* These structures are already declared in the Distab17_Inst.c file and are unused by the project. */
#ifdef INIT_DEPRECATED_SBB_STRUCTURES
PRE_SECTION_DATA(".SBB_IRAM")
uint8 DisableECUFct[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint8 ResIdSrvPt[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint8 SrvPtEnabled[D17_MAXNUM_AVAILABLE_SERVICEPOINTS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(".SBB_IRAM")
uint8 SrvPtResId[D17_MAXNUM_AVAILABLE_SERVICEPOINTS + 1] = { 0 };
POST_SECTION_DATA()
#endif

// TODO add in Init function Variables_SBB_SPxxx.Init(); initialization with !=0 values ?

/* Initializes the EMEM memory containing the SBB test variables with 0 initial values. */

void Init_SBB_Variables(void)
{
    unsigned long long* dst_ptr8;
    uint32 no_of_val_8;


#if (defined SBB_ED_RAM_INIT_LOC && defined SBB_ED_RAM_INIT_SIZE)
    no_of_val_8 = SBB_ED_RAM_INIT_SIZE / 8; // number of 64 bit values to write

    dst_ptr8 = (unsigned long long*) SBB_ED_RAM_INIT_LOC;
    while (no_of_val_8 > 0)
    {
        *dst_ptr8++ = 0x0;
        *dst_ptr8++ = 0x0;
        *dst_ptr8++ = 0x0;
        *dst_ptr8++ = 0x0;
        no_of_val_8 -= 4;
    }
#else
#error "Undefined SBB variables location and size in the Init_SBB_Variables function !"
#endif
}


/* Initializes the P_D17_SrvPtResId, P_D17_ResIdSrvPt, P_D17_SrvPtEnabled, P_D17_DisableFctExec tables with 0 in case they are located in the EMEM memory which is not cleared after an ECU reset.*/

void Init_SBB_Structures_in_ED_RAM(void)
{
    uint16 noOfVal;
    uint8* dstPointer, * dstPointer_2, * dstPointer_3;
    // needed for serial ETKs, because these "parameters" are located inside internal RAM
    // and this is not initialized -> so the service point looks like active
    noOfVal = D17_MAXNUM_AVAILABLE_SERVICEPOINTS + 1;
    dstPointer = (uint32*)&(P_D17_SrvPtResId[0]);

    while (noOfVal > 0)
    {
        *dstPointer++ = 0;
        noOfVal--;
    }

    noOfVal = D17_MAXNUM_AVAILABLE_SERVICEPOINTS;
    dstPointer = (uint32*)&(P_D17_ResIdSrvPt[0]);
    dstPointer_2 = (uint32*)&(P_D17_SrvPtEnabled[0]);
    dstPointer_3 = (uint32*)&(P_D17_DisableFctExec[0]);

    while (noOfVal > 0)
    {
        *dstPointer++ = 0;
        *dstPointer_2++ = 0;
        *dstPointer_3++ = 0;
        noOfVal--;
    }
}

#endif
