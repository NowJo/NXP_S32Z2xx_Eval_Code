/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */
#include "meas_cal.h"
#include "emuram.h"
#include "ETK_Integration_Cfg.h" //SWITCH macros
#include "ETK_SectionMacro.h"
#include "ETK_CodeCheck.h"
#include "CompileTime.h"

/************************************* BEGIN OF MEASUREMENT VARIABLES ************************************/
PRE_SECTION_DATA(ProjVersion, ".IRAM_DATA")
VOLATILE_DEF tVersion ProjVersion = { 0, 0, 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(M_Prescaler_LED_900, ".IRAM_DATA")
VOLATILE_DEF uint32 M_Prescaler_LED_900 = 0;
POST_SECTION_DATA()

PRE_SECTION_DATA(PrescalerLedCounter, ".IRAM_DATA")
VOLATILE_DEF uint32 PrescalerLedCounter = 0;
POST_SECTION_DATA()

PRE_SECTION_DATA(HandshakeAtStartup, ".IRAM_DATA")
VOLATILE_DEF uint32 HandshakeAtStartup = 0;
POST_SECTION_DATA()

PRE_SECTION_DATA(DistabExecTime, ".IRAM_DATA")
VOLATILE_DEF uint32 DistabExecTime[DISTAB_RASTER_EVENTS] = { 0 };
POST_SECTION_DATA()

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
PRE_SECTION_DATA(ConsecutiveLedCounter, ".IRAM_DATA")
VOLATILE_DEF uint32 ConsecutiveLedCounter = 0;
POST_SECTION_DATA()
#endif

PRE_SECTION_DATA(M_I_RasterMeas, ".IRAM_DATA")
VOLATILE_DEF tMeas M_I_RasterMeas[NUMBER_MEAS_RASTERS] = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(M_E_RasterMeas, ".IRAM_DATA")
VOLATILE_DEF tMeas M_E_RasterMeas[NUMBER_MEAS_RASTERS] = { 0 };
POST_SECTION_DATA()

/* Coldstart ASW Variables */
#ifdef COLDSTART_EXECUTION_TIME
PRE_SECTION_DATA(Time_for_Wait_Pattern_ASD, ".IRAM_DATA")
uint32 Time_for_Wait_Pattern_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(Time_for_Ready_Pattern_ASD, ".IRAM_DATA")
uint32 Time_for_Ready_Pattern_ASD;
POST_SECTION_DATA()
#endif

/* Handshake ASW Variables */
#ifdef HANDSHAKE_EXECUTION_TIME
PRE_SECTION_DATA(ETK_Handshake_Start_Elapsed_Time_ASD, ".IRAM_DATA")
uint32 ETK_Handshake_Start_Elapsed_Time_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Detection_Protocol_Elapsed_Time_ASD, ".IRAM_DATA")
uint32 ETK_Detection_Protocol_Elapsed_Time_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Protocol_Handshake_End_Elapsed_Time_ASD, ".IRAM_DATA")
uint32 ETK_Protocol_Handshake_End_Elapsed_Time_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(ETK_Handshake_MBIN_Clear_Elapsed_Time_ASD, ".IRAM_DATA")
uint32 ETK_Handshake_MBIN_Clear_Elapsed_Time_ASD;
POST_SECTION_DATA()
#endif

/* Code Check ASW Variables */
PRE_SECTION_DATA(serETK_CodeCheck_RP_passed_ASD, ".IRAM_DATA")
uint8 serETK_CodeCheck_RP_passed_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckCylceTime_ASD, ".IRAM_DATA")
uint32 CodeCheckCylceTime_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternFLASH_Date_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternFLASH_Date_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternFLASH_Time_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternFLASH_Time_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternDATA_Date_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternDATA_Date_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternDATA_Time_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternDATA_Time_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternRAM_Date_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternRAM_Date_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternRAM_Time_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternRAM_Time_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternEMURAM_Date_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternEMURAM_Date_ASD;
POST_SECTION_DATA()
PRE_SECTION_DATA(CodeCheckPatternEMURAM_Time_ASD, ".IRAM_DATA")
uint32 CodeCheckPatternEMURAM_Time_ASD;
POST_SECTION_DATA()

#ifdef TRACE_SUPPORT
PRE_SECTION_BSS(pe0TraceVar_00, ".IRAM_TRACE")
VOLATILE_DEF tTraceVarBlock pe0TraceVar_00;
POST_SECTION_BSS()
PRE_SECTION_BSS(pe0TraceVar_01, ".IRAM_TRACE")
VOLATILE_DEF tTraceVarBlock pe0TraceVar_01;
POST_SECTION_BSS()

PRE_SECTION_BSS(pe1TraceVar_01, ".IRAM_TRACE_C1")
VOLATILE_DEF tTraceVarBlock pe1TraceVar_01;
POST_SECTION_BSS()

PRE_SECTION_BSS(pe2TraceVar_01, ".IRAM_TRACE_C2")
VOLATILE_DEF tTraceVarBlock pe2TraceVar_01;
POST_SECTION_BSS()

PRE_SECTION_BSS(pe3TraceVar_01, ".IRAM_TRACE_C3")
VOLATILE_DEF tTraceVarBlock pe3TraceVar_01;
POST_SECTION_BSS()

PRE_SECTION_BSS(pe4TraceVar_04, ".IRAM_TRACE_C4")
VOLATILE_DEF tTraceVarBlock pe4TraceVar_01;
POST_SECTION_BSS()

PRE_SECTION_BSS(pe5TraceVar_01, ".IRAM_TRACE_C5")
VOLATILE_DEF tTraceVarBlock pe5TraceVar_01;
POST_SECTION_BSS()

PRE_SECTION_BSS(pe6TraceVar_01, ".IRAM_TRACE_C6")
VOLATILE_DEF tTraceVarBlock pe6TraceVar_01;
POST_SECTION_BSS()

PRE_SECTION_BSS(pe7TraceVar_01, ".IRAM_TRACE_C7")
VOLATILE_DEF tTraceVarBlock pe7TraceVar_01;
POST_SECTION_BSS()

#endif //TRACE_SUPPORT

#ifdef CAL_MEASURE_V2
PRE_SECTION_DATA(M_Cal_Measure_V2_Intern, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureV2 M_Cal_Measure_V2_Intern = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(M_Cal_Measure_V2_Extern, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureV2 M_Cal_Measure_V2_Extern = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(M_Cal_Measure_V2_FAR, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureV2 M_Cal_Measure_V2_FAR = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(M_Cal_Measure_V2_Offline, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureV2 M_Cal_Measure_V2_Offline = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(M_Cal_Measure_V2_Reserved, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureV2 M_Cal_Measure_V2_Reserved = { 0 };
POST_SECTION_DATA()
PRE_SECTION_DATA(M_Cal_Measure_V2_Virtual, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureV2 M_Cal_Measure_V2_Virtual = { 0 };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_Cal_Measure_V2_Intern, ".ETAS_RP2")
CAL_DEF tCalMeasureV2 P_Cal_Measure_V2_Intern;
POST_SECTION_DATA()
PRE_SECTION_DATA(P_Cal_Measure_V2_Extern, ".ETAS_RP2")
CAL_DEF tCalMeasureV2 P_Cal_Measure_V2_Extern;
POST_SECTION_DATA()
PRE_SECTION_DATA(P_Cal_Measure_V2_FAR, ".ETAS_RP2")
CAL_DEF tCalMeasureV2 P_Cal_Measure_V2_FAR;
POST_SECTION_DATA()
PRE_SECTION_DATA(P_Cal_Measure_V2_Offline, ".ETAS_RP2")
CAL_DEF tCalMeasureV2 P_Cal_Measure_V2_Offline;
POST_SECTION_DATA()
PRE_SECTION_DATA(P_Cal_Measure_V2_Reserved, ".ETAS_RP2")
CAL_DEF tCalMeasureV2 P_Cal_Measure_V2_Reserved;
POST_SECTION_DATA()
PRE_SECTION_DATA(P_Cal_Measure_V2_Virtual, ".ETAS_RP2")
CAL_DEF tCalMeasureV2 P_Cal_Measure_V2_Virtual;
POST_SECTION_DATA()


#endif //CAL_MEASURE_V2

#ifdef CAL_MEASURE_BLOCKS
PRE_SECTION_DATA(M_Cal_Measure_Blocks, ".IRAM_DATA")
VOLATILE_DEF tCalMeasureBlocks M_Cal_Measure_Blocks = { { 0 } };
POST_SECTION_DATA()

PRE_SECTION_DATA(P_Cal_Measure_Blocks, ".ETAS_RP2")
VOLATILE_DEF tCalMeasureBlocks P_Cal_Measure_Blocks;
POST_SECTION_DATA()


#endif

PRE_SECTION_DATA(LuxTestScratchPad, ".LuxTestScratchPad")
volatile uint32 LuxTestScratchPad[64];
POST_SECTION_DATA()

/************************************* END OF MEASUREMENT VARIABLE ************************************/

/************************************* BEGIN OF CALIBRATION PARAMETERS ************************************/
PRE_SECTION_RODATA(P_Prescaler_LED_900, ".CAL_LED")
CAL_DEF uint32 P_Prescaler_LED_900 = 10;
POST_SECTION_RODATA()

PRE_SECTION_RODATA(P_RasterCalMax, ".CAL_PARAM")
CAL_DEF tCalMax P_RasterCalMax =
{
  //-1 is not "max positive value but is the value before roll over to 0 needed for LUX tests
    -1,     //sint32
    ~0,     //uint32
    -1,     //sint16
    ~0,     //uint16
    -1,     //sint8
    ~0      //uint8
};
POST_SECTION_RODATA()

PRE_SECTION_RODATA(P_CodeCheckCycleTime_ASD, ".CAL_PARAM")
CAL_DEF uint32 P_CodeCheckCycleTime_ASD = 1;
POST_SECTION_RODATA()
PRE_SECTION_RODATA(P_WriteCodeCheckPattern_cyclic_Enable, ".CAL_PARAM")
CAL_DEF uint8 P_WriteCodeCheckPattern_cyclic_Enable = 1;
POST_SECTION_RODATA()
PRE_SECTION_RODATA(P_Change_RAM_Pattern, ".CAL_PARAM")
CAL_DEF uint8 P_Change_RAM_Pattern = 0;
POST_SECTION_RODATA()

#ifdef TRACE_SUPPORT
PRE_SECTION_RODATA(tickInsideFor, ".CAL_PARAM")
CAL_DEF uint32 tickInsideFor = 0;
POST_SECTION_RODATA()
PRE_SECTION_RODATA(tickBetweenFor, ".CAL_PARAM")
CAL_DEF uint32 tickBetweenFor = 0x100;
POST_SECTION_RODATA()
PRE_SECTION_RODATA(delayEnabled, ".CAL_PARAM")
CAL_DEF uint8 delayEnabled = FALSE;
POST_SECTION_RODATA()
#endif

/************************************* END OF CALIBRATION PARAMETERS ************************************/

/************************************* BEGIN OF ADAPTIVE PARAMETERS ************************************/
PRE_SECTION_DATA(Padaptive_RPREQ_Force_Fail, ".IRAM_ADAP")
VOLATILE_DEF uint8 Padaptive_RPREQ_Force_Fail = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(Padaptive_WPREQ_Force_Fail, ".IRAM_ADAP")
VOLATILE_DEF uint8 Padaptive_WPREQ_Force_Fail = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(Padaptive_MOREQ_Force_Fail, ".IRAM_ADAP")
VOLATILE_DEF uint8 Padaptive_MOREQ_Force_Fail = 0;
POST_SECTION_DATA()
PRE_SECTION_DATA(Padaptive_PageSwitch_depending_CodeCheck, ".IRAM_ADAP")
VOLATILE_DEF uint8 Padaptive_PageSwitch_depending_CodeCheck = 0;
POST_SECTION_DATA()
/************************************* END OF ADAPTIVE PARAMETERS ************************************/

/* Functions */
#define INCREMENT_COUNTER(VAL, MAX) VAL++; *VAL = (MAX == *VAL) ? 0 : *VAL + 1

void MEAS_IncrementFct(VOLATILE_DEF tMeas* meas)
{
    uint8 i;

    VOLATILE_DEF sint8* sint8_ptr;
    VOLATILE_DEF sint16* sint16_ptr;
    VOLATILE_DEF sint32* sint32_ptr;
    VOLATILE_DEF uint8* uint8_ptr;
    VOLATILE_DEF uint16* uint16_ptr;
    VOLATILE_DEF uint32* uint32_ptr;
#ifdef FLOAT32_SUPPORT
    VOLATILE_DEF real32* fl32_ptr;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
    VOLATILE_DEF real64* fl64_ptr;
#endif // FLOAT64_SUPPORT

    sint8_ptr = &meas->sint8.sint8_01;
    uint8_ptr = &meas->uint8.uint8_01;
    sint16_ptr = &meas->sint16.sint16_01;
    uint16_ptr = &meas->uint16.uint16_01;
    sint32_ptr = &meas->sint32.sint32_01;
    uint32_ptr = &meas->uint32.uint32_01;
#ifdef FLOAT32_SUPPORT
    fl32_ptr = &meas->fl32.fl32_01;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
    fl64_ptr = &meas->fl64.fl64_01;
#endif // FLOAT64_SUPPORT

    /* INCREMENT_COUNTER starts incrementing it VAL++. So, it has to start one address before. */
    sint8_ptr--;
    uint8_ptr--;
    sint16_ptr--;
    uint16_ptr--;
    sint32_ptr--;
    uint32_ptr--;
#ifdef FLOAT32_SUPPORT
    fl32_ptr--;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
    fl64_ptr--;
#endif // FLOAT64_SUPPORT

    for (i = 0; i < 8; i++)
    {
        INCREMENT_COUNTER(sint8_ptr,  ACTIVE_PAGE_SINT8(P_RasterCalMax.sint8_max));
        INCREMENT_COUNTER(uint8_ptr,  ACTIVE_PAGE_UINT8(P_RasterCalMax.uint8_max));
        INCREMENT_COUNTER(sint16_ptr, ACTIVE_PAGE_SINT16(P_RasterCalMax.sint16_max));
        INCREMENT_COUNTER(uint16_ptr, ACTIVE_PAGE_UINT16(P_RasterCalMax.uint16_max));
        INCREMENT_COUNTER(sint32_ptr, ACTIVE_PAGE_SINT32(P_RasterCalMax.sint32_max));
        INCREMENT_COUNTER(uint32_ptr, ACTIVE_PAGE_UINT32(P_RasterCalMax.uint32_max));
#ifdef FLOAT32_SUPPORT
        fl32_ptr++;
        *fl32_ptr+=(real32)1.0;
#endif // FLOAT32_SUPPORT

#ifdef FLOAT64_SUPPORT
        fl64_ptr++;
        *fl64_ptr+=(real64)1.0;
#endif // FLOAT64_SUPPORT
    }

}


void MEAS_RasterCounters(uint8 index)
{
    MEAS_IncrementFct(&M_I_RasterMeas[index]);
    MEAS_IncrementFct(&M_E_RasterMeas[index]);
}

void MEAS_RasterCountersInit(void)
{
    uint8 i;

    for (i = 0; i < NUMBER_MEAS_RASTERS; i++)
    {
        M_I_RasterMeas[i].sint8.sint8_01 = -71;
        M_I_RasterMeas[i].sint8.sint8_02 = -61;
        M_I_RasterMeas[i].sint8.sint8_03 = -51;
        M_I_RasterMeas[i].sint8.sint8_04 = -41;
        M_I_RasterMeas[i].sint8.sint8_05 = -31;
        M_I_RasterMeas[i].sint8.sint8_06 = -21;
        M_I_RasterMeas[i].sint8.sint8_07 = -11;
        M_I_RasterMeas[i].sint8.sint8_08 = -01;

        M_I_RasterMeas[i].sint16.sint16_01 = -7003;
        M_I_RasterMeas[i].sint16.sint16_02 = -6003;
        M_I_RasterMeas[i].sint16.sint16_03 = -5003;
        M_I_RasterMeas[i].sint16.sint16_04 = -4003;
        M_I_RasterMeas[i].sint16.sint16_05 = -3003;
        M_I_RasterMeas[i].sint16.sint16_06 = -2003;
        M_I_RasterMeas[i].sint16.sint16_07 = -1003;
        M_I_RasterMeas[i].sint16.sint16_08 = -0003;

        M_I_RasterMeas[i].sint32.sint32_01 = -1900000005;
        M_I_RasterMeas[i].sint32.sint32_02 = -190000005;
        M_I_RasterMeas[i].sint32.sint32_03 = -19000005;
        M_I_RasterMeas[i].sint32.sint32_04 = -1900005;
        M_I_RasterMeas[i].sint32.sint32_05 = -190005;
        M_I_RasterMeas[i].sint32.sint32_06 = -19005;
        M_I_RasterMeas[i].sint32.sint32_07 = -1905;
        M_I_RasterMeas[i].sint32.sint32_08 = -195;

        M_I_RasterMeas[i].uint8.uint8_01 = 00;
        M_I_RasterMeas[i].uint8.uint8_02 = 10;
        M_I_RasterMeas[i].uint8.uint8_03 = 20;
        M_I_RasterMeas[i].uint8.uint8_04 = 30;
        M_I_RasterMeas[i].uint8.uint8_05 = 40;
        M_I_RasterMeas[i].uint8.uint8_06 = 50;
        M_I_RasterMeas[i].uint8.uint8_07 = 60;
        M_I_RasterMeas[i].uint8.uint8_08 = 70;

        M_I_RasterMeas[i].uint16.uint16_01 = 0005;
        M_I_RasterMeas[i].uint16.uint16_02 = 1005;
        M_I_RasterMeas[i].uint16.uint16_03 = 2005;
        M_I_RasterMeas[i].uint16.uint16_04 = 3005;
        M_I_RasterMeas[i].uint16.uint16_05 = 4005;
        M_I_RasterMeas[i].uint16.uint16_06 = 5005;
        M_I_RasterMeas[i].uint16.uint16_07 = 6005;
        M_I_RasterMeas[i].uint16.uint16_08 = 7005;

        M_I_RasterMeas[i].uint32.uint32_01 = 400000001;
        M_I_RasterMeas[i].uint32.uint32_02 = 40000001;
        M_I_RasterMeas[i].uint32.uint32_03 = 4000001;
        M_I_RasterMeas[i].uint32.uint32_04 = 400001;
        M_I_RasterMeas[i].uint32.uint32_05 = 40001;
        M_I_RasterMeas[i].uint32.uint32_06 = 4001;
        M_I_RasterMeas[i].uint32.uint32_07 = 401;
        M_I_RasterMeas[i].uint32.uint32_08 = 41;

        M_E_RasterMeas[i].sint8.sint8_01 = -72;
        M_E_RasterMeas[i].sint8.sint8_02 = -62;
        M_E_RasterMeas[i].sint8.sint8_03 = -52;
        M_E_RasterMeas[i].sint8.sint8_04 = -42;
        M_E_RasterMeas[i].sint8.sint8_05 = -32;
        M_E_RasterMeas[i].sint8.sint8_06 = -22;
        M_E_RasterMeas[i].sint8.sint8_07 = -12;
        M_E_RasterMeas[i].sint8.sint8_08 = -02;

        M_E_RasterMeas[i].sint16.sint16_01 = -7004;
        M_E_RasterMeas[i].sint16.sint16_02 = -6004;
        M_E_RasterMeas[i].sint16.sint16_03 = -5004;
        M_E_RasterMeas[i].sint16.sint16_04 = -4004;
        M_E_RasterMeas[i].sint16.sint16_05 = -3004;
        M_E_RasterMeas[i].sint16.sint16_06 = -2004;
        M_E_RasterMeas[i].sint16.sint16_07 = -1004;
        M_E_RasterMeas[i].sint16.sint16_08 = -0004;

        M_E_RasterMeas[i].sint32.sint32_01 = -200000005;
        M_E_RasterMeas[i].sint32.sint32_02 = -150000005;
        M_E_RasterMeas[i].sint32.sint32_03 = -100000004;
        M_E_RasterMeas[i].sint32.sint32_04 = -500000004;
        M_E_RasterMeas[i].sint32.sint32_05 = -50000004;
        M_E_RasterMeas[i].sint32.sint32_06 = -500004;
        M_E_RasterMeas[i].sint32.sint32_07 = -5004;
        M_E_RasterMeas[i].sint32.sint32_08 = -54;

        M_E_RasterMeas[i].uint8.uint8_01 = 01;
        M_E_RasterMeas[i].uint8.uint8_02 = 11;
        M_E_RasterMeas[i].uint8.uint8_03 = 21;
        M_E_RasterMeas[i].uint8.uint8_04 = 31;
        M_E_RasterMeas[i].uint8.uint8_05 = 41;
        M_E_RasterMeas[i].uint8.uint8_06 = 51;
        M_E_RasterMeas[i].uint8.uint8_07 = 61;
        M_E_RasterMeas[i].uint8.uint8_08 = 71;

        M_E_RasterMeas[i].uint16.uint16_01 = 0004;
        M_E_RasterMeas[i].uint16.uint16_02 = 1004;
        M_E_RasterMeas[i].uint16.uint16_03 = 2004;
        M_E_RasterMeas[i].uint16.uint16_04 = 3004;
        M_E_RasterMeas[i].uint16.uint16_05 = 4004;
        M_E_RasterMeas[i].uint16.uint16_06 = 5004;
        M_E_RasterMeas[i].uint16.uint16_07 = 6004;
        M_E_RasterMeas[i].uint16.uint16_08 = 7004;

        M_E_RasterMeas[i].uint32.uint32_01 = 430000002;
        M_E_RasterMeas[i].uint32.uint32_02 = 420000002;
        M_E_RasterMeas[i].uint32.uint32_03 = 42000002;
        M_E_RasterMeas[i].uint32.uint32_04 = 4200002;
        M_E_RasterMeas[i].uint32.uint32_05 = 420002;
        M_E_RasterMeas[i].uint32.uint32_06 = 42002;
        M_E_RasterMeas[i].uint32.uint32_07 = 4202;
        M_E_RasterMeas[i].uint32.uint32_08 = 422;
    }
}

void MEAS_PrescalerLedBlinking(void)
{
    M_Prescaler_LED_900 = ACTIVE_PAGE_UINT32(P_Prescaler_LED_900);

    if (0!=M_Prescaler_LED_900)
    {
        PrescalerLedCounter++;

        if(M_Prescaler_LED_900 <= PrescalerLedCounter )
        {
            PrescalerLedCounter = 0;
#ifdef LED_CAL
            GPIO_ToggleLED(LED_CAL);
#endif
        }
    }
}


void MEAS_StoreTestingVariables(void)
{
    ProjVersion.VersionX = VERSION_X;
    ProjVersion.VersionY = VERSION_Y;
    ProjVersion.VersionZ = VERSION_Z;

    serETK_CodeCheck_RP_passed_ASD = CodeCheck_RP();
    CodeCheckCylceTime_ASD = ACTIVE_PAGE_UINT32(P_CodeCheckCycleTime_ASD);

    /* Relevant for System Test and INCA Tests */
#ifdef COLDSTART_EXECUTION_TIME
    Time_for_Wait_Pattern_ASD = Coldstart_Counter_END_Wait - Coldstart_Start;
    Time_for_Ready_Pattern_ASD = Coldstart_Counter_END_Ready - Coldstart_Counter_END_Wait;
#endif

    /* Only Relevant for System Test */
#ifdef HANDSHAKE_EXECUTION_TIME
    ETK_Handshake_Start_Elapsed_Time_ASD = ETK_Handshake_Start_Timing_End - ETK_Handshake_Start_Timing_Start;
    ETK_Detection_Protocol_Elapsed_Time_ASD = ETK_Detection_Protocol_Timing_End - ETK_Detection_Protocol_Timing_Start;
    ETK_Protocol_Handshake_End_Elapsed_Time_ASD = ETK_Protocol_Handshake_End_Timing_End - ETK_Protocol_Handshake_End_Timing_Start;
    ETK_Handshake_MBIN_Clear_Elapsed_Time_ASD = ETK_Handshake_MBIN_Clear_Timing - ETK_Handshake_MBOUT_ACC_Write_Timing;
#endif

    // If the initial handshake was not executed successfully or the (X)ETK is not present
    if (ECU_ETK_ADV_Status.ETK_Available || ECU_ETK_Status.ETK_Available)
    {
        HandshakeAtStartup = 1;

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
        /** Resets the LEDs 0-3 in the LED off state.
        This is currently used to signalize a missing (X)ETK.*/
        GPIO_Led_YesEtk();
#endif
    }
    else
    {
        HandshakeAtStartup = 0;
#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
        /** Resets the LEDs 0-3 in the LED off state.
        This is currently used to signalize a missing (X)ETK.*/
        GPIO_Led_NoEtk();
#endif
    }
}

void MEAS_RefreshTestingVariables(void)
{
    /* Code Check get info - Only Relevant for System Test */
    Check_PageSwitch_after_CodeCheck(Padaptive_PageSwitch_depending_CodeCheck);
    OMD_Adaptive_Force_Fail_Parameters_Update(Padaptive_RPREQ_Force_Fail, Padaptive_WPREQ_Force_Fail, Padaptive_MOREQ_Force_Fail);

    /* Only Relevant for System Test */
#ifdef CODECHECK_SUPPORT
    CodeCheckPatternFLASH_Date_ASD = CODE_CHECK_CODE.Date;
    CodeCheckPatternFLASH_Time_ASD = CODE_CHECK_CODE.Time;
    CodeCheckPatternDATA_Date_ASD = CODE_CHECK_DATA.Date;
    CodeCheckPatternDATA_Time_ASD = CODE_CHECK_DATA.Time;
    CodeCheckPatternRAM_Date_ASD = CODE_CHECK_PATTERN_RAM_DATE;
    CodeCheckPatternRAM_Time_ASD = CODE_CHECK_PATTERN_RAM_TIME;
    CodeCheckPatternEMURAM_Date_ASD = CODE_CHECK_PATTERN_EMURAM_DATE;
    CodeCheckPatternEMURAM_Time_ASD = CODE_CHECK_PATTERN_EMURAM_TIME;
#endif
}

#ifdef CONSECUTIVE_LED_BLINKING_SUPPORT
void MEAS_ConsecutiveLedBlinking(void)
{
	M_Prescaler_LED_900 = ACTIVE_PAGE_UINT32(P_Prescaler_LED_900);

	PrescalerLedCounter++;

	if(M_Prescaler_LED_900 <= PrescalerLedCounter )
	{
		PrescalerLedCounter = 0;
		GPIO_LedBlinkingConsecutive(); // Blinks one of the Leds between the Leds
	}
}
#endif

#ifdef TRACE_SUPPORT
void MEAS_TraceCounters(VOLATILE_DEF tTraceVarBlock* trace)
{
    uint32 i;
    uint32 newvalue;

    //Calculating 16-bit array
    newvalue=trace->uint16_array[0]+1;
    for (i = 0; i < UINT16_TRACE_BLOCK; i++)
    {
        trace->uint16_array[i] = newvalue + i;

        if (delayEnabled)
        {
            BURST_PREVENT /* Collection of NOP's */
        }

    }

    //Calculating 32-bit array
    newvalue=trace->uint32_array[0]+1;
    for (i = 0; i < UINT32_TRACE_BLOCK; i++)
    {
        trace->uint32_array[i] =  newvalue + i;

        if (delayEnabled)
        {
            BURST_PREVENT /* Collection of NOP's */
        }

    }

    newvalue = trace->uint8_array[0]+1;
    for (i = 0; i < UINT8_TRACE_BLOCK; i++)
    {
        trace->uint8_array[i] = newvalue + i;

        if (delayEnabled)
        {
            BURST_PREVENT /* Collection of NOP's */
        }

    }
}
#endif

#ifdef CAL_MEASURE_V2
void MEAS_UpdateCalMeasureV2(void)
{
    MEAS_CalcCalMeasureV2(&M_Cal_Measure_V2_Intern,  &P_Cal_Measure_V2_Intern);
    MEAS_CalcCalMeasureV2(&M_Cal_Measure_V2_Extern,  &P_Cal_Measure_V2_Extern);
    MEAS_CalcCalMeasureV2(&M_Cal_Measure_V2_FAR,     &P_Cal_Measure_V2_FAR);
    MEAS_CalcCalMeasureV2(&M_Cal_Measure_V2_Offline, &P_Cal_Measure_V2_Offline);
    MEAS_CalcCalMeasureV2(&M_Cal_Measure_V2_Reserved, &P_Cal_Measure_V2_Reserved);
    MEAS_CalcCalMeasureV2(&M_Cal_Measure_V2_Virtual, &P_Cal_Measure_V2_Virtual);

}

void MEAS_CalcCalMeasureV2(VOLATILE_DEF tCalMeasureV2* meas, CAL_DEF tCalMeasureV2* cal)
{
    meas->S8_1 = ACTIVE_PAGE_SINT8(cal->S8_1);
    meas->S8_2 = ACTIVE_PAGE_SINT8(cal->S8_2);
    meas->S8_3 = ACTIVE_PAGE_SINT8(cal->S8_3);
    meas->S8_4 = ACTIVE_PAGE_SINT8(cal->S8_4);
    meas->U8_1 = ACTIVE_PAGE_UINT8(cal->U8_1);
    meas->U8_2 = ACTIVE_PAGE_UINT8(cal->U8_2);
    meas->U8_3 = ACTIVE_PAGE_UINT8(cal->U8_3);
    meas->U8_4 = ACTIVE_PAGE_UINT8(cal->U8_4);

    meas->S16_1 = ACTIVE_PAGE_SINT16(cal->S16_1);
    meas->S16_2 = ACTIVE_PAGE_SINT16(cal->S16_2);
    meas->S16_3 = ACTIVE_PAGE_SINT16(cal->S16_3);
    meas->U16_1 = ACTIVE_PAGE_UINT16(cal->U16_1);
    meas->U16_2 = ACTIVE_PAGE_UINT16(cal->U16_2);
    meas->U16_3 = ACTIVE_PAGE_UINT16(cal->U16_3);

    meas->S32_1 = ACTIVE_PAGE_SINT32(cal->S32_1);
    meas->S32_2 = ACTIVE_PAGE_SINT32(cal->S32_2);
    meas->U32_1 = ACTIVE_PAGE_UINT16(cal->U32_1);
    meas->U32_2 = ACTIVE_PAGE_UINT16(cal->U32_2);

#ifdef FLOAT32_SUPPORT
    meas->F32_1 = ACTIVE_PAGE_FL32(cal->F32_1);
    meas->F32_2 = ACTIVE_PAGE_FL32(cal->F32_2);
#endif

#ifdef FLOAT64_SUPPORT
    meas->F64_1 = ACTIVE_PAGE_FL64(cal->F64_1);
    meas->F64_2 = ACTIVE_PAGE_FL64(cal->F64_2);

#endif
}
#endif

#ifdef CAL_MEASURE_BLOCKS
void MEAS_UpdateCalMeasureBlocks(void)
{
	int Index_x, Index_y;
    for (Index_x = 0U; Index_x < 6U; Index_x++)
    {
        M_Cal_Measure_Blocks.Sint32_array[Index_x] = ACTIVE_PAGE_SINT32(P_Cal_Measure_Blocks.Sint32_array[Index_x]);
        M_Cal_Measure_Blocks.Sint16_array[Index_x] = ACTIVE_PAGE_SINT16(P_Cal_Measure_Blocks.Sint16_array[Index_x]);
        M_Cal_Measure_Blocks.Sint8_array[Index_x] = ACTIVE_PAGE_SINT8(P_Cal_Measure_Blocks.Sint8_array[Index_x]);
        M_Cal_Measure_Blocks.Uint32_array[Index_x] = ACTIVE_PAGE_UINT32(P_Cal_Measure_Blocks.Uint32_array[Index_x]);
        M_Cal_Measure_Blocks.Uint16_array[Index_x] = ACTIVE_PAGE_UINT16(P_Cal_Measure_Blocks.Uint16_array[Index_x]);
        M_Cal_Measure_Blocks.Uint8_array[Index_x] = ACTIVE_PAGE_UINT8(P_Cal_Measure_Blocks.Uint8_array[Index_x]);

#ifdef FLOAT32_SUPPORT
        M_Cal_Measure_Blocks.Fl32_array[Index_x] = ACTIVE_PAGE_FL32(P_Cal_Measure_Blocks.Fl32_array[Index_x]);
#endif

#ifdef FLOAT64_SUPPORT
        M_Cal_Measure_Blocks.Fl64_array[Index_x] = ACTIVE_PAGE_FL64(P_Cal_Measure_Blocks.Fl64_array[Index_x]);
#endif
    }

    for (Index_x = 0U; Index_x < 5U; Index_x++)
    {
        for (Index_y = 0U; Index_y < 6U; Index_y++)
        {
            M_Cal_Measure_Blocks.Sint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_SINT8(P_Cal_Measure_Blocks.Sint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Sint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_SINT16(P_Cal_Measure_Blocks.Sint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Sint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_SINT32(P_Cal_Measure_Blocks.Sint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Uint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_UINT8(P_Cal_Measure_Blocks.Uint8_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Uint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_UINT16(P_Cal_Measure_Blocks.Uint16_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

            M_Cal_Measure_Blocks.Uint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_UINT32(P_Cal_Measure_Blocks.Uint32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);

#ifdef FLOAT32_SUPPORT
            M_Cal_Measure_Blocks.Fl32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_FL32(P_Cal_Measure_Blocks.Fl32_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);
#endif

#ifdef FLOAT64_SUPPORT
            M_Cal_Measure_Blocks.Fl64_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]
                = ACTIVE_PAGE_FL64(P_Cal_Measure_Blocks.Fl64_matrix[Index_y + (((Index_x <= 4U) ? Index_x : 4U)) * 6U]);
#endif
        }

    }
}
#endif

void MEAS_UpdateEmuRamTestingVariables(void)
{
	uint8 cpu_id=GetCoreIndex();
	switch(cpu_id)
	{
	case eCORE_R52_0_INDEX:
		EMURAM_Update_Cpu0();
		break;

	case eCORE_R52_1_INDEX:
		EMURAM_Update_Cpu1();
		break;

	case eCORE_R52_2_INDEX:
		EMURAM_Update_Cpu2();
		break;

	case eCORE_R52_3_INDEX:
		EMURAM_Update_Cpu3();
		break;
	}
    //EMURAM_UpdateAll();
}
