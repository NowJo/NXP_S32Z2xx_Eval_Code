 /**************************************************************************************************
 *
 * Copyright 2021 NXP
 *
 **************************************************************************************************
 *
 * NXP Confidential Proprietary. This software is owned or controlled by NXP and may only be used
 * strictly in accordance with the applicable terms. By expressly accepting such terms or by
 * downloading, installing, activating and/or otherwise using the software, you are agreeing that
 * you have read, and that you agree to comply with and are bound by, such license terms.
 * If you do not agree to be bound by the applicable license terms, then you may not retain,
 * install, activate or otherwise use the software.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
**************************************************************************************************/
#include "common_utils.h"
#include "GIC.h"
#include "CORE_defines.h"


/////////////////////////////////////////////////
// Configure interrupts per core
/////////////////////////////////////////////////
	void INTC_setup_core0(void)
	{
		vuint16_t int_count, i;

		/* Initialize GIC */
		GIC_Distributer.GICD_CTLR.R |=1<<0; 		//enable GICD group 0 interrupt
		GIC_Distributer.GICD_CTLR.R |=1<<1;			//enable GICD group 1 interrupt
		while((GIC_Distributer.GICD_CTLR.R & 0x80000000) != 0x0);   // poll until bit RWP is cleared

		// Clear ProcessorSleep to 0 & poll until ChildrenAsleep is cleared
		GIC_RedistributerC0.GICR_WAKER.R &= 0xFFFFFFFD;
		while((GIC_RedistributerC0.GICR_WAKER.R & 0x00000004) !=0x0);

		ENABLECPUGROP0();							//enable CPU group 0 interrupt
		ENABLECPUGROP1();							//enable CPU group 1 interrupt
		CPUMASK();									//set CPU mask to min

		/* Enable interrupts */
		int_count = (GIC_Distributer.GICD_TYPER.R & 0x0000001F); //Get number of SPIs that the GIC supports
		for(i=0x104;i<=(0x104+((int_count+1)*0x4));i+=0x4)
		{
			*(vuint32_t*)(S250_GIC_BASEADDR+i) = 0xFFFFFFFF;	//enable all SPI
		}

		for(i=0x84; i<=0xF8; i+=0x4) /* Writing to GICD_IGROUPR1-30 */
		{
			*(vuint32_t*)(S250_GIC_BASEADDR+i) = 0xFFFFFFFF;	//Send all SPIs to Group1 (IRQ)
		}

		GIC_RedistSGIPPIC0.GICR_ISENABLER0.R = 0xFFFFFFFF;	//enable all SGI and PPI

		/* enable MSCM routings to both clusters */
		for (i=0x0;i<788;i+=0x1)
		{
			MSCM.IRSPRC[i].R = 0x3;
		}

	}



	void INTC_setup_core1(void)
	{
		// Clear ProcessorSleep to 0 & poll until ChildrenAsleep is cleared
		GIC_RedistributerC1.GICR_WAKER.R &= 0xFFFFFFFD;
		while((GIC_RedistributerC1.GICR_WAKER.R & 0x00000004) !=0x0);

		ENABLECPUGROP0();								//enable CPU group 0 interrupt
		ENABLECPUGROP1();								//enable CPU group 1 interrupt
		CPUMASK();										//set CPU mask to min
	}



	void INTC_setup_core2(void)
	{
		// Clear ProcessorSleep to 0 & poll until ChildrenAsleep is cleared
		GIC_RedistributerC0.GICR_WAKER.R &= 0xFFFFFFFD;
		while((GIC_RedistributerC0.GICR_WAKER.R & 0x00000004) !=0x0);

		ENABLECPUGROP0();								//enable CPU group 0 interrupt
		ENABLECPUGROP1();								//enable CPU group 1 interrupt
		CPUMASK();										//set CPU mask to min
	}



	void INTC_setup_core3(void)
	{
		// Clear ProcessorSleep to 0 & poll until ChildrenAsleep is cleared
		GIC_RedistributerC1.GICR_WAKER.R &= 0xFFFFFFFD;
		while((GIC_RedistributerC1.GICR_WAKER.R & 0x00000004) !=0x0);

		ENABLECPUGROP0();								//enable CPU group 0 interrupt
		ENABLECPUGROP1();								//enable CPU group 1 interrupt
		CPUMASK();										//set CPU mask to min
	}

	void INTC_setup_core4(void)
	{
		// Clear ProcessorSleep to 0 & poll until ChildrenAsleep is cleared
		GIC_RedistributerC0.GICR_WAKER.R &= 0xFFFFFFFD;
		while((GIC_RedistributerC0.GICR_WAKER.R & 0x00000004) !=0x0);

		ENABLECPUGROP0();								//enable CPU group 0 interrupt
		ENABLECPUGROP1();								//enable CPU group 1 interrupt
		CPUMASK();										//set CPU mask to min
	}



