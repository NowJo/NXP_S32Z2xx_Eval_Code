 /**************************************************************************************************
 *
 * Copyright 2021 NXP
 *
 **************************************************************************************************
 *
 * NXP Confidential Proprietary. This software is owned or controlled by NXP and may only be used
 * strictly in accordance with the applicable terms. By expressly accepting such terms or by
 * downloading, installing, activating and/or otherwise using the software, you are agreeing that
 * you have read, and that you agree to comply with and are bound by, such license terms.
 * If you do not agree to be bound by the applicable license terms, then you may not retain,
 * install, activate or otherwise use the software.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
**************************************************************************************************/
/*
 * FILE NAME: fs85_s247_init.c
 * DESCRIPTION:
 * This file contains the exception routines for core 3.
 **************************************************************************/

#include "project.h"
#include "target_specific.h"
#include "wdt.h"

//extern vuint32_t err_cnt_core5;

void C_Hyp_Und_exception_CORE5(void);
void C_Hyp_Data_Abort_Exception_Core5(void);
void C_Hyp_trap_exception_Core5(void);
void C_Data_Abort_Exception_Core5(void);
void C_irq_exception_CORE5(uint32_t);
void C_firq_exception_CORE5(uint32_t);

void C_Hyp_Und_exception_CORE5(void)
{
//	err_cnt_core5++;
    WDT_Wait_To_Die(); //Wait for WDT
}

void C_Hyp_Data_Abort_Exception_Core5(void)
{
//	err_cnt_core5++;
    WDT_Wait_To_Die(); //Wait for WDT
}

void C_Hyp_trap_exception_Core5(void)
{
//	err_cnt_core5++;
}

void C_irq_exception_CORE5(uint32_t intid)
{
//	err_cnt_core5++;
}

void C_firq_exception_CORE5(uint32_t intid)
{
//	err_cnt_core5++;
}

void C_Data_Abort_Exception_Core5(void)
{
//	err_cnt_core5++;
}
