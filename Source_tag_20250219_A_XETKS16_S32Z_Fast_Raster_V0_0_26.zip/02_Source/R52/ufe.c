/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2021                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */

#include "ufe.h"

#ifdef UFE_SUPPORT

PRE_SECTION_DATA(".IRAM_DATA")
VOLATILE_DEF uint8 UFE_Var = 127;
POST_SECTION_DATA()

PRE_SECTION_RODATA(".CAL_PARAM")
CONST_DEF VOLATILE_DEF uint32 UFE_ADDR_MAX = 0x800000;
POST_SECTION_RODATA()

PRE_SECTION_BSS(default)
VOLATILE_DEF tUfeMailbox CurrentRequest;
POST_SECTION_BSS()

PRE_SECTION_BSS(default)
VOLATILE_DEF tUfeMailbox LastRequest;
POST_SECTION_BSS()

PRE_SECTION_BSS(default)
VOLATILE_DEF tUfeMailbox Acknowledge;
POST_SECTION_BSS()

PRE_SECTION_RODATA(".UFE_DATA")
CONST_DEF VOLATILE_DEF tUfeMailbox Request = { 0, 0, 0, 0, 0, { 0 } };
POST_SECTION_RODATA()

void UFE_UfeInit(void)
{
    UFE_Var = 127;

    Acknowledge.counter = 0;
    Acknowledge.index = 0;
    Acknowledge.nroBytes = 0;
    Acknowledge.addr = 0;
    Acknowledge.length = 0;

    for (uint16 i = 0; i < 256; i++)
    {
        Acknowledge.parameter[i] = 0;
    }

    LastRequest.counter = 0;
    LastRequest.index = 0;
    LastRequest.nroBytes = 0;
    LastRequest.addr = 0;
    LastRequest.length = 0;


    for (uint16 i = 0; i < 256; i++)
    {
        LastRequest.parameter[i] = 0;
    }

    CurrentRequest.counter = 0;
    CurrentRequest.index = 0;
    CurrentRequest.nroBytes = 0;
    CurrentRequest.addr = 0;
    CurrentRequest.length = 0;

    for (uint16 i = 0; i < 256; i++)
    {
        CurrentRequest.parameter[i] = 0;
    }
}
void UFE_UfeProcess(void)
{
    //Updating the current REQ Mailbox
    CurrentRequest.counter = ACTIVE_PAGE_SINT32(Request.counter);
    CurrentRequest.index = ACTIVE_PAGE_UINT32(Request.index);
    CurrentRequest.nroBytes = ACTIVE_PAGE_UINT32(Request.nroBytes);
    CurrentRequest.addr = ACTIVE_PAGE_UINT32(Request.addr);
    CurrentRequest.length = ACTIVE_PAGE_UINT16(Request.length);

    for (uint16 i = 0; i < 256; i++)
    {
        CurrentRequest.parameter[i] = ACTIVE_PAGE_UINT8(Request.parameter[i]);
    }

    //Reset the ECU value in case INCA restarted
    if (ACTIVE_PAGE_SINT32(Request.counter) == 0x00)
    {
        Acknowledge.counter = 0x00;
    }

#ifdef VERIFY_COUNTER
    if (UFE_SwapEndianU32IfNeeded(ACTIVE_PAGE_SINT32(Request.counter)) == (UFE_SwapEndianU32IfNeeded(Acknowledge.counter) + 1))
#endif
    {
        //Copying the Request from INCA
        LastRequest.counter = ACTIVE_PAGE_SINT32(Request.counter);
        LastRequest.index = ACTIVE_PAGE_UINT32(Request.index);
        LastRequest.nroBytes = ACTIVE_PAGE_UINT32(Request.nroBytes);
        LastRequest.addr = ACTIVE_PAGE_UINT32(Request.addr);
        LastRequest.length = ACTIVE_PAGE_UINT16(Request.length);

        for (uint16 i = 0; i < 256; i++)
        {
            LastRequest.parameter[i] = ACTIVE_PAGE_UINT8(Request.parameter[i]);
        }

        //Taking the actions
        switch (ACTIVE_PAGE_UINT32(Request.index))
        {
        case 0x01000000:
            //Calling the function
            UFE_Set0Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x02000000:
            //Calling the function
            UFE_Set10Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x03000000:
            //Calling the function
            UFE_Set50Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x04000000:
            //Calling the function
            UFE_Set100Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x05000000:
            //Calling the function
            UFE_Set127Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x06000000:
            //Calling the function
            UFE_Set150Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x07000000:
            //Calling the function
            UFE_Set200Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x08000000:
            //Calling the function
            UFE_Set250Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x09000000:
            //Calling the function
            UFE_Set255Fnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x0A000000:
            //Calling the function
            UFE_ReadValueFnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x0B000000:
            //Calling the function
            UFE_WriteValueFnc();

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x0C000000:
            //Calling the function
            UFE_ReadMemoryFnc(&Request, &Acknowledge);

            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);
            break;

        case 0x0D000000:
            //In this case response is sent first because we'll reset the controller
            //Success response
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = ACTIVE_PAGE_SINT32(Request.counter);

            //Calling the function
            UFE_ResetController();
            break;

        default:
            //UF does not exist for this ECU code -> AC = -1
            Acknowledge.nroBytes = ACTIVE_PAGE_UINT32(Request.nroBytes);
            Acknowledge.index = ACTIVE_PAGE_UINT32(Request.index);
            Acknowledge.counter = -1;
            break;
        }
    }
}

uint32 UFE_SwapEndianU32IfNeeded(uint32 value)
{
#ifdef SWAP_ENDIAN
    uint32 b0 = (uint32)(value & 0x000000FF) << 24u;
    uint32 b1 = (uint32)(value & 0x0000FF00) << 8u;
    uint32 b2 = (uint32)(value & 0x00FF0000) >> 8u;
    uint32 b3 = (uint32)(value & 0xFF000000) >> 24u;

    return b0 | b1 | b2 | b3;
#else
    return value;
#endif
}

uint16 UFE_SwapEndianU16IfNeeded(uint16 value)
{
#ifdef SWAP_ENDIAN
    uint16 b0 = (uint16)(value & 0x00FF) << 8u;
    uint16 b1 = (uint16)(value & 0xFF00) >> 8u;

    return b0 | b1;
#else
    return value;
#endif
}

void UFE_Set0Fnc(void)
{
    UFE_Var = 0;
    Acknowledge.nroBytes = 0;
}
void UFE_Set10Fnc(void)
{
    UFE_Var = 10;
    Acknowledge.nroBytes = 0;
}
void UFE_Set50Fnc(void)
{
    UFE_Var = 50;
    Acknowledge.nroBytes = 0;
}
void UFE_Set100Fnc(void)
{
    UFE_Var = 100;
    Acknowledge.nroBytes = 0;
}
void UFE_Set127Fnc(void)
{
    UFE_Var = 127;
    Acknowledge.nroBytes = 0;
}
void UFE_Set150Fnc(void)
{
    UFE_Var = 150;
    Acknowledge.nroBytes = 0;
}
void UFE_Set200Fnc(void)
{
    UFE_Var = 200;
    Acknowledge.nroBytes = 0;
}
void UFE_Set250Fnc(void)
{
    UFE_Var = 250;
    Acknowledge.nroBytes = 0;
}
void UFE_Set255Fnc(void)
{
    UFE_Var = 255;
    Acknowledge.nroBytes = 0;
}
void UFE_ReadValueFnc(void)
{
    //Clearing the ACK Mailbox parameters
    for (uint16 i = 0; i < 256; i++)
    {
        Acknowledge.parameter[i] = 0;
    }

    //Sending the UFE_Var value
    Acknowledge.parameter[0] = UFE_Var;

    //Sending Length = 1 independent from the request becuase UFE_Var is uint8
    Acknowledge.length = UFE_SwapEndianU16IfNeeded(0x01);

    //Number of Bytes is fixed for an Read Request
    Acknowledge.nroBytes = UFE_SwapEndianU32IfNeeded(0x106);

    //Sending back the address requested (it does not take affect in this UF)
    Acknowledge.addr = ACTIVE_PAGE_UINT32(Request.addr);
}
void UFE_WriteValueFnc(void)
{
    //Clearing the ACK Mailbox parameters
    for (uint16 i = 0; i < 256; i++)
    {
        Acknowledge.parameter[i] = 0;
    }

    //Writing the parameter to the UFE_Var
    UFE_Var = ACTIVE_PAGE_UINT8(ACTIVE_PAGE_UINT8(Request.parameter[0]));

    //Sending back the value to ACK Mailbox
    Acknowledge.parameter[0] = UFE_Var;

    //Length is independent from REQ Mailbox because UFE_Var is uint8
    Acknowledge.length = UFE_SwapEndianU16IfNeeded(0x01);

    //Number of bytes is fixed 0x106 for Write Request
    Acknowledge.nroBytes = UFE_SwapEndianU32IfNeeded(0x106);

    //Sending back the same address requested (it does not affect the UF)
    Acknowledge.addr = ACTIVE_PAGE_UINT32(Request.addr);
}

void UFE_ReadMemoryFnc(CONST_DEF VOLATILE_DEF tUfeMailbox * Req, VOLATILE_DEF tUfeMailbox * Ack)
{
    uint8* pRead;
    pRead = (uint8*)(UFE_SwapEndianU32IfNeeded(Req->addr));

    //Clearing the ACK Mailbox parameter array
    for (uint16 i = 0; i < 256; i++)
    {
        Ack->parameter[i] = 0;
    }

    //Checking if the address is within the uC valid range
    if ((UFE_SwapEndianU32IfNeeded(Req->addr) + UFE_SwapEndianU16IfNeeded(Req->length)) < ACTIVE_PAGE_UINT32(UFE_ADDR_MAX))
    {
        //Copying the memory content to the ACK parameter array byte per byte (uint8)
        for (uint16 i = 0; i < UFE_SwapEndianU16IfNeeded(Req->length); i++)
        {
            Ack->parameter[i] = *pRead++; // *pRead is uint8
        }
    }

    //Sending back the same lenght requested
    Ack->length = Req->length;

    //Number of bytes is fixed for Read request
    Ack->nroBytes = UFE_SwapEndianU32IfNeeded(0x106);
    Ack->addr = Req->addr;
}

void UFE_ResetController(void)
{
    BASE_WaitInMicroSeconds(WAIT_UNTIL_RESET);
    BASE_ResetController(); //Incase soft reset by WDT does not happen
}

#endif
