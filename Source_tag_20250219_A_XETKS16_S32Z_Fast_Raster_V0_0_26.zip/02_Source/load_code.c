/* /BEGIN COPYRIGHT_HEADER                                                     */
/*                                                                             */
/* Added by copyright.py V1.3.2                                                */
/*                                                                             */
/* =========================================================================== */
/* Copyright and Legal Disclaimer:                                             */
/* This Code example was provided by ETAS GmbH, Stuttgart                      */
/*                                                                             */
/* ETAS will not be held reliable for any usage of this code,                  */
/* this code is provided as example code only, and not tested and released     */
/* for production code.                                                        */
/* ETAS will not guarantee any functional part of this code in any             */
/* environment together with any ETAS tools. ETAS will not guarantee that      */
/* this code works together with any future versions of ETAS tools.            */
/*                                                                             */
/* ETAS will not guarantee that this code is free of rights of third parties.  */
/*                                                                             */
/* You are hereby granted the right to use his code as a example for your own  */
/* ECU implementation together with ETAS Tools. No licenses are granted by     */
/* implication or otherwise under any patents or trademarks of ETAS GmbH.      */
/* This software is provided on an "AS IS" basis and without warranty.         */
/*                                                                             */
/* You are not allowed to give these code to third parties without             */
/* the written permission of ETAS GmbH.                                        */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* ETAS GmbH DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED,              */
/* INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A            */
/* PARTICULAR PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD        */
/* TO THE SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF)                   */
/* AND ANY ACCOMPANYING WRITTEN MATERIALS.                                     */
/*                                                                             */
/*                                                                             */
/* To the maximum extent permitted by applicable law,                          */
/* IN NO EVENT SHALL ETAS BE LIABLE FOR ANY                                    */
/* DAMAGES WHATSOEVER (INCLUDING WITHOUT LIMITATION, DAMAGES FOR LOSS OF       */
/* BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION,      */
/* OR OTHER PECUNIARY LOSS)                                                    */
/* ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.                        */
/*                                                                             */
/*                                                                             */
/* ETAS GmbH assumes no responsibility for the maintenance                     */
/* and support of this software                                                */
/*                                                                             */
/*                                                                             */
/*  COPYRIGHT (c) ETAS GmbH 2022                                               */
/*  All Rights Reserved                                                        */
/* =========================================================================== */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/*     ETK Drivers Example                         |   ETAS GmbH               */
/*     For Demonstration Purpose Only              |   Stuttgart Feuerbach     */
/*     Sample Driver Implementation                |   All rights reserved     */
/*                                                                             */
/* =========================================================================== */
/*                                                                             */
/* /END COPYRIGHT_HEADER                                                       */


#include "a_std_type.h"
#include "load_code.h"
#include "target_specific.h"
#include "ETK_SectionMacro.h"

#ifdef BOOT_CORE_M33
PRE_SECTION_DATA(rtu_code_store, ".rtu_load_buffer")
struct _load_code_header rtu_code_store;
POST_SECTION_DATA()
#endif
#ifdef RTU_STAND_ALONE_BOOT
PRE_SECTION_DATA(smu_code_store, ".smu_load_buffer")
struct _load_code_header smu_code_store;
POST_SECTION_DATA()
#endif

#include "gpio.h"
void InitCoreSRAM(void)
{
        //POR requested so we can initialize these else we get a reset!
#ifdef BOOT_CORE_M33
   //Clear shared RAM
		RTU0__SRAMCTL_D0.RAMIAS.R=0x31780000;
		RTU0__SRAMCTL_D0.RAMIAE.R=0x317BFFFF;
		RTU0__SRAMCTL_D0.RAMCR.R=0x101;

		RTU0__SRAMCTL_D1.RAMIAS.R=0x317C0000;
		RTU0__SRAMCTL_D1.RAMIAE.R=0x317FFFFF;
		RTU0__SRAMCTL_D1.RAMCR.R=0x101;

		RTU0__SRAMCTL_D2.RAMIAS.R=0x31800000;
		RTU0__SRAMCTL_D2.RAMIAE.R=0x3187FFFF;
		RTU0__SRAMCTL_D2.RAMCR.R=0x101;

		RTU1__SRAMCTL_D0.RAMIAS.R=0x35780000;
		RTU1__SRAMCTL_D0.RAMIAE.R=0x357BFFFF;
		RTU1__SRAMCTL_D0.RAMCR.R=0x101;

		RTU1__SRAMCTL_D1.RAMIAS.R=0x357C0000;
		RTU1__SRAMCTL_D1.RAMIAE.R=0x357FFFFF;
		RTU1__SRAMCTL_D1.RAMCR.R=0x101;

		RTU1__SRAMCTL_D2.RAMIAS.R=0x35800000;
		RTU1__SRAMCTL_D2.RAMIAE.R=0x3587FFFF;
		RTU1__SRAMCTL_D2.RAMCR.R=0x101;
		while( !
		((RTU0__SRAMCTL_D0.RAMSR.R&1) &
		 (RTU0__SRAMCTL_D1.RAMSR.R&1) &
		 (RTU0__SRAMCTL_D2.RAMSR.R&1) &
		 (RTU1__SRAMCTL_D0.RAMSR.R&1) &
		 (RTU1__SRAMCTL_D1.RAMSR.R&1) &
		 (RTU1__SRAMCTL_D2.RAMSR.R&1)));

		if( 0!=LoadCodeAvailableAddr())
		{
			//Prep the RTU to receive its code!
				RTU0__SRAMCTL_C0.RAMIAS.R=0x32100000;
				RTU0__SRAMCTL_C0.RAMIAE.R=0x321FFFFF;
				RTU0__SRAMCTL_C0.RAMCR.R=0x101;

				RTU0__SRAMCTL_C1.RAMIAS.R=0x32200000;
				RTU0__SRAMCTL_C1.RAMIAE.R=0x322FFFFF;
				RTU0__SRAMCTL_C1.RAMCR.R=0x101;

				RTU0__SRAMCTL_C2.RAMIAS.R=0x32300000;
				RTU0__SRAMCTL_C2.RAMIAE.R=0x323FFFFF;
				RTU0__SRAMCTL_C2.RAMCR.R=0x101;

				RTU0__SRAMCTL_C3.RAMIAS.R=0x32400000;
				RTU0__SRAMCTL_C3.RAMIAE.R=0x324FFFFF;
				RTU0__SRAMCTL_C3.RAMCR.R=0x101;

				RTU0__SRAMCTL_C4.RAMIAS.R=0x32500000;
				RTU0__SRAMCTL_C4.RAMIAE.R=0x325FFFFF;
				RTU0__SRAMCTL_C4.RAMCR.R=0x101;

				RTU0__SRAMCTL_C5.RAMIAS.R=0x32600000;
				RTU0__SRAMCTL_C5.RAMIAE.R=0x326FFFFF;
				RTU0__SRAMCTL_C5.RAMCR.R=0x101;

				RTU0__SRAMCTL_C6.RAMIAS.R=0x32700000;
				RTU0__SRAMCTL_C6.RAMIAE.R=0x327FFFFF;
				RTU0__SRAMCTL_C6.RAMCR.R=0x101;

				/*Make sure that the RTU0 Code space is all initialized */

				RTU1__SRAMCTL_C0.RAMIAS.R=0x36100000;
				RTU1__SRAMCTL_C0.RAMIAE.R=0x361FFFFF;
				RTU1__SRAMCTL_C0.RAMCR.R=0x101;

				RTU1__SRAMCTL_C1.RAMIAS.R=0x36200000;
				RTU1__SRAMCTL_C1.RAMIAE.R=0x362FFFFF;
				RTU1__SRAMCTL_C1.RAMCR.R=0x101;

				RTU1__SRAMCTL_C2.RAMIAS.R=0x36300000;
				RTU1__SRAMCTL_C2.RAMIAE.R=0x363FFFFF;
				RTU1__SRAMCTL_C2.RAMCR.R=0x101;

				RTU1__SRAMCTL_C3.RAMIAS.R=0x36400000;
				RTU1__SRAMCTL_C3.RAMIAE.R=0x364FFFFF;
				RTU1__SRAMCTL_C3.RAMCR.R=0x101;

				RTU1__SRAMCTL_C4.RAMIAS.R=0x36500000;
				RTU1__SRAMCTL_C4.RAMIAE.R=0x365FFFFF;
				RTU1__SRAMCTL_C4.RAMCR.R=0x101;

				RTU1__SRAMCTL_C5.RAMIAS.R=0x36600000;
				RTU1__SRAMCTL_C5.RAMIAE.R=0x366FFFFF;
				RTU1__SRAMCTL_C5.RAMCR.R=0x101;

				RTU1__SRAMCTL_C6.RAMIAS.R=0x36700000;
				RTU1__SRAMCTL_C6.RAMIAE.R=0x367FFFFF;
				RTU1__SRAMCTL_C6.RAMCR.R=0x101;

				//Lets CLear FlexSRAM for use in system test
				CE_SRAMCTL_0.RAMIAS.R=0x26000000;
				CE_SRAMCTL_0.RAMIAE.R=0x26FFFFFF;
				CE_SRAMCTL_0.RAMCR.R=0x101;

				while( !
				((RTU0__SRAMCTL_C0.RAMSR.R&1) &
				 (RTU0__SRAMCTL_C1.RAMSR.R&1) &
				 (RTU0__SRAMCTL_C2.RAMSR.R&1) &
				 (RTU0__SRAMCTL_C3.RAMSR.R&1) &
				 (RTU0__SRAMCTL_C4.RAMSR.R&1) &
				 (RTU0__SRAMCTL_C5.RAMSR.R&1) &
				 (RTU0__SRAMCTL_C6.RAMSR.R&1)));

/* Causing continuous resets under some conditions because registers are not
			 * valid.  (Short power cycle after programming*/
				while( !
				((RTU1__SRAMCTL_C0.RAMSR.R&1) &
				 (RTU1__SRAMCTL_C1.RAMSR.R&1) &
				 (RTU1__SRAMCTL_C2.RAMSR.R&1) &
				 (RTU1__SRAMCTL_C3.RAMSR.R&1) &
				 (RTU1__SRAMCTL_C4.RAMSR.R&1) &
				 (RTU1__SRAMCTL_C5.RAMSR.R&1) &
				 (RTU1__SRAMCTL_C6.RAMSR.R&1)));
		}


#elif defined(RTU_STAND_ALONE_BOOT)

		if( IsLoadCodeAvailable())
		{
		  uint8 cpu_id= GetCoreIndex();

		  if( eCORE_R52_0_INDEX == cpu_id)
		  {
			//Only clear SMU from core 0
			SMU__SRAMCTL_0.RAMIAS.R=0x25000000;
			SMU__SRAMCTL_0.RAMIAE.R=0x2503FFFF;
			SMU__SRAMCTL_0.RAMCR.R=0x1;

			SMU__SRAMCTL_1.RAMIAS.R=0x25040000;
			SMU__SRAMCTL_1.RAMIAE.R=0x2507FFFF;
			SMU__SRAMCTL_1.RAMCR.R=0x1;

			SMU__SRAMCTL_2.RAMIAS.R=0x25080000;
			SMU__SRAMCTL_2.RAMIAE.R=0x250BFFFF;
			SMU__SRAMCTL_2.RAMCR.R=0x1;

			SMU__SRAMCTL_3.RAMIAS.R=0x250C0000;
			SMU__SRAMCTL_3.RAMIAE.R=0x250FFFFF;
			SMU__SRAMCTL_3.RAMCR.R=0x1;
		  }
		}
#endif

}


#if defined(BOOT_CORE_M33)||defined(RTU_STAND_ALONE_BOOT)
/**  LoadCodeSections() will only load if the pattern is found.  This allows the ability to load both the
 *   RTU and SMU from the debugger if desired.
 */
void LoadCodeSections(void)
{
    uint32 n, items;
    uint32 *pSrc, *pDest;
    uint32 numsegments;
    uint32 load_addr;
    struct _load_code_header *code_store;

    InitCoreSRAM();

    load_addr=LoadCodeAvailableAddr();
    if( 0!=load_addr)
    {
    	code_store=(struct _load_code_header *)(load_addr);
        numsegments=code_store->num_sections;
        for(n=0; n<numsegments ; n++)
        {
            pSrc=(uint32 *)((load_addr) + code_store->load_section[n].src_offset);
            pDest=(uint32 *)(code_store->load_section[n].dest_addr);
            items=(code_store->load_section[n].src_size+sizeof(uint32)-1)/sizeof(uint32);
            while(0<items)
            {
                *pDest=*pSrc;
                pSrc++;
                pDest++;
                items--;
            }
        }
    }

}
#endif
